import { callAI } from './client'
import type { AIInterpretation, RelationshipAnalysis } from '@/types'

const DEMO_INTERPRETATION: AIInterpretation = {
  observation:
    'BTC and NASDAQ historically show a positive relationship. The current rolling correlation has fallen sharply from 0.72 to 0.18.',
  statisticalEvidence:
    'Current correlation: 0.18 | Baseline: 0.72 | Z-score: -2.7σ | Sample: 90 observations',
  regime: 'DIVERGENCE',
  strategyHypothesis:
    'A mean-reversion pair framework could be investigated. The hypothesis is that the relationship may normalize toward its historical baseline.',
  risk:
    'Relationship instability remains elevated. The divergence may continue or deepen before normalizing. This is a hypothesis, not a guaranteed reversal.',
  nextAction: 'RUN BACKTEST',
  confidence: 'MEDIUM',
  causeVerified: false,
}

export async function explainAnomaly(
  analysis: RelationshipAnalysis,
  assetAName: string,
  assetBName: string
): Promise<AIInterpretation> {
  const response = await callAI({
    type: 'explain_anomaly',
    payload: {
      assetA: assetAName,
      assetB: assetBName,
      currentCorrelation: analysis.currentCorrelation,
      baselineCorrelation: analysis.baselineCorrelation,
      zScore: analysis.zScore,
      regime: analysis.regime,
      sampleSize: analysis.sampleSize,
    },
  })

  if (response.success && response.data) {
    return response.data as unknown as AIInterpretation
  }

  // Demo fallback with real values injected
  return {
    ...DEMO_INTERPRETATION,
    statisticalEvidence: `Current correlation: ${(analysis.currentCorrelation ?? 0).toFixed(2)} | Baseline: ${(analysis.baselineCorrelation ?? 0).toFixed(2)} | Z-score: ${(analysis.zScore ?? 0).toFixed(1)}σ | Sample: ${analysis.sampleSize} observations`,
    observation: `${assetAName} and ${assetBName} historically show a ${(analysis.baselineCorrelation ?? 0) > 0 ? 'positive' : 'negative'} relationship. The current rolling correlation has ${(analysis.zScore ?? 0) < 0 ? 'fallen' : 'risen'} sharply from ${(analysis.baselineCorrelation ?? 0).toFixed(2)} to ${(analysis.currentCorrelation ?? 0).toFixed(2)}.`,
    regime: analysis.regime,
    causeVerified: false,
  }
}
