import { logReturns } from '@/engine/correlation'

/**
 * Estimate hedge ratio using OLS beta:
 * beta = Cov(A, B) / Var(B)
 *
 * This represents how many units of B to hold per unit of A
 * to create a market-neutral pair.
 */
export function estimateHedgeRatio(pricesA: number[], pricesB: number[]): number | null {
  if (pricesA.length !== pricesB.length || pricesA.length < 20) return null

  const retA = logReturns(pricesA)
  const retB = logReturns(pricesB)

  const n = retA.length
  if (n < 20) return null

  const meanA = retA.reduce((s, v) => s + v, 0) / n
  const meanB = retB.reduce((s, v) => s + v, 0) / n

  let cov = 0
  let varB = 0
  for (let i = 0; i < n; i++) {
    cov += (retA[i] - meanA) * (retB[i] - meanB)
    varB += (retB[i] - meanB) ** 2
  }

  if (varB === 0) return null

  const beta = cov / varB
  // Return absolute value, direction is handled by strategy
  return Math.abs(beta)
}
