export function DemoModeBanner() {
  return (
    <div className="bg-[#F2F2F2] border-b-2 border-black py-1.5 px-6">
      <p className="text-[10px] sm:text-[11px] uppercase tracking-widest text-center text-[#444444] font-medium">
        <span className="font-black text-black">DEMO MODE</span> — All data is seeded and deterministic.
        Calculations are real. No live market data.
        <span className="font-black text-accent ml-2">SIMULATED EXECUTION ONLY.</span>
      </p>
    </div>
  )
}
