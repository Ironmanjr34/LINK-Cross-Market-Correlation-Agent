import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type {
  Anomaly,
  StrategyDefinition,
  BacktestResult,
  RiskEvaluation,
  PaperPosition,
  JournalEntry,
  ScanResult,
  RelationshipAnalysis,
  AIInterpretation,
} from '@/types'
import { generateId } from '@/lib/utils'

interface LinkState {
  // UI
  isDemoMode: boolean
  activeTab: string
  selectedPair: string | null

  // Scan results
  scanResult: ScanResult | null
  isScanning: boolean

  // Analysis
  currentAnalysis: RelationshipAnalysis | null
  currentInterpretation: AIInterpretation | null

  // Strategy
  currentStrategy: StrategyDefinition | null
  strategies: StrategyDefinition[]

  // Backtest
  currentBacktest: BacktestResult | null

  // Risk
  currentRisk: RiskEvaluation | null

  // Paper trading
  paperBalance: number
  paperPositions: PaperPosition[]

  // Journal
  journal: JournalEntry[]

  // Watchlist
  watchlist: string[] // pair IDs

  // Actions
  setActiveTab: (tab: string) => void
  setSelectedPair: (pair: string | null) => void
  setScanResult: (result: ScanResult | null) => void
  setIsScanning: (v: boolean) => void
  setCurrentAnalysis: (analysis: RelationshipAnalysis | null) => void
  setCurrentInterpretation: (interpretation: AIInterpretation | null) => void
  setCurrentStrategy: (strategy: StrategyDefinition | null) => void
  addStrategy: (strategy: StrategyDefinition) => void
  setCurrentBacktest: (result: BacktestResult | null) => void
  setCurrentRisk: (risk: RiskEvaluation | null) => void
  addPaperPosition: (position: PaperPosition) => void
  updatePaperPosition: (id: string, updates: Partial<PaperPosition>) => void
  addJournalEntry: (entry: Omit<JournalEntry, 'id' | 'timestamp'>) => void
  addToWatchlist: (pairId: string) => void
  removeFromWatchlist: (pairId: string) => void
  resetPaperTrading: () => void
}

const INITIAL_PAPER_BALANCE = 10_000

export const useLinkStore = create<LinkState>()(
  persist(
    (set, get) => ({
      isDemoMode: true,
      activeTab: 'overview',
      selectedPair: null,

      scanResult: null,
      isScanning: false,

      currentAnalysis: null,
      currentInterpretation: null,

      currentStrategy: null,
      strategies: [],

      currentBacktest: null,
      currentRisk: null,

      paperBalance: INITIAL_PAPER_BALANCE,
      paperPositions: [],

      journal: [],
      watchlist: [],

      setActiveTab: (tab) => set({ activeTab: tab }),
      setSelectedPair: (pair) => set({ selectedPair: pair }),
      setScanResult: (result) => set({ scanResult: result }),
      setIsScanning: (v) => set({ isScanning: v }),
      setCurrentAnalysis: (analysis) => set({ currentAnalysis: analysis }),
      setCurrentInterpretation: (interpretation) => set({ currentInterpretation: interpretation }),
      setCurrentStrategy: (strategy) => set({ currentStrategy: strategy }),
      addStrategy: (strategy) =>
        set((state) => ({ strategies: [...state.strategies, strategy] })),
      setCurrentBacktest: (result) => set({ currentBacktest: result }),
      setCurrentRisk: (risk) => set({ currentRisk: risk }),

      addPaperPosition: (position) =>
        set((state) => ({ paperPositions: [...state.paperPositions, position] })),

      updatePaperPosition: (id, updates) =>
        set((state) => ({
          paperPositions: state.paperPositions.map((p) =>
            p.id === id ? { ...p, ...updates } : p
          ),
          paperBalance:
            updates.balanceAfter !== undefined
              ? updates.balanceAfter
              : state.paperBalance,
        })),

      addJournalEntry: (entry) =>
        set((state) => ({
          journal: [
            {
              ...entry,
              id: generateId(),
              timestamp: Date.now(),
            },
            ...state.journal,
          ].slice(0, 500), // keep last 500
        })),

      addToWatchlist: (pairId) =>
        set((state) => ({
          watchlist: state.watchlist.includes(pairId)
            ? state.watchlist
            : [...state.watchlist, pairId],
        })),

      removeFromWatchlist: (pairId) =>
        set((state) => ({
          watchlist: state.watchlist.filter((id) => id !== pairId),
        })),

      resetPaperTrading: () =>
        set({
          paperBalance: INITIAL_PAPER_BALANCE,
          paperPositions: [],
        }),
    }),
    {
      name: 'link-store',
      partialize: (state) => ({
        strategies: state.strategies,
        paperBalance: state.paperBalance,
        paperPositions: state.paperPositions,
        journal: state.journal,
        watchlist: state.watchlist,
      }),
    }
  )
)
