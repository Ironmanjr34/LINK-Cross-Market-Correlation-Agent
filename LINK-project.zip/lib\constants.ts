import type { Asset } from '@/types'

export const DEMO_ASSETS: Asset[] = [
  { id: 'BTC', symbol: 'BTC', name: 'Bitcoin', category: 'crypto', currency: 'USD' },
  { id: 'ETH', symbol: 'ETH', name: 'Ethereum', category: 'crypto', currency: 'USD' },
  { id: 'SOL', symbol: 'SOL', name: 'Solana', category: 'crypto', currency: 'USD' },
  { id: 'BNB', symbol: 'BNB', name: 'BNB', category: 'crypto', currency: 'USD' },
  { id: 'NASDAQ', symbol: 'NASDAQ', name: 'NASDAQ Composite', category: 'equity', currency: 'USD' },
  { id: 'SPX', symbol: 'SPX', name: 'S&P 500', category: 'equity', currency: 'USD' },
  { id: 'TECH', symbol: 'TECH', name: 'Technology Basket', category: 'equity', currency: 'USD' },
  { id: 'GROWTH', symbol: 'GROWTH', name: 'Growth Basket', category: 'equity', currency: 'USD' },
  { id: 'GOLD', symbol: 'GOLD', name: 'Gold', category: 'commodity', currency: 'USD' },
  { id: 'OIL', symbol: 'OIL', name: 'Crude Oil', category: 'commodity', currency: 'USD' },
  { id: 'DXY', symbol: 'DXY', name: 'US Dollar Index', category: 'fx', currency: 'USD' },
  { id: 'USDT', symbol: 'USDT', name: 'US Treasury Yield', category: 'macro', currency: 'USD' },
]

export const ASSET_MAP: Record<string, Asset> = Object.fromEntries(
  DEMO_ASSETS.map((a) => [a.id, a])
)

export const DEFAULT_LOOKBACK_DAYS = 30
export const MIN_SAMPLE_SIZE = 20
export const ROLLING_WINDOW = 30
export const ANOMALY_Z_THRESHOLD = 2.0
export const WATCHLIST_Z_THRESHOLD = 1.5

export const DEMO_CAPITAL = 10_000
export const DEFAULT_FEES_BPS = 10 // 0.10%
export const DEFAULT_SLIPPAGE_BPS = 5 // 0.05%

export const STRATEGY_TYPES = [
  { id: 'MEAN_REVERSION', label: 'Mean Reversion', description: 'Trade divergence expecting normalization' },
  { id: 'BREAKOUT', label: 'Regime Breakout', description: 'Trade continuation of relationship break' },
  { id: 'RELATIVE_STRENGTH', label: 'Relative Strength', description: 'Compare normalized returns between assets' },
  { id: 'CROSS_MARKET_ROTATION', label: 'Cross-Market Rotation', description: 'Use relationship changes for allocation shifts' },
] as const

export const TIMEFRAMES = ['1D', '4H', '1H', '30M'] as const
export const LOOKBACK_OPTIONS = [7, 14, 30, 60, 90, 180] as const

export const REGIME_LABELS: Record<string, string> = {
  STRONG_POSITIVE: 'STRONG POSITIVE',
  MODERATE_POSITIVE: 'MODERATE POSITIVE',
  NEUTRAL: 'NEUTRAL',
  MODERATE_NEGATIVE: 'MODERATE NEGATIVE',
  STRONG_NEGATIVE: 'STRONG NEGATIVE',
  DIVERGENCE: 'DIVERGENCE',
  STRENGTHENING: 'STRENGTHENING',
  WEAKENING: 'WEAKENING',
  INVERTING: 'INVERTING',
  BROKEN: 'BROKEN',
  INSUFFICIENT_DATA: 'INSUFFICIENT DATA',
}

export const DATA_SOURCE_LABEL = 'DEMO / SEEDED'
export const DATA_NOTE = 'CALCULATED ON DEMO DATA'
