import { SwissPanel, SwissButton, SwissStatus } from '@/components/swiss'
import type { StrategyDefinition } from '@/types'

interface StrategyRuleCardProps {
  strategy: StrategyDefinition
  onRunBacktest?: () => void
  onEdit?: () => void
}

const TYPE_LABELS: Record<string, string> = {
  MEAN_REVERSION: 'MEAN REVERSION',
  BREAKOUT: 'REGIME BREAKOUT',
  RELATIVE_STRENGTH: 'RELATIVE STRENGTH',
  CROSS_MARKET_ROTATION: 'CROSS-MARKET ROTATION',
}

export function StrategyRuleCard({ strategy, onRunBacktest, onEdit }: StrategyRuleCardProps) {
  return (
    <SwissPanel border="all" borderWidth={4} padding="md">
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <p className="text-[11px] uppercase tracking-widest text-[#999999] font-medium">STRATEGY</p>
          <h2 className="text-xl font-black mt-0.5">{strategy.name}</h2>
        </div>
        <SwissStatus status="INFO" label={TYPE_LABELS[strategy.type] ?? strategy.type} size="md" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-8 gap-y-4 mb-6">
        {[
          { label: 'ASSET A', value: strategy.assetA },
          { label: 'ASSET B', value: strategy.assetB },
          { label: 'LOOKBACK', value: `${strategy.lookback}D` },
          { label: 'TIMEFRAME', value: strategy.timeframe },
          { label: 'POSITION MODE', value: strategy.positionMode.toUpperCase() },
          { label: 'REBALANCE', value: strategy.rebalanceFrequency.toUpperCase() },
        ].map(({ label, value }) => (
          <div key={label}>
            <p className="text-[11px] uppercase tracking-widest text-[#999999]">{label}</p>
            <p className="text-sm font-bold mono-value mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {/* Signal rules */}
      <div className="border-t-2 border-black pt-4 mb-6">
        <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-3">SIGNAL RULES</p>
        <div className="grid grid-cols-3 gap-4">
          <div className="border-l-4 border-black pl-3">
            <p className="text-[10px] uppercase tracking-widest text-[#999999]">ENTRY</p>
            <p className="text-lg font-black mono-value">|Z| &gt; {strategy.entryZ.toFixed(1)}σ</p>
          </div>
          <div className="border-l-4 border-[#999999] pl-3">
            <p className="text-[10px] uppercase tracking-widest text-[#999999]">EXIT</p>
            <p className="text-lg font-black mono-value">|Z| &lt; {strategy.exitZ.toFixed(1)}σ</p>
          </div>
          <div className="border-l-4 border-accent pl-3">
            <p className="text-[10px] uppercase tracking-widest text-accent font-bold">STOP</p>
            <p className="text-lg font-black mono-value text-accent">|Z| &gt; {strategy.stopZ.toFixed(1)}σ</p>
          </div>
        </div>
      </div>

      {/* Capital & costs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm mb-6">
        {[
          { label: 'CAPITAL', value: `$${strategy.capitalAllocation.toLocaleString()}` },
          { label: 'HEDGE RATIO', value: strategy.hedgeRatio ? strategy.hedgeRatio.toFixed(2) : '1.00' },
          { label: 'FEES', value: `${strategy.feesBps}bps` },
          { label: 'SLIPPAGE', value: `${strategy.slippageBps}bps` },
        ].map(({ label, value }) => (
          <div key={label}>
            <p className="text-[11px] uppercase tracking-widest text-[#999999]">{label}</p>
            <p className="font-bold mono-value">{value}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-3">
        {onRunBacktest && (
          <SwissButton onClick={onRunBacktest} variant="primary" size="md">
            RUN BACKTEST
          </SwissButton>
        )}
        {onEdit && (
          <SwissButton onClick={onEdit} variant="secondary" size="md">
            EDIT PARAMETERS
          </SwissButton>
        )}
      </div>

      <p className="text-[10px] text-[#999999] uppercase tracking-widest mt-3">CALCULATED ON DEMO DATA — NOT FINANCIAL ADVICE</p>
    </SwissPanel>
  )
}
