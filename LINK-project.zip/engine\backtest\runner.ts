import type {
  StrategyDefinition,
  BacktestResult,
  BacktestTrade,
  PriceSeries,
  CorrelationObservation,
} from '@/types'
import { rollingCorrelation, alignSeries, logReturns } from '@/engine/correlation'
import {
  calcWinRate,
  calcProfitFactor,
  calcMaxDrawdown,
  calcSharpe,
  calcAnnualizedReturn,
  buildEquityCurve,
} from './metrics'
import { generateId } from '@/lib/utils'
import { DATA_SOURCE_LABEL } from '@/lib/constants'

/**
 * Run a backtest for a correlation-based pair strategy.
 *
 * Methodology:
 * 1. Align price series by timestamp.
 * 2. Compute rolling correlation and z-score chronologically.
 * 3. Generate signals — entry at next candle after signal (avoids look-ahead).
 * 4. Apply fees and slippage at entry and exit.
 * 5. Record all trades.
 * 6. Calculate performance metrics from trade log.
 */
export function runBacktest(
  strategy: StrategyDefinition,
  seriesA: PriceSeries,
  seriesB: PriceSeries
): BacktestResult {
  const { pricesA, pricesB, timestamps } = alignSeries(seriesA, seriesB)

  const feeFactor = 1 - strategy.feesBps / 10000
  const slippageFactor = 1 - strategy.slippageBps / 10000
  const costFactor = feeFactor * slippageFactor

  // Calculate rolling z-scores chronologically
  const zScores = computeRollingZScores(seriesA, seriesB, strategy.lookback)

  const trades: BacktestTrade[] = []
  let currentTrade: Partial<BacktestTrade> | null = null
  let capital = strategy.capitalAllocation

  const zMap = new Map(zScores.map((z) => [z.timestamp, z.value]))

  for (let i = 1; i < timestamps.length; i++) {
    const ts = timestamps[i]
    const prevTs = timestamps[i - 1]
    const z = zMap.get(prevTs) ?? null // use previous candle's z-score (no look-ahead)
    const priceA = pricesA[i]
    const priceB = pricesB[i]

    if (z === null) continue

    // No position — look for entry
    if (currentTrade === null) {
      if (strategy.type === 'MEAN_REVERSION') {
        // Enter when |z| > entryZ
        if (Math.abs(z) >= strategy.entryZ) {
          const direction = z > 0 ? 'LONG_B_SHORT_A' : 'LONG_A_SHORT_B'
          const capitalHalf = capital / 2
          currentTrade = {
            id: generateId(),
            entryTimestamp: ts,
            direction,
            entryPriceA: priceA / slippageFactor,
            entryPriceB: priceB / slippageFactor,
            entryZScore: z,
          }
        }
      } else if (strategy.type === 'BREAKOUT') {
        // Enter in direction of break when |z| > entryZ
        if (Math.abs(z) >= strategy.entryZ) {
          const direction = z > 0 ? 'LONG_A_SHORT_B' : 'LONG_B_SHORT_A'
          currentTrade = {
            id: generateId(),
            entryTimestamp: ts,
            direction,
            entryPriceA: priceA / slippageFactor,
            entryPriceB: priceB / slippageFactor,
            entryZScore: z,
          }
        }
      }
    } else {
      // In position — check for exit
      let exitReason: BacktestTrade['exitReason'] | null = null

      if (Math.abs(z) >= strategy.stopZ) {
        exitReason = 'STOP'
      } else if (Math.abs(z) <= strategy.exitZ) {
        exitReason = 'TARGET'
      }

      if (exitReason !== null) {
        const exitPriceA = priceA * slippageFactor
        const exitPriceB = priceB * slippageFactor

        const pnl = computePairPnl(
          currentTrade.direction!,
          currentTrade.entryPriceA!,
          currentTrade.entryPriceB!,
          exitPriceA,
          exitPriceB,
          strategy.capitalAllocation,
          strategy.hedgeRatio ?? 1,
          costFactor
        )

        const trade: BacktestTrade = {
          id: currentTrade.id!,
          entryTimestamp: currentTrade.entryTimestamp!,
          exitTimestamp: ts,
          direction: currentTrade.direction!,
          entryPriceA: currentTrade.entryPriceA!,
          entryPriceB: currentTrade.entryPriceB!,
          exitPriceA,
          exitPriceB,
          entryZScore: currentTrade.entryZScore!,
          exitZScore: z,
          pnl,
          pnlPct: pnl / strategy.capitalAllocation,
          exitReason,
        }
        trades.push(trade)
        capital += pnl
        currentTrade = null
      }
    }
  }

  // Close any open trade at end of data
  if (currentTrade !== null && timestamps.length > 0) {
    const lastIdx = timestamps.length - 1
    const exitPriceA = pricesA[lastIdx] * slippageFactor
    const exitPriceB = pricesB[lastIdx] * slippageFactor
    const pnl = computePairPnl(
      currentTrade.direction!,
      currentTrade.entryPriceA!,
      currentTrade.entryPriceB!,
      exitPriceA,
      exitPriceB,
      strategy.capitalAllocation,
      strategy.hedgeRatio ?? 1,
      costFactor
    )
    trades.push({
      id: currentTrade.id!,
      entryTimestamp: currentTrade.entryTimestamp!,
      exitTimestamp: timestamps[lastIdx],
      direction: currentTrade.direction!,
      entryPriceA: currentTrade.entryPriceA!,
      entryPriceB: currentTrade.entryPriceB!,
      exitPriceA,
      exitPriceB,
      entryZScore: currentTrade.entryZScore!,
      exitZScore: null,
      pnl,
      pnlPct: pnl / strategy.capitalAllocation,
      exitReason: 'END_OF_DATA',
    })
  }

  // Build equity curve
  const equityCurve = buildEquityCurve(trades, strategy.capitalAllocation, timestamps)

  // Calculate metrics
  const closedTrades = trades.filter((t) => t.exitTimestamp !== null)
  const totalPnl = closedTrades.reduce((s, t) => s + t.pnl, 0)
  const totalReturn = totalPnl / strategy.capitalAllocation

  const periodDays =
    timestamps.length >= 2
      ? (timestamps[timestamps.length - 1] - timestamps[0]) / (1000 * 60 * 60 * 24)
      : 0

  // Daily returns for Sharpe
  const dailyReturns = equityCurve.slice(1).map((p, i) => {
    const prev = equityCurve[i].equity
    return prev > 0 ? (p.equity - prev) / prev : 0
  })

  const pnls = closedTrades.map((t) => t.pnl)

  return {
    strategyId: strategy.id,
    totalReturn,
    annualizedReturn: calcAnnualizedReturn(totalReturn, periodDays),
    winRate: calcWinRate(trades),
    profitFactor: calcProfitFactor(trades),
    sharpe: calcSharpe(dailyReturns),
    maxDrawdown: calcMaxDrawdown(equityCurve),
    tradeCount: closedTrades.length,
    winCount: closedTrades.filter((t) => t.pnl > 0).length,
    lossCount: closedTrades.filter((t) => t.pnl <= 0).length,
    avgTradePnl: pnls.length > 0 ? pnls.reduce((s, v) => s + v, 0) / pnls.length : 0,
    bestTrade: pnls.length > 0 ? Math.max(...pnls) : 0,
    worstTrade: pnls.length > 0 ? Math.min(...pnls) : 0,
    trades,
    equityCurve,
    period: {
      start: timestamps[0] ?? 0,
      end: timestamps[timestamps.length - 1] ?? 0,
    },
    dataSource: DATA_SOURCE_LABEL,
    timeframe: strategy.timeframe,
    feesBps: strategy.feesBps,
    slippageBps: strategy.slippageBps,
  }
}

/**
 * Calculate rolling z-scores over rolling correlation values.
 * Uses 30-day rolling correlation with 30-period baseline window.
 */
function computeRollingZScores(
  seriesA: PriceSeries,
  seriesB: PriceSeries,
  window: number
): { timestamp: number; value: number }[] {
  const rolling = rollingCorrelation(seriesA, seriesB, window)
  const zScores: { timestamp: number; value: number }[] = []

  for (let i = window; i < rolling.length; i++) {
    const baseline = rolling.slice(0, i)
    const values = baseline.map((r) => r.value)
    const mu = values.reduce((s, v) => s + v, 0) / values.length
    const variance = values.reduce((s, v) => s + (v - mu) ** 2, 0) / (values.length - 1 || 1)
    const sigma = Math.sqrt(variance)
    if (sigma > 0) {
      const z = (rolling[i].value - mu) / sigma
      zScores.push({ timestamp: rolling[i].timestamp, value: z })
    }
  }

  return zScores
}

/**
 * Compute P&L for a pair trade.
 * Assumes equal capital allocation to each leg, adjusted by hedge ratio.
 */
function computePairPnl(
  direction: 'LONG_A_SHORT_B' | 'LONG_B_SHORT_A' | 'FLAT',
  entryA: number,
  entryB: number,
  exitA: number,
  exitB: number,
  capital: number,
  hedgeRatio: number,
  costFactor: number
): number {
  if (direction === 'FLAT') return 0

  const halfCapital = capital / 2
  const qtyA = halfCapital / entryA
  const qtyB = (halfCapital * hedgeRatio) / entryB

  if (direction === 'LONG_A_SHORT_B') {
    const longPnl = (exitA - entryA) * qtyA
    const shortPnl = (entryB - exitB) * qtyB
    return (longPnl + shortPnl) * costFactor
  } else {
    const longPnl = (exitB - entryB) * qtyB
    const shortPnl = (entryA - exitA) * qtyA
    return (longPnl + shortPnl) * costFactor
  }
}
