'use client'
import { useMemo, useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { SwissPanel, SwissButton, SwissMetric, SwissSectionLabel, SwissDivider, SwissStatus } from '@/components/swiss'
import { PriceComparisonChart } from '@/components/charts/PriceComparisonChart'
import { RollingCorrelationChart } from '@/components/charts/RollingCorrelationChart'
import { ZScoreChart } from '@/components/charts/ZScoreChart'
import { RelationshipHeader } from '@/components/domain/RelationshipHeader'
import { StrategyRuleCard } from '@/components/domain/StrategyRuleCard'
import { DEMO_SERIES } from '@/data/demoScenario'
import { ASSET_MAP, ROLLING_WINDOW } from '@/lib/constants'
import { calculateCorrelationStats } from '@/engine/correlation'
import { classifyRegime } from '@/engine/regime'
import { generateStrategy, estimateHedgeRatio } from '@/engine/strategy'
import { explainAnomaly } from '@/services/ai'
import { useLinkStore } from '@/services/persistence/store'
import type { RelationshipAnalysis, AIInterpretation, StrategyDefinition } from '@/types'
import { Sparkles, ArrowRight, ShieldAlert } from 'lucide-react'

export default function PairDetailPage() {
  const params = useParams()
  const router = useRouter()
  const pairParam = (params.pair as string) || 'BTC-NASDAQ'
  const [symbolA, symbolB] = pairParam.toUpperCase().split('-')

  const assetA = ASSET_MAP[symbolA] || { id: symbolA, symbol: symbolA, name: symbolA, category: 'crypto' }
  const assetB = ASSET_MAP[symbolB] || { id: symbolB, symbol: symbolB, name: symbolB, category: 'equity' }

  const seriesA = DEMO_SERIES[symbolA]
  const seriesB = DEMO_SERIES[symbolB]

  const {
    setCurrentAnalysis,
    setCurrentStrategy,
    addStrategy,
    addJournalEntry,
    currentInterpretation,
    setCurrentInterpretation,
  } = useLinkStore()

  const [aiLoading, setAiLoading] = useState(false)
  const [localStrategy, setLocalStrategy] = useState<StrategyDefinition | null>(null)

  // Calculate stats
  const analysis: RelationshipAnalysis | null = useMemo(() => {
    if (!seriesA || !seriesB) return null
    const stats = calculateCorrelationStats(seriesA, seriesB, ROLLING_WINDOW)
    const regime = classifyRegime(
      stats.currentCorrelation,
      stats.zScore,
      stats.rolling,
      stats.baselineCorrelation,
      stats.sampleSize
    )

    const dataQuality: RelationshipAnalysis['dataQuality'] =
      stats.sampleSize >= 100
        ? 'HIGH'
        : stats.sampleSize >= 50
        ? 'MEDIUM'
        : stats.sampleSize >= 20
        ? 'LOW'
        : 'INSUFFICIENT'

    return {
      assetA,
      assetB,
      currentCorrelation: stats.currentCorrelation,
      baselineCorrelation: stats.baselineCorrelation,
      correlationStdDev: stats.correlationStdDev,
      deviation:
        stats.currentCorrelation !== null && stats.baselineCorrelation !== null
          ? stats.currentCorrelation - stats.baselineCorrelation
          : null,
      zScore: stats.zScore,
      rollingCorrelation: stats.rolling,
      regime,
      sampleSize: stats.sampleSize,
      dataQuality,
      timestamp: Date.now(),
    }
  }, [seriesA, seriesB, symbolA, symbolB])

  // Sync to store
  useEffect(() => {
    if (analysis) {
      setCurrentAnalysis(analysis)
    }
  }, [analysis, setCurrentAnalysis])

  // Run AI explainer on load
  useEffect(() => {
    if (!analysis) return
    let isMounted = true
    setAiLoading(true)

    explainAnomaly(analysis, assetA.name, assetB.name)
      .then((interp) => {
        if (isMounted) {
          setCurrentInterpretation(interp)
          addJournalEntry({
            type: 'AI_INTERPRETATION',
            title: 'AI ANOMALY EXPLANATION',
            detail: interp.observation,
            pair: `${symbolA}-${symbolB}`,
            value: interp.regime,
            status: 'INFO',
          })
        }
      })
      .catch((err) => console.error('AI explanation error:', err))
      .finally(() => {
        if (isMounted) setAiLoading(false)
      })

    return () => {
      isMounted = false
    }
  }, [analysis?.zScore, symbolA, symbolB])

  if (!seriesA || !seriesB || !analysis) {
    return (
      <div className="p-12 text-center bg-white">
        <h2 className="text-xl font-black mb-2">INSUFFICIENT DATA</h2>
        <p className="text-sm text-[#999999] mb-4">
          Price series for pair {symbolA} / {symbolB} is not available in the demo universe.
        </p>
        <SwissButton onClick={() => router.push('/correlation')} variant="primary" size="md">
          RETURN TO LAB
        </SwissButton>
      </div>
    )
  }

  const handleGenerateStrategy = () => {
    const hedgeRatio = estimateHedgeRatio(
      seriesA.map((p) => p.price),
      seriesB.map((p) => p.price)
    )
    const strategy = generateStrategy({
      assetA: symbolA,
      assetB: symbolB,
      type: (analysis.zScore ?? 0) < 0 ? 'MEAN_REVERSION' : 'BREAKOUT',
      entryZ: 2.0,
      exitZ: 0.5,
      stopZ: 3.0,
      hedgeRatio: hedgeRatio ?? 1.0,
    })

    setLocalStrategy(strategy)
    setCurrentStrategy(strategy)
    addStrategy(strategy)

    addJournalEntry({
      type: 'STRATEGY_GENERATED',
      title: 'PAIR STRATEGY SYNTHESIZED',
      detail: `${strategy.name} with entry Z > 2.0σ, exit Z < 0.5σ`,
      pair: `${symbolA}-${symbolB}`,
      value: strategy.type,
      status: 'SUCCESS',
    })
  }

  return (
    <div className="bg-white">
      {/* Header section */}
      <div className="p-6 md:p-8 border-b-4 border-black">
        <RelationshipHeader assetA={symbolA} assetB={symbolB} analysis={analysis} />
      </div>

      {/* Main 2-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 border-b-2 border-black">
        {/* Left Column: Visual Analytics */}
        <div className="lg:col-span-7 p-6 border-r-0 lg:border-r-2 border-black space-y-8">
          <SwissSectionLabel number="01">STATISTICAL TIME-SERIES VISUALIZATIONS</SwissSectionLabel>

          {/* Chart 1: Price Comparison */}
          <div className="border-2 border-black p-4">
            <PriceComparisonChart
              seriesA={seriesA}
              seriesB={seriesB}
              labelA={symbolA}
              labelB={symbolB}
            />
          </div>

          {/* Chart 2: Rolling Correlation */}
          <div className="border-2 border-black p-4">
            <RollingCorrelationChart
              data={analysis.rollingCorrelation}
              baseline={analysis.baselineCorrelation}
              label={`${symbolA} / ${symbolB} — 30D ROLLING CORRELATION`}
            />
          </div>

          {/* Chart 3: Z-Score */}
          <div className="border-2 border-black p-4">
            <ZScoreChart rollingCorrelation={analysis.rollingCorrelation} />
          </div>
        </div>

        {/* Right Column: AI Interpretation & Strategy Factory */}
        <div className="lg:col-span-5 p-6 space-y-6 bg-white">
          <SwissSectionLabel number="02">QUANTITATIVE AI INTERPRETATION</SwissSectionLabel>

          {/* AI Output Card */}
          <div className="border-4 border-black p-6 bg-white">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-black">
              <span className="flex items-center gap-1.5 text-xs font-black tracking-widest uppercase">
                <Sparkles size={14} className="text-accent" />
                LINK ANALYSIS AGENT
              </span>
              <SwissStatus
                status={currentInterpretation?.confidence === 'HIGH' ? 'PASS' : 'INFO'}
                label={`CONFIDENCE: ${currentInterpretation?.confidence ?? 'CALCULATING'}`}
                size="sm"
              />
            </div>

            {aiLoading ? (
              <div className="py-8 text-center space-y-2">
                <div className="w-5 h-5 border-2 border-black border-t-transparent animate-spin mx-auto" />
                <p className="text-xs uppercase tracking-widest text-[#999999] font-mono">
                  Synthesizing statistical divergence...
                </p>
              </div>
            ) : (
              <div className="space-y-4 text-sm">
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">OBSERVATION</p>
                  <p className="font-semibold text-black mt-0.5 leading-relaxed">
                    {currentInterpretation?.observation}
                  </p>
                </div>

                <div>
                  <p className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">STATISTICAL EVIDENCE</p>
                  <p className="font-mono text-xs text-[#444444] mt-0.5 bg-[#F2F2F2] p-2 border border-[#E8E8E8]">
                    {currentInterpretation?.statisticalEvidence}
                  </p>
                </div>

                <div>
                  <p className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">STRATEGY HYPOTHESIS</p>
                  <p className="text-black mt-0.5 leading-relaxed">
                    {currentInterpretation?.strategyHypothesis}
                  </p>
                </div>

                <div className="border-l-2 border-accent pl-3 py-1">
                  <p className="text-[10px] uppercase tracking-widest text-accent font-bold flex items-center gap-1">
                    <ShieldAlert size={12} />
                    RISK FACTOR & DISCLAIMER
                  </p>
                  <p className="text-xs text-[#444444] mt-0.5">
                    {currentInterpretation?.risk}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Strategy Generation */}
          <div className="space-y-4">
            <SwissSectionLabel number="03">STRATEGY SYNTHESIS</SwissSectionLabel>
            {!localStrategy ? (
              <div className="border-2 border-black p-6 space-y-4">
                <p className="text-xs text-[#444444] leading-relaxed">
                  Convert this statistical anomaly into an executable market-neutral pair strategy with automated hedge ratio and z-score bounds.
                </p>
                <SwissButton onClick={handleGenerateStrategy} variant="primary" size="lg" className="w-full">
                  GENERATE STRATEGY
                </SwissButton>
              </div>
            ) : (
              <div className="space-y-4">
                <StrategyRuleCard
                  strategy={localStrategy}
                  onRunBacktest={() => router.push('/backtest')}
                />
                <SwissButton
                  onClick={() => router.push('/backtest')}
                  variant="primary"
                  size="lg"
                  className="w-full flex items-center justify-center gap-2"
                >
                  PROCEED TO BACKTEST
                  <ArrowRight size={16} />
                </SwissButton>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
