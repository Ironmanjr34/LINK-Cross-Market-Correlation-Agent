import type { BacktestTrade, EquityPoint } from '@/types'

const ANNUALIZATION_FACTOR = Math.sqrt(252)
const RISK_FREE_RATE = 0.045 // 4.5% annualized
const DAILY_RISK_FREE = RISK_FREE_RATE / 252

export function calcWinRate(trades: BacktestTrade[]): number {
  const closed = trades.filter((t) => t.exitTimestamp !== null)
  if (closed.length === 0) return 0
  const wins = closed.filter((t) => t.pnl > 0).length
  return wins / closed.length
}

export function calcProfitFactor(trades: BacktestTrade[]): number {
  const closed = trades.filter((t) => t.exitTimestamp !== null)
  const gains = closed.filter((t) => t.pnl > 0).reduce((s, t) => s + t.pnl, 0)
  const losses = Math.abs(closed.filter((t) => t.pnl < 0).reduce((s, t) => s + t.pnl, 0))
  if (losses === 0) return gains > 0 ? 999 : 0
  return gains / losses
}

export function calcMaxDrawdown(equityCurve: EquityPoint[]): number {
  if (equityCurve.length === 0) return 0
  let peak = equityCurve[0].equity
  let maxDD = 0
  for (const point of equityCurve) {
    if (point.equity > peak) peak = point.equity
    const dd = (peak - point.equity) / peak
    if (dd > maxDD) maxDD = dd
  }
  return maxDD
}

export function calcSharpe(dailyReturns: number[]): number {
  if (dailyReturns.length < 2) return 0
  const excess = dailyReturns.map((r) => r - DAILY_RISK_FREE)
  const mean = excess.reduce((s, v) => s + v, 0) / excess.length
  const variance = excess.reduce((s, v) => s + (v - mean) ** 2, 0) / (excess.length - 1)
  const stdDev = Math.sqrt(variance)
  if (stdDev === 0) return 0
  return (mean / stdDev) * ANNUALIZATION_FACTOR
}

export function calcAnnualizedReturn(totalReturn: number, days: number): number {
  if (days <= 0) return 0
  return Math.pow(1 + totalReturn, 365 / days) - 1
}

export function buildEquityCurve(
  trades: BacktestTrade[],
  initialCapital: number,
  timestamps: number[]
): EquityPoint[] {
  // Build a daily equity curve from trade P&L
  const curve: EquityPoint[] = []
  let equity = initialCapital
  let peak = equity

  // Group trades by exit timestamp
  const closedTrades = trades.filter((t) => t.exitTimestamp !== null && t.pnl !== undefined)

  for (const ts of timestamps) {
    // Apply P&L from trades that closed at or before this timestamp
    const tradesAtPoint = closedTrades.filter(
      (t) => t.exitTimestamp !== null && t.exitTimestamp <= ts
    )
    const totalPnl = tradesAtPoint.reduce((s, t) => s + t.pnl, 0)
    const pointEquity = initialCapital + totalPnl
    if (pointEquity > peak) peak = pointEquity
    const drawdown = peak > 0 ? (peak - pointEquity) / peak : 0
    curve.push({ timestamp: ts, equity: pointEquity, drawdown })
  }

  return curve
}
