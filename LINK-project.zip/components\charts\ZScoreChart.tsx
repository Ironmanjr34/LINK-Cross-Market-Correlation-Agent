'use client'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ReferenceArea,
} from 'recharts'
import type { CorrelationObservation } from '@/types'
import { formatDateShort } from '@/lib/formatters'

interface ZScoreChartProps {
  rollingCorrelation: CorrelationObservation[]
  window?: number
  height?: number
}

export function ZScoreChart({ rollingCorrelation, window = 30, height = 220 }: ZScoreChartProps) {
  const zScoreData: { timestamp: number; zScore: number }[] = []

  for (let i = window; i < rollingCorrelation.length; i++) {
    const baseline = rollingCorrelation.slice(0, i).map((r) => r.value)
    const mu = baseline.reduce((s, v) => s + v, 0) / baseline.length
    const variance = baseline.reduce((s, v) => s + (v - mu) ** 2, 0) / (baseline.length - 1 || 1)
    const sigma = Math.sqrt(variance)
    if (sigma > 0) {
      const z = (rollingCorrelation[i].value - mu) / sigma
      zScoreData.push({ timestamp: rollingCorrelation[i].timestamp, zScore: +z.toFixed(3) })
    }
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.[0]) return null
    const z = payload[0].value
    return (
      <div className="bg-white border-2 border-black p-3">
        <p className="text-[10px] uppercase tracking-widest text-[#999999] mb-1">
          {formatDateShort(label)}
        </p>
        <p className="text-sm font-bold mono-value">
          Z-SCORE: {z > 0 ? '+' : ''}{z?.toFixed(2)}σ
        </p>
      </div>
    )
  }

  return (
    <div>
      <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-2">
        CORRELATION Z-SCORE — STANDARD DEVIATIONS FROM BASELINE
      </p>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={zScoreData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid strokeDasharray="" stroke="rgba(0,0,0,0.06)" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(t) => formatDateShort(t)}
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
          />
          <YAxis
            ticks={[-3, -2, -1, 0, 1, 2, 3]}
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
            tickFormatter={(v) => `${v > 0 ? '+' : ''}${v}σ`}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceArea y1={2} y2={4} fill="rgba(255,48,0,0.06)" />
          <ReferenceArea y1={-4} y2={-2} fill="rgba(255,48,0,0.06)" />
          <ReferenceLine y={0} stroke="#000" strokeWidth={1.5} />
          <ReferenceLine
            y={2}
            stroke="#FF3000"
            strokeDasharray="4 4"
            strokeWidth={1}
            label={{ value: '+2σ', position: 'right', fontSize: 8, fill: '#FF3000', fontWeight: 700 }}
          />
          <ReferenceLine
            y={-2}
            stroke="#FF3000"
            strokeDasharray="4 4"
            strokeWidth={1}
            label={{ value: '-2σ', position: 'right', fontSize: 8, fill: '#FF3000', fontWeight: 700 }}
          />
          <ReferenceLine y={3} stroke="rgba(255,48,0,0.5)" strokeDasharray="2 2" strokeWidth={1} />
          <ReferenceLine y={-3} stroke="rgba(255,48,0,0.5)" strokeDasharray="2 2" strokeWidth={1} />
          <Line
            type="monotone"
            dataKey="zScore"
            stroke="#000000"
            dot={false}
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
