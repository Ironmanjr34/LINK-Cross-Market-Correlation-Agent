'use client'
import { useLinkStore } from '@/services/persistence/store'
import { usePaperTrading } from '@/hooks/usePaperTrading'
import { SwissButton, SwissMetric, SwissSectionLabel, SwissStatus, SwissTable } from '@/components/swiss'
import { formatCurrency, formatTimestamp } from '@/lib/formatters'
import type { PaperPosition } from '@/types'
import { useRouter } from 'next/navigation'

export default function PaperPage() {
  const router = useRouter()
  const { paperBalance, openPositions, closedPositions, closePosition } = usePaperTrading()
  const allPositions = useLinkStore((s) => s.paperPositions)
  const resetPaperTrading = useLinkStore((s) => s.resetPaperTrading)

  const totalPnl = closedPositions.reduce((s, p) => s + (p.pnl ?? 0), 0)

  const positionColumns = [
    {
      key: 'pair',
      header: 'PAIR',
      render: (p: PaperPosition) => (
        <span className="font-bold">
          {p.assetA} / {p.assetB}
        </span>
      ),
    },
    {
      key: 'direction',
      header: 'DIRECTION',
      render: (p: PaperPosition) => (
        <span className="text-[11px] uppercase tracking-widest font-mono">
          {p.direction.replace(/_/g, ' ')}
        </span>
      ),
    },
    {
      key: 'entry',
      header: 'ENTRY TIME',
      render: (p: PaperPosition) => (
        <span className="mono-value text-[11px]">{formatTimestamp(p.entryTimestamp)}</span>
      ),
    },
    {
      key: 'capital',
      header: 'CAPITAL',
      render: (p: PaperPosition) => (
        <span className="mono-value">{formatCurrency(p.capitalAllocated)}</span>
      ),
    },
    {
      key: 'status',
      header: 'STATUS',
      render: (p: PaperPosition) => (
        <SwissStatus status={p.status === 'OPEN' ? 'LIVE' : 'INFO'} label={p.status} size="sm" />
      ),
    },
    {
      key: 'pnl',
      header: 'REALIZED P&L',
      render: (p: PaperPosition) =>
        p.pnl !== undefined ? (
          <span className={`mono-value font-bold ${p.pnl >= 0 ? 'text-black' : 'text-accent'}`}>
            {p.pnl >= 0 ? '+' : ''}
            {formatCurrency(p.pnl, 2)}
          </span>
        ) : (
          <span className="text-[#999999] text-xs font-mono">IN POSITION</span>
        ),
    },
    {
      key: 'action',
      header: 'ACTION',
      render: (p: PaperPosition) =>
        p.status === 'OPEN' ? (
          <SwissButton
            size="sm"
            variant="secondary"
            onClick={() => closePosition(p.id, 'MANUAL CLOSE')}
          >
            CLOSE
          </SwissButton>
        ) : null,
    },
  ]

  return (
    <div>
      <div className="border-b-4 border-black px-6 py-8 bg-white">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-widest text-[#999999] mb-2 font-bold">07 / PAPER TRADING</p>
            <h1 className="text-3xl md:text-5xl font-black tracking-tighter">PAPER TRADING</h1>
          </div>
          <div className="flex items-center gap-3">
            <SwissStatus status="DEMO" label="PAPER MODE" size="md" />
            <SwissStatus status="INFO" label="SIMULATED EXECUTION" size="md" />
            {allPositions.length > 0 && (
              <SwissButton onClick={resetPaperTrading} variant="ghost" size="sm">
                RESET STATE
              </SwissButton>
            )}
          </div>
        </div>
        <p className="text-accent font-bold mt-2 text-xs uppercase tracking-widest">
          SIMULATED EXECUTION — NO REAL FUNDS — RECORDED TO IMMUTABLE LOCAL JOURNAL
        </p>
      </div>

      {/* Balance */}
      <div className="grid grid-cols-2 md:grid-cols-4 border-b-2 border-black bg-white">
        <div className="p-6 border-r-2 border-black">
          <SwissMetric label="PAPER BALANCE" value={formatCurrency(paperBalance)} size="md" />
        </div>
        <div className="p-6 border-r-2 border-black">
          <SwissMetric label="OPEN POSITIONS" value={openPositions.length} size="md" />
        </div>
        <div className="p-6 border-r-2 border-black">
          <SwissMetric label="CLOSED POSITIONS" value={closedPositions.length} size="md" />
        </div>
        <div className="p-6">
          <SwissMetric
            label="REALIZED P&L"
            value={formatCurrency(totalPnl, 2)}
            size="md"
            accent={totalPnl < 0}
          />
        </div>
      </div>

      {/* No positions CTA */}
      {allPositions.length === 0 && (
        <div className="p-6 border-b-2 border-black bg-white">
          <div className="border-2 border-[#E8E8E8] p-8 text-center">
            <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-2">
              NO ACTIVE PAPER POSITIONS
            </p>
            <p className="text-sm text-[#444444] mb-4 max-w-md mx-auto">
              Follow the complete quantitative loop to activate a paper position: Anomaly &rarr; Strategy &rarr; Backtest &rarr; Risk Check &rarr; Paper Trade.
            </p>
            <SwissButton onClick={() => router.push('/anomalies')} variant="primary" size="md">
              VIEW ANOMALIES &rarr;
            </SwissButton>
          </div>
        </div>
      )}

      {/* Positions table */}
      {allPositions.length > 0 && (
        <div className="p-6 bg-white">
          <SwissSectionLabel className="mb-4">ACTIVE & HISTORICAL PAPER ORDERS</SwissSectionLabel>
          <SwissTable
            columns={positionColumns}
            data={allPositions}
            keyExtractor={(p) => p.id}
            emptyMessage="NO POSITIONS RECORDED"
          />
        </div>
      )}

      <div className="border-t-2 border-black px-6 py-4 bg-[#F2F2F2]">
        <p className="text-[10px] text-[#999999] uppercase tracking-widest">
          PAPER SIMULATOR ACTIVE — DETERMINISTIC PRICING ON DEMO SERIES — RISK CONSTRAINTS STRICTLY ENFORCED
        </p>
      </div>
    </div>
  )
}
