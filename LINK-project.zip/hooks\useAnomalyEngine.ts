import { useMemo } from 'react'
import { calculateCorrelationStats } from '@/engine/correlation'
import { classifyRegime } from '@/engine/regime'
import { detectAnomalies } from '@/engine/anomaly'
import { DEMO_SERIES, DEFAULT_SCAN_PAIRS } from '@/data/demoScenario'
import { ASSET_MAP, ROLLING_WINDOW } from '@/lib/constants'
import type { ScanResult, RelationshipAnalysis } from '@/types'

export function useAnomalyScan(): ScanResult {
  return useMemo(() => {
    const analyses: { assetA: typeof ASSET_MAP[string]; assetB: typeof ASSET_MAP[string]; analysis: RelationshipAnalysis }[] = []

    for (const [idA, idB] of DEFAULT_SCAN_PAIRS) {
      const assetA = ASSET_MAP[idA]
      const assetB = ASSET_MAP[idB]
      if (!assetA || !assetB) continue

      const seriesA = DEMO_SERIES[idA]
      const seriesB = DEMO_SERIES[idB]
      if (!seriesA || !seriesB) continue

      const stats = calculateCorrelationStats(seriesA, seriesB, ROLLING_WINDOW)

      const dataQuality: RelationshipAnalysis['dataQuality'] =
        stats.sampleSize >= 100 ? 'HIGH' : stats.sampleSize >= 50 ? 'MEDIUM' : stats.sampleSize >= 20 ? 'LOW' : 'INSUFFICIENT'

      const regime = classifyRegime(
        stats.currentCorrelation,
        stats.zScore,
        stats.rolling,
        stats.baselineCorrelation,
        stats.sampleSize
      )

      analyses.push({
        assetA,
        assetB,
        analysis: {
          assetA,
          assetB,
          currentCorrelation: stats.currentCorrelation,
          baselineCorrelation: stats.baselineCorrelation,
          correlationStdDev: stats.correlationStdDev,
          deviation:
            stats.currentCorrelation !== null && stats.baselineCorrelation !== null
              ? stats.currentCorrelation - stats.baselineCorrelation
              : null,
          zScore: stats.zScore,
          rollingCorrelation: stats.rolling,
          regime,
          sampleSize: stats.sampleSize,
          dataQuality,
          timestamp: Date.now(),
        },
      })
    }

    const { anomalies, watchlist } = detectAnomalies(analyses)
    const normalCount = analyses.length - anomalies.length - watchlist.length

    return {
      totalPairs: analyses.length,
      anomalies,
      watchlist,
      normal: normalCount,
      scannedAt: Date.now(),
    }
  }, [])
}
