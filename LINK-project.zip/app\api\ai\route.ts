import { NextRequest, NextResponse } from 'next/server'
import type { AIInterpretation } from '@/types'

const GEMINI_MODEL = 'gemini-3.8-flash'
const API_KEY = process.env.GEMINI_API_KEY

/**
 * Server-side AI proxy.
 * Routes AI requests to Gemini 3.8 Flash.
 * API key is never exposed to the client.
 */
export async function POST(request: NextRequest) {
  const body = await request.json()
  const { type, payload } = body as { type: string; payload: Record<string, unknown> }

  // If no API key, return demo response
  if (!API_KEY) {
    return NextResponse.json({
      success: true,
      demo: true,
      data: getDemoResponse(type, payload),
    })
  }

  try {
    const prompt = buildPrompt(type, payload)
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.3,
            responseMimeType: 'application/json',
          },
        }),
      }
    )

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const result = await response.json()
    const text = result.candidates?.[0]?.content?.parts?.[0]?.text ?? '{}'
    
    let parsed: Record<string, unknown> = {}
    try {
      parsed = JSON.parse(text)
    } catch {
      // If JSON parse fails, return as text
      return NextResponse.json({ success: true, text, demo: false })
    }

    return NextResponse.json({ success: true, data: parsed, demo: false })
  } catch (error) {
    console.error('AI API error:', error)
    // Graceful fallback to demo
    return NextResponse.json({
      success: true,
      demo: true,
      data: getDemoResponse(type, payload),
    })
  }
}

function buildPrompt(type: string, payload: Record<string, unknown>): string {
  switch (type) {
    case 'parse_intent':
      return `You are a quantitative trading assistant. Parse this user query into a structured strategy configuration.

User query: "${payload.query}"

Available assets: BTC, ETH, SOL, BNB, NASDAQ, SPX, TECH, GROWTH, GOLD, OIL, DXY, USDT
Strategy types: MEAN_REVERSION, BREAKOUT, RELATIVE_STRENGTH, CROSS_MARKET_ROTATION

Return JSON with exactly these fields:
{
  "assetA": string,
  "assetB": string,
  "type": "MEAN_REVERSION" | "BREAKOUT" | "RELATIVE_STRENGTH" | "CROSS_MARKET_ROTATION",
  "lookback": number (days, 7-90),
  "entryZ": number (1.5-3.0),
  "exitZ": number (0.0-1.0),
  "stopZ": number (2.5-4.0),
  "confidence": number (0-1)
}

Return only valid JSON.`

    case 'explain_anomaly':
      return `You are a quantitative research analyst. Explain this cross-market correlation anomaly in structured format.

Data:
- Asset A: ${payload.assetA}
- Asset B: ${payload.assetB}
- Current correlation: ${payload.currentCorrelation}
- Baseline correlation: ${payload.baselineCorrelation}
- Z-score: ${payload.zScore}\u03c3
- Regime: ${payload.regime}
- Sample size: ${payload.sampleSize} observations

IMPORTANT RULES:
1. Never fabricate specific macro events as confirmed causes.
2. If you don't know the cause, say "CAUSE NOT VERIFIED".
3. Distinguish correlation from causation.
4. Be concise and quantitative.
5. Never imply guaranteed reversals.

Return JSON:
{
  "observation": string (1-2 sentences describing what the data shows),
  "statisticalEvidence": string (the key numbers),
  "regime": string (one of the regime classifications),
  "strategyHypothesis": string (what strategy could be investigated),
  "risk": string (risks and limitations),
  "nextAction": "RUN BACKTEST" | "COLLECT MORE DATA" | "MONITOR" | "INVESTIGATE",
  "confidence": "HIGH" | "MEDIUM" | "LOW",
  "causeVerified": false
}

Return only valid JSON.`

    case 'generate_strategy':
      return `You are a quantitative strategy builder. Generate a structured trading strategy configuration.

Context:
- Asset A: ${payload.assetA}
- Asset B: ${payload.assetB}
- Strategy type: ${payload.type}
- Current z-score: ${payload.zScore}
- Current correlation: ${payload.currentCorrelation}

Return JSON:
{
  "name": string,
  "description": string (1-2 sentences),
  "entryZ": number,
  "exitZ": number,
  "stopZ": number,
  "positionMode": "pair" | "directional",
  "rebalanceFrequency": "Daily" | "Weekly" | "Signal",
  "rationale": string
}

Return only valid JSON.`

    case 'summarize_regime':
      return `Summarize the current market regime based on these cross-asset correlations.

Data: ${JSON.stringify(payload)}

Return JSON:
{
  "regime": "RISK_ON" | "RISK_OFF" | "NEUTRAL" | "TRANSITIONING",
  "confidence": number (0-100),
  "summary": string (2-3 sentences),
  "signals": string[] (list of key observations)
}

Return only valid JSON.`

    default:
      return `Analyze this data and return a JSON response: ${JSON.stringify(payload)}`
  }
}

function getDemoResponse(type: string, payload: Record<string, unknown>): Record<string, unknown> {
  switch (type) {
    case 'parse_intent':
      return {
        assetA: 'BTC',
        assetB: 'NASDAQ',
        type: 'MEAN_REVERSION',
        lookback: 30,
        entryZ: 2.0,
        exitZ: 0.5,
        stopZ: 3.0,
        confidence: 0.88,
      }
    case 'explain_anomaly': {
      const assetA = (payload.assetA as string) ?? 'Asset A'
      const assetB = (payload.assetB as string) ?? 'Asset B'
      const currentCorr = payload.currentCorrelation as number ?? 0.18
      const baselineCorr = payload.baselineCorrelation as number ?? 0.72
      const zScore = payload.zScore as number ?? -2.7
      const sampleSize = payload.sampleSize as number ?? 90
      return {
        observation: `${assetA} and ${assetB} historically show a ${baselineCorr > 0 ? 'positive' : 'negative'} relationship. The current rolling correlation has ${zScore < 0 ? 'fallen' : 'risen'} sharply from ${baselineCorr.toFixed(2)} to ${currentCorr.toFixed(2)}.`,
        statisticalEvidence: `Current correlation: ${currentCorr.toFixed(2)} | Baseline: ${baselineCorr.toFixed(2)} | Z-score: ${zScore.toFixed(1)}\u03c3 | Sample: ${sampleSize} observations`,
        regime: payload.regime ?? 'DIVERGENCE',
        strategyHypothesis: `A mean-reversion pair framework could be investigated. The hypothesis is that the ${assetA}/${assetB} relationship may normalize toward its historical baseline. This is a hypothesis, not a guaranteed reversal.`,
        risk: 'Relationship instability remains elevated. The divergence may continue or deepen before normalizing. CAUSE NOT VERIFIED — no confirmed macro catalyst identified in demo mode.',
        nextAction: 'RUN BACKTEST',
        confidence: 'MEDIUM',
        causeVerified: false,
      } as Record<string, unknown>
    }
    case 'generate_strategy':
      return {
        name: `Mean Reversion — ${payload.assetA} / ${payload.assetB}`,
        description: 'Enter when correlation z-score exceeds threshold, exit when relationship normalizes.',
        entryZ: 2.0,
        exitZ: 0.5,
        stopZ: 3.0,
        positionMode: 'pair',
        rebalanceFrequency: 'Daily',
        rationale: 'Historical mean reversion tendency in this pair relationship.',
      }
    case 'summarize_regime':
      return {
        regime: 'RISK_OFF',
        confidence: 72,
        summary: 'Cross-asset relationships suggest a risk-off environment. Crypto-equity correlation has weakened materially.',
        signals: [
          'BTC/NASDAQ correlation below historical mean',
          'DXY showing negative correlation with risk assets',
          'Gold correlation with equities normalizing',
        ],
      }
    default:
      return { message: 'Demo response', demo: true }
  }
}
