'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { SwissButton, SwissMetric } from '@/components/swiss'
import { AnomalyCard } from '@/components/domain/AnomalyCard'
import { useAnomalyScan } from '@/hooks/useAnomalyEngine'
import { useLinkStore } from '@/services/persistence/store'

export default function AnomaliesPage() {
  const router = useRouter()
  const scanResult = useAnomalyScan()
  const { addJournalEntry } = useLinkStore()
  const [filter, setFilter] = useState<'ALL' | 'ANOMALY' | 'WATCHLIST'>('ALL')

  const allItems = [
    ...scanResult.anomalies.map((a) => ({ ...a, _type: 'ANOMALY' as const })),
    ...scanResult.watchlist.map((a) => ({ ...a, _type: 'WATCHLIST' as const })),
  ]

  const filtered =
    filter === 'ALL'
      ? allItems
      : filter === 'ANOMALY'
      ? allItems.filter((a) => a._type === 'ANOMALY')
      : allItems.filter((a) => a._type === 'WATCHLIST')

  return (
    <div>
      {/* Header */}
      <div className="border-b-4 border-black px-6 py-8">
        <p className="text-[11px] uppercase tracking-widest text-[#999999] mb-2 font-bold">03 / ANOMALY DISCOVERY</p>
        <h1 className="text-3xl md:text-5xl font-black tracking-tighter">ANOMALY FEED</h1>
        <p className="text-[#444444] mt-2 text-sm">
          Unusual cross-market relationship breaks ranked by statistical deviation and correlation break severity.
        </p>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-3 border-b-2 border-black">
        <div className="p-6 border-r-2 border-black">
          <SwissMetric label="TOTAL PAIRS" value={scanResult.totalPairs} size="md" />
        </div>
        <div className="p-6 border-r-2 border-black">
          <SwissMetric
            label="ANOMALIES"
            value={scanResult.anomalies.length}
            size="md"
            accent={scanResult.anomalies.length > 0}
          />
        </div>
        <div className="p-6">
          <SwissMetric label="WATCHLIST" value={scanResult.watchlist.length} size="md" />
        </div>
      </div>

      {/* Filters */}
      <div className="border-b-2 border-black px-6 py-3 flex items-center gap-2 bg-white">
        {(['ALL', 'ANOMALY', 'WATCHLIST'] as const).map((f) => (
          <SwissButton
            key={f}
            onClick={() => setFilter(f)}
            variant={filter === f ? 'primary' : 'secondary'}
            size="sm"
          >
            {f}
          </SwissButton>
        ))}
        <span className="ml-auto text-[11px] text-[#999999] uppercase tracking-widest font-mono">
          {filtered.length} PAIRS
        </span>
      </div>

      {/* List */}
      <div className="p-6">
        {filtered.length === 0 ? (
          <div className="border-2 border-[#E8E8E8] p-8 text-center">
            <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold">
              NO SIGNIFICANT RELATIONSHIP BREAKS
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((item, i) => (
              <AnomalyCard
                key={item.id}
                anomaly={item}
                index={i}
                onClick={() => {
                  addJournalEntry({
                    type: 'PAIR_OPENED',
                    title: 'PAIR OPENED',
                    detail: `${item.assetA.symbol} / ${item.assetB.symbol}`,
                    pair: `${item.assetA.id}-${item.assetB.id}`,
                    status: 'INFO',
                  })
                  router.push(`/relationship/${item.assetA.id}-${item.assetB.id}`)
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Methodology note */}
      <div className="border-t-2 border-black px-6 py-4 bg-[#F2F2F2]">
        <p className="text-[10px] text-[#999999] uppercase tracking-widest">
          ANOMALY SCORE = |Z-SCORE| × RELATIONSHIP STRENGTH × DATA QUALITY FACTOR
          — CALCULATED ON DEMO DATA — NOT FINANCIAL ADVICE
        </p>
      </div>
    </div>
  )
}
