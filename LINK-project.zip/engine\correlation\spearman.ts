import { pearsonCorrelation } from './pearson'

function rankArray(arr: number[]): number[] {
  const sorted = [...arr].map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v)
  const ranks = new Array(arr.length).fill(0)
  let i = 0
  while (i < sorted.length) {
    let j = i
    // Find tied values
    while (j < sorted.length - 1 && sorted[j].v === sorted[j + 1].v) j++
    const avgRank = (i + j) / 2 + 1 // 1-indexed
    for (let k = i; k <= j; k++) {
      ranks[sorted[k].i] = avgRank
    }
    i = j + 1
  }
  return ranks
}

/**
 * Spearman rank correlation coefficient.
 * Converts both arrays to ranks then computes Pearson on ranks.
 */
export function spearmanCorrelation(x: number[], y: number[]): number | null {
  if (x.length !== y.length || x.length === 0) return null
  return pearsonCorrelation(rankArray(x), rankArray(y))
}
