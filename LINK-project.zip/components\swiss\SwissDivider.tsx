import { cn } from '@/lib/utils'

interface SwissDividerProps {
  orientation?: 'horizontal' | 'vertical'
  weight?: 1 | 2 | 4
  className?: string
}

export function SwissDivider({
  orientation = 'horizontal',
  weight = 1,
  className,
}: SwissDividerProps) {
  if (orientation === 'vertical') {
    return (
      <div
        className={cn(
          'self-stretch bg-black',
          weight === 1 ? 'w-px' : weight === 2 ? 'w-0.5' : 'w-1',
          className
        )}
      />
    )
  }
  return (
    <hr
      className={cn(
        'border-0 bg-black',
        weight === 1 ? 'h-px' : weight === 2 ? 'h-0.5' : 'h-1',
        className
      )}
    />
  )
}
