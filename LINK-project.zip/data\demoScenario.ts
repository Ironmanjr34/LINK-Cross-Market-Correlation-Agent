import { mulberry32 } from '@/lib/utils'
import type { PriceSeries, Asset } from '@/types'
import { DEMO_ASSETS } from '@/lib/constants'

/**
 * Generate a realistic-looking price series using seeded random walk.
 * Uses geometric Brownian motion simulation.
 *
 * @param seed - PRNG seed for determinism
 * @param days - number of days to generate
 * @param startPrice - initial price
 * @param dailyDrift - expected daily return (annualized drift / 252)
 * @param dailyVol - daily volatility
 * @param startDate - start timestamp
 */
function generatePriceSeries(
  seed: number,
  days: number,
  startPrice: number,
  dailyDrift: number,
  dailyVol: number,
  startDate: Date
): PriceSeries {
  const rng = mulberry32(seed)
  const series: PriceSeries = []
  let price = startPrice
  const msPerDay = 24 * 60 * 60 * 1000

  for (let i = 0; i < days; i++) {
    const timestamp = startDate.getTime() + i * msPerDay
    series.push({ timestamp, price })

    // Box-Muller transform for normal distribution
    const u1 = rng()
    const u2 = rng()
    const z = Math.sqrt(-2 * Math.log(Math.max(u1, 1e-10))) * Math.cos(2 * Math.PI * u2)

    // Geometric Brownian Motion step
    price = price * Math.exp(dailyDrift - 0.5 * dailyVol * dailyVol + dailyVol * z)
    price = Math.max(price, 0.01) // floor at 0.01
  }

  return series
}

/**
 * Generate correlated price series.
 * Uses Cholesky decomposition of 2x2 correlation matrix.
 */
function generateCorrelatedSeries(
  seedA: number,
  seedB: number,
  days: number,
  startPriceA: number,
  startPriceB: number,
  dailyVolA: number,
  dailyVolB: number,
  targetCorrelation: number,
  startDate: Date
): { seriesA: PriceSeries; seriesB: PriceSeries } {
  const rngA = mulberry32(seedA)
  const rngB = mulberry32(seedB)

  const boxMuller = (rng: () => number) => {
    const u1 = rng()
    const u2 = rng()
    return Math.sqrt(-2 * Math.log(Math.max(u1, 1e-10))) * Math.cos(2 * Math.PI * u2)
  }

  const seriesA: PriceSeries = []
  const seriesB: PriceSeries = []
  let priceA = startPriceA
  let priceB = startPriceB
  const msPerDay = 24 * 60 * 60 * 1000

  // Cholesky: L11=1, L21=rho, L22=sqrt(1-rho^2)
  const rho = targetCorrelation
  const L22 = Math.sqrt(Math.max(1 - rho * rho, 0))

  const driftA = 0.0001 // slight upward bias
  const driftB = 0.0001

  for (let i = 0; i < days; i++) {
    const timestamp = startDate.getTime() + i * msPerDay
    seriesA.push({ timestamp, price: priceA })
    seriesB.push({ timestamp, price: priceB })

    const z1 = boxMuller(rngA)
    const z2 = boxMuller(rngB)

    // Correlated normals
    const zA = z1
    const zB = rho * z1 + L22 * z2

    priceA = priceA * Math.exp(driftA - 0.5 * dailyVolA ** 2 + dailyVolA * zA)
    priceB = priceB * Math.exp(driftB - 0.5 * dailyVolB ** 2 + dailyVolB * zB)

    priceA = Math.max(priceA, 0.01)
    priceB = Math.max(priceB, 0.01)
  }

  return { seriesA, seriesB }
}

// ============================================================
// DEMO SCENARIO: BTC / NASDAQ Correlation Divergence
//
// Phase 1 (Days 0-89):   Normal regime, correlation ~0.72
// Phase 2 (Days 90-119): Divergence, correlation drops to ~0.18
// Phase 3 (Days 120-179): Recovery, correlation recovers toward 0.72
// ============================================================

const START_DATE = new Date('2025-01-01T00:00:00Z')
const SEED_BTC = 0xdeadbeef
const SEED_NASDAQ = 0xcafebabe
const SEED_ETH = 0xf00dcafe
const SEED_GOLD = 0xbeefdead
const SEED_SOL = 0x12345678
const SEED_DXY = 0xabcdef01

function buildBtcNasdaqScenario(): { btc: PriceSeries; nasdaq: PriceSeries } {
  const totalDays = 180
  const msPerDay = 24 * 60 * 60 * 1000

  // Phase 1: 90 days, high correlation 0.72
  const phase1 = generateCorrelatedSeries(
    SEED_BTC,
    SEED_NASDAQ,
    90,
    112000, // BTC start price
    21000,  // NASDAQ start
    0.035,  // BTC daily vol ~3.5%
    0.012,  // NASDAQ daily vol ~1.2%
    0.72,
    START_DATE
  )

  // Phase 2: 30 days divergence — BTC corrects, NASDAQ stable
  const phase2StartDate = new Date(START_DATE.getTime() + 90 * msPerDay)
  const phase2 = generateCorrelatedSeries(
    SEED_BTC + 1,
    SEED_NASDAQ + 1,
    30,
    phase1.seriesA[phase1.seriesA.length - 1].price,
    phase1.seriesB[phase1.seriesB.length - 1].price,
    0.04,   // Higher BTC vol during divergence
    0.012,
    0.15,   // Very low correlation during divergence
    phase2StartDate
  )

  // Phase 3: 60 days recovery
  const phase3StartDate = new Date(START_DATE.getTime() + 120 * msPerDay)
  const phase3 = generateCorrelatedSeries(
    SEED_BTC + 2,
    SEED_NASDAQ + 2,
    60,
    phase2.seriesA[phase2.seriesA.length - 1].price,
    phase2.seriesB[phase2.seriesB.length - 1].price,
    0.03,
    0.012,
    0.65,   // Recovering correlation
    phase3StartDate
  )

  const btc = [...phase1.seriesA, ...phase2.seriesA, ...phase3.seriesA]
  const nasdaq = [...phase1.seriesB, ...phase2.seriesB, ...phase3.seriesB]

  return { btc, nasdaq }
}

// ---- Build all demo series ----

export const { btc: BTC_SERIES, nasdaq: NASDAQ_SERIES } = buildBtcNasdaqScenario()

export const ETH_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_ETH,
  SEED_BTC,
  180,
  3500,
  BTC_SERIES[0].price,
  0.038,
  0.035,
  0.84,
  START_DATE
).seriesA

export const SOL_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_SOL,
  SEED_BTC,
  180,
  180,
  BTC_SERIES[0].price,
  0.05,
  0.035,
  0.75,
  START_DATE
).seriesA

export const GOLD_SERIES: PriceSeries = generatePriceSeries(
  SEED_GOLD,
  180,
  2650,
  0.00005,
  0.008,
  START_DATE
)

export const DXY_SERIES: PriceSeries = generatePriceSeries(
  SEED_DXY,
  180,
  104.5,
  -0.00003,
  0.005,
  START_DATE
)

export const TECH_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_NASDAQ + 10,
  SEED_NASDAQ,
  180,
  19500,
  NASDAQ_SERIES[0].price,
  0.014,
  0.012,
  0.91,
  START_DATE
).seriesA

export const GROWTH_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_NASDAQ + 20,
  SEED_NASDAQ,
  180,
  15200,
  NASDAQ_SERIES[0].price,
  0.016,
  0.012,
  0.85,
  START_DATE
).seriesA

export const SPX_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_NASDAQ + 30,
  SEED_NASDAQ,
  180,
  5800,
  NASDAQ_SERIES[0].price,
  0.011,
  0.012,
  0.93,
  START_DATE
).seriesA

export const BNB_SERIES: PriceSeries = generateCorrelatedSeries(
  SEED_BTC + 100,
  SEED_BTC,
  180,
  680,
  BTC_SERIES[0].price,
  0.04,
  0.035,
  0.78,
  START_DATE
).seriesA

export const OIL_SERIES: PriceSeries = generatePriceSeries(
  SEED_GOLD + 1,
  180,
  78.5,
  0.00002,
  0.018,
  START_DATE
)

export const USDT_SERIES: PriceSeries = generatePriceSeries(
  SEED_DXY + 1,
  180,
  4.35,
  -0.00002,
  0.004,
  START_DATE
)

/**
 * All demo series by asset ID.
 */
export const DEMO_SERIES: Record<string, PriceSeries> = {
  BTC: BTC_SERIES,
  ETH: ETH_SERIES,
  SOL: SOL_SERIES,
  BNB: BNB_SERIES,
  NASDAQ: NASDAQ_SERIES,
  SPX: SPX_SERIES,
  TECH: TECH_SERIES,
  GROWTH: GROWTH_SERIES,
  GOLD: GOLD_SERIES,
  OIL: OIL_SERIES,
  DXY: DXY_SERIES,
  USDT: USDT_SERIES,
}

/**
 * Pairs to scan by default.
 */
export const DEFAULT_SCAN_PAIRS: Array<[string, string]> = [
  ['BTC', 'NASDAQ'],
  ['BTC', 'ETH'],
  ['BTC', 'GOLD'],
  ['BTC', 'DXY'],
  ['BTC', 'TECH'],
  ['ETH', 'NASDAQ'],
  ['ETH', 'TECH'],
  ['SOL', 'NASDAQ'],
  ['SOL', 'BTC'],
  ['GOLD', 'DXY'],
  ['NASDAQ', 'TECH'],
  ['NASDAQ', 'GOLD'],
]
