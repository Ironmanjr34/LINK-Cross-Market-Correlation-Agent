const http = require('http')

const routes = [
  '/',
  '/correlation',
  '/anomalies',
  '/relationship/BTC-NASDAQ',
  '/strategies',
  '/backtest',
  '/paper',
  '/journal',
]

function checkRoute(path) {
  return new Promise((resolve) => {
    http.get('http://localhost:3000' + path, (res) => {
      let data = ''
      res.on('data', (c) => (data += c))
      res.on('end', () => {
        resolve({ path, status: res.statusCode, length: data.length, data })
      })
    }).on('error', (err) => resolve({ path, error: err.message }))
  })
}

async function run() {
  console.log('Testing server routes on http://localhost:3000...')
  for (const r of routes) {
    const res = await checkRoute(r)
    if (res.status === 200) {
      console.log(`✓ ${r.padEnd(26)} -> 200 OK (${res.length} bytes)`)
    } else {
      console.error(`✗ ${r.padEnd(26)} -> Status: ${res.status || res.error}`)
    }
  }

  // Check CSS assets from home
  const home = await checkRoute('/')
  const cssMatches = home.data.match(/href="(\/_next\/static\/css\/[^"]+)"/g)
  if (cssMatches) {
    for (const m of cssMatches) {
      const url = m.replace('href="', '').replace('"', '')
      const cssRes = await checkRoute(url)
      console.log(`✓ CSS Asset ${url} -> Status: ${cssRes.status}`)
    }
  }
}

run()
