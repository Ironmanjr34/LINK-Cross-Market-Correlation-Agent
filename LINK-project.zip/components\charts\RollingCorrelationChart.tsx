'use client'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts'
import type { CorrelationObservation } from '@/types'
import { formatDateShort, formatCorrelation } from '@/lib/formatters'

interface RollingCorrelationChartProps {
  data: CorrelationObservation[]
  baseline?: number | null
  height?: number
  label?: string
}

export function RollingCorrelationChart({
  data,
  baseline,
  height = 220,
  label = 'ROLLING CORRELATION',
}: RollingCorrelationChartProps) {
  const chartData = data.map((d) => ({
    timestamp: d.timestamp,
    correlation: +d.value.toFixed(4),
  }))

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.[0]) return null
    return (
      <div className="bg-white border-2 border-black p-3">
        <p className="text-label uppercase tracking-widest text-gray-mid mb-1">
          {formatDateShort(label)}
        </p>
        <p className="text-sm font-bold mono-value">
          CORRELATION: {formatCorrelation(payload[0].value)}
        </p>
      </div>
    )
  }

  return (
    <div>
      <p className="text-label uppercase tracking-widest text-gray-mid mb-2">{label}</p>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={chartData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid strokeDasharray="" stroke="rgba(0,0,0,0.06)" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(t) => formatDateShort(t)}
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
          />
          <YAxis
            domain={[-1, 1]}
            ticks={[-1, -0.5, 0, 0.5, 1]}
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
            tickFormatter={(v) => v.toFixed(1)}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={0} stroke="#000" strokeWidth={1.5} />
          {baseline !== undefined && baseline !== null && (
            <ReferenceLine
              y={baseline}
              stroke="#FF3000"
              strokeDasharray="6 3"
              strokeWidth={1.5}
              label={{ value: 'BASELINE', position: 'right', fontSize: 8, fill: '#FF3000', fontWeight: 700 }}
            />
          )}
          <ReferenceLine y={1} stroke="rgba(0,0,0,0.15)" strokeDasharray="3 3" />
          <ReferenceLine y={-1} stroke="rgba(0,0,0,0.15)" strokeDasharray="3 3" />
          <Line
            type="monotone"
            dataKey="correlation"
            stroke="#000000"
            dot={false}
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
