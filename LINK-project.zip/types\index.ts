// ============================================================
// LINK — Core Domain Types
// ============================================================

export type AssetCategory = 'crypto' | 'equity' | 'macro' | 'commodity' | 'fx'

export interface Asset {
  id: string
  symbol: string
  name: string
  category: AssetCategory
  currency?: string
}

export interface PricePoint {
  timestamp: number // Unix ms
  price: number
}

export type PriceSeries = PricePoint[]

export interface Quote {
  symbol: string
  price: number
  timestamp: number
}

// ---- Correlation ----

export type CorrelationMethod = 'pearson' | 'spearman'

export interface CorrelationObservation {
  timestamp: number
  value: number
}

export type RelationshipRegime =
  | 'STRONG_POSITIVE'
  | 'MODERATE_POSITIVE'
  | 'NEUTRAL'
  | 'MODERATE_NEGATIVE'
  | 'STRONG_NEGATIVE'
  | 'DIVERGENCE'
  | 'STRENGTHENING'
  | 'WEAKENING'
  | 'INVERTING'
  | 'BROKEN'
  | 'INSUFFICIENT_DATA'

export interface RelationshipAnalysis {
  assetA: Asset
  assetB: Asset
  currentCorrelation: number | null
  baselineCorrelation: number | null
  correlationStdDev: number | null
  deviation: number | null
  zScore: number | null
  rollingCorrelation: CorrelationObservation[]
  regime: RelationshipRegime
  sampleSize: number
  dataQuality: 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT'
  timestamp: number
}

// ---- Anomaly ----

export interface Anomaly {
  id: string
  assetA: Asset
  assetB: Asset
  analysis: RelationshipAnalysis
  anomalyScore: number
  severity: 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME'
  detectedAt: number
}

// ---- Strategy ----

export type StrategyType =
  | 'MEAN_REVERSION'
  | 'BREAKOUT'
  | 'RELATIVE_STRENGTH'
  | 'CROSS_MARKET_ROTATION'

export interface StrategyDefinition {
  id: string
  name: string
  type: StrategyType
  assetA: string
  assetB: string
  lookback: number // days
  timeframe: string
  entryZ: number
  exitZ: number
  stopZ: number
  hedgeRatio?: number
  positionMode: 'pair' | 'directional'
  rebalanceFrequency: string
  capitalAllocation: number
  feesBps: number
  slippageBps: number
  createdAt: number
}

// ---- Backtest ----

export type TradeDirection = 'LONG_A_SHORT_B' | 'LONG_B_SHORT_A' | 'FLAT'

export interface BacktestTrade {
  id: string
  entryTimestamp: number
  exitTimestamp: number | null
  direction: TradeDirection
  entryPriceA: number
  entryPriceB: number
  exitPriceA: number | null
  exitPriceB: number | null
  entryZScore: number
  exitZScore: number | null
  pnl: number
  pnlPct: number
  exitReason: 'TARGET' | 'STOP' | 'END_OF_DATA' | 'OPEN'
}

export interface EquityPoint {
  timestamp: number
  equity: number
  drawdown: number
}

export interface BacktestResult {
  strategyId: string
  totalReturn: number
  annualizedReturn: number
  winRate: number
  profitFactor: number
  sharpe: number
  maxDrawdown: number
  tradeCount: number
  winCount: number
  lossCount: number
  avgTradePnl: number
  bestTrade: number
  worstTrade: number
  trades: BacktestTrade[]
  equityCurve: EquityPoint[]
  period: { start: number; end: number }
  dataSource: string
  timeframe: string
  feesBps: number
  slippageBps: number
}

// ---- Risk ----

export type RiskCheckStatus = 'PASS' | 'WARNING' | 'BLOCKED'

export interface RiskCheckItem {
  id: string
  label: string
  status: RiskCheckStatus
  detail: string
}

export interface RiskEvaluation {
  overallStatus: 'PASS' | 'CONDITIONAL' | 'BLOCKED'
  checks: RiskCheckItem[]
  timestamp: number
}

// ---- Paper Trading ----

export type PaperOrderStatus = 'OPEN' | 'CLOSED' | 'STOPPED'

export interface PaperPosition {
  id: string
  strategyId: string
  strategyName: string
  assetA: string
  assetB: string
  direction: TradeDirection
  entryTimestamp: number
  exitTimestamp?: number
  entryPriceA: number
  entryPriceB: number
  exitPriceA?: number
  exitPriceB?: number
  quantityA: number
  quantityB: number
  capitalAllocated: number
  balanceBefore: number
  balanceAfter?: number
  pnl?: number
  pnlPct?: number
  status: PaperOrderStatus
  entrySignal: string
  exitReason?: string
  hedgeRatio: number
}

// ---- Journal ----

export type JournalEventType =
  | 'SCAN_STARTED'
  | 'SCAN_COMPLETE'
  | 'ANOMALY_DETECTED'
  | 'PAIR_OPENED'
  | 'STRATEGY_GENERATED'
  | 'BACKTEST_COMPLETE'
  | 'RISK_CHECK'
  | 'PAPER_TRADE_STARTED'
  | 'PAPER_TRADE_CLOSED'
  | 'AI_INTERPRETATION'
  | 'USER_COMMAND'

export interface JournalEntry {
  id: string
  timestamp: number
  type: JournalEventType
  title: string
  detail: string
  pair?: string
  value?: string | number
  status?: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR'
}

// ---- Market Data ----

export interface MarketDataProvider {
  getHistoricalPrices(
    symbol: string,
    timeframe: string,
    start: Date,
    end: Date
  ): Promise<PriceSeries>
  getLatestPrice(symbol: string): Promise<Quote>
}

// ---- AI ----

export interface AIInterpretation {
  observation: string
  statisticalEvidence: string
  regime: string
  strategyHypothesis: string
  risk: string
  nextAction: string
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  causeVerified: boolean
}

export interface ScanResult {
  totalPairs: number
  anomalies: Anomaly[]
  watchlist: Anomaly[]
  normal: number
  scannedAt: number
}
