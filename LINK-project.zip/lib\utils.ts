import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Seeded PRNG — mulberry32 */
export function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5)
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** Pair ID from two asset IDs */
export function pairId(a: string, b: string): string {
  return `${a}-${b}`
}

export function pairLabel(a: string, b: string): string {
  return `${a} / ${b}`
}

export function parsePairId(pairId: string): [string, string] {
  const [a, b] = pairId.split('-')
  return [a, b]
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

export function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export function mean(arr: number[]): number {
  if (arr.length === 0) return 0
  return arr.reduce((s, v) => s + v, 0) / arr.length
}

export function stdDev(arr: number[]): number {
  if (arr.length < 2) return 0
  const m = mean(arr)
  const variance = arr.reduce((s, v) => s + (v - m) ** 2, 0) / (arr.length - 1)
  return Math.sqrt(variance)
}

export function normalize(series: number[]): number[] {
  const first = series[0]
  if (!first || first === 0) return series.map(() => 100)
  return series.map((v) => (v / first) * 100)
}

export function zScore(value: number, mu: number, sigma: number): number | null {
  if (sigma === 0) return null
  return (value - mu) / sigma
}
