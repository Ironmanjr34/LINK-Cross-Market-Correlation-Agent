import { useCallback } from 'react'
import { openPaperPosition, closePaperPosition } from '@/engine/paper-trading'
import { useLinkStore } from '@/services/persistence/store'
import type { StrategyDefinition, RelationshipAnalysis } from '@/types'
import { DEMO_SERIES } from '@/data/demoScenario'

export function usePaperTrading() {
  const { paperBalance, paperPositions, addPaperPosition, updatePaperPosition, addJournalEntry } =
    useLinkStore()

  const openPosition = useCallback(
    (strategy: StrategyDefinition, analysis: RelationshipAnalysis) => {
      const seriesA = DEMO_SERIES[strategy.assetA]
      const seriesB = DEMO_SERIES[strategy.assetB]
      if (!seriesA || !seriesB) return

      const priceA = seriesA[seriesA.length - 1].price
      const priceB = seriesB[seriesB.length - 1].price

      const position = openPaperPosition(strategy, analysis, priceA, priceB, paperBalance)
      addPaperPosition(position)

      addJournalEntry({
        type: 'PAPER_TRADE_STARTED',
        title: 'PAPER TRADE STARTED',
        detail: `${strategy.assetA} / ${strategy.assetB} — ${strategy.name}`,
        pair: `${strategy.assetA}-${strategy.assetB}`,
        value: `Z: ${(analysis.zScore ?? 0).toFixed(2)}\u03c3`,
        status: 'SUCCESS',
      })
    },
    [paperBalance, addPaperPosition, addJournalEntry]
  )

  const closePosition = useCallback(
    (positionId: string, exitReason: string) => {
      const position = paperPositions.find((p) => p.id === positionId)
      if (!position) return

      const seriesA = DEMO_SERIES[position.assetA]
      const seriesB = DEMO_SERIES[position.assetB]
      if (!seriesA || !seriesB) return

      const priceA = seriesA[seriesA.length - 1].price
      const priceB = seriesB[seriesB.length - 1].price

      const closed = closePaperPosition(position, priceA, priceB, exitReason, 10, 5)
      updatePaperPosition(positionId, closed)

      addJournalEntry({
        type: 'PAPER_TRADE_CLOSED',
        title: 'PAPER TRADE CLOSED',
        detail: `${position.assetA} / ${position.assetB} — ${exitReason}`,
        pair: `${position.assetA}-${position.assetB}`,
        value: `P&L: ${closed.pnl !== undefined ? (closed.pnl >= 0 ? '+' : '') + closed.pnl.toFixed(2) : 'N/A'}`,
        status: 'INFO',
      })
    },
    [paperPositions, updatePaperPosition, addJournalEntry]
  )

  const openPositions = paperPositions.filter((p) => p.status === 'OPEN')
  const closedPositions = paperPositions.filter((p) => p.status === 'CLOSED')

  return { paperBalance, openPositions, closedPositions, openPosition, closePosition }
}
