'use client'
import { cn } from '@/lib/utils'
import { formatCorrelation } from '@/lib/formatters'

interface CorrelationHeatmapProps {
  assets: string[]
  matrix: Record<string, Record<string, number | null>>
  onCellClick?: (assetA: string, assetB: string) => void
  className?: string
}

function cellStyle(value: number | null): { bg: string; text: string } {
  if (value === null) return { bg: 'bg-[#F2F2F2]', text: 'text-[#999999]' }
  if (value === 1) return { bg: 'bg-black', text: 'text-white' }
  if (value >= 0.7) return { bg: 'bg-neutral-800', text: 'text-white' }
  if (value >= 0.4) return { bg: 'bg-neutral-600', text: 'text-white' }
  if (value >= 0.1) return { bg: 'bg-neutral-300', text: 'text-black' }
  if (value >= -0.1) return { bg: 'bg-[#F2F2F2]', text: 'text-neutral-700' }
  if (value >= -0.4) return { bg: 'bg-red-100', text: 'text-accent' }
  if (value >= -0.7) return { bg: 'bg-red-200', text: 'text-accent' }
  return { bg: 'bg-accent', text: 'text-white' }
}

export function CorrelationHeatmap({
  assets,
  matrix,
  onCellClick,
  className,
}: CorrelationHeatmapProps) {
  return (
    <div className={cn('overflow-x-auto', className)}>
      <table className="border-collapse w-full">
        <thead>
          <tr>
            <th className="w-16" />
            {assets.map((a) => (
              <th
                key={a}
                className="text-[11px] uppercase tracking-widest font-bold pb-2 px-1 text-center text-black"
                style={{ minWidth: '56px' }}
              >
                {a}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {assets.map((rowAsset) => (
            <tr key={rowAsset}>
              <td className="text-[11px] uppercase tracking-widest font-bold pr-3 py-0.5 whitespace-nowrap text-black">
                {rowAsset}
              </td>
              {assets.map((colAsset) => {
                const value =
                  rowAsset === colAsset
                    ? 1
                    : matrix[rowAsset]?.[colAsset] ?? matrix[colAsset]?.[rowAsset] ?? null
                const { bg, text } = cellStyle(value)
                const isClickable = onCellClick && rowAsset !== colAsset
                return (
                  <td key={colAsset} className="px-0.5 py-0.5">
                    <button
                      onClick={() => isClickable && onCellClick?.(rowAsset, colAsset)}
                      className={cn(
                        'w-full h-12 mono-value text-xs font-bold transition-opacity duration-150 border-0 flex items-center justify-center',
                        bg,
                        text,
                        isClickable ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                      )}
                      title={`${rowAsset} / ${colAsset}: ${value !== null ? formatCorrelation(value) : 'N/A'}`}
                      aria-label={`${rowAsset} to ${colAsset} correlation: ${value !== null ? formatCorrelation(value) : 'N/A'}`}
                      disabled={!isClickable}
                    >
                      {formatCorrelation(value)}
                    </button>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {/* Legend */}
      <div className="flex items-center gap-3 mt-4 flex-wrap">
        <span className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">LEGEND:</span>
        {[
          { label: '+1.0', bg: 'bg-black', text: 'text-white' },
          { label: '+0.7', bg: 'bg-neutral-600', text: 'text-white' },
          { label: '0.0', bg: 'bg-[#F2F2F2]', text: 'text-neutral-700' },
          { label: '-0.4', bg: 'bg-red-200', text: 'text-accent' },
          { label: '-1.0', bg: 'bg-accent', text: 'text-white' },
        ].map(({ label, bg, text }) => (
          <div key={label} className="flex items-center gap-1">
            <div className={cn('w-6 h-4 flex items-center justify-center text-[9px] font-bold mono-value border border-black/10', bg, text)}>
              {label}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
