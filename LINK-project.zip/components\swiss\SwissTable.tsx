import { cn } from '@/lib/utils'
import type { ReactNode } from 'react'

export interface Column<T> {
  key: string
  header: string
  render: (row: T) => ReactNode
  className?: string
  headerClassName?: string
}

interface SwissTableProps<T> {
  columns: Column<T>[]
  data: T[]
  onRowClick?: (row: T) => void
  className?: string
  emptyMessage?: string
  keyExtractor: (row: T) => string
}

export function SwissTable<T>({
  columns,
  data,
  onRowClick,
  className,
  emptyMessage = 'NO DATA',
  keyExtractor,
}: SwissTableProps<T>) {
  return (
    <div className={cn('overflow-x-auto', className)}>
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black">
            {columns.map((col) => (
              <th
                key={col.key}
                className={cn(
                  'text-left text-[11px] uppercase tracking-widest font-bold pb-2 pt-1 pr-4 text-black',
                  col.headerClassName
                )}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length}
                className="text-center text-[#999999] text-[11px] uppercase tracking-widest py-8"
              >
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((row) => (
              <tr
                key={keyExtractor(row)}
                onClick={() => onRowClick?.(row)}
                className={cn(
                  'border-b border-gray-subtle',
                  onRowClick && 'cursor-pointer hover:bg-muted transition-colors duration-150'
                )}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={cn('py-3 pr-4 text-sm', col.className)}
                  >
                    {col.render(row)}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}
