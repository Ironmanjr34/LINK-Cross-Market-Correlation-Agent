'use client'
import { formatTimeShort } from '@/lib/formatters'
import { cn } from '@/lib/utils'
import type { JournalEntry } from '@/types'

const STATUS_COLORS: Record<string, string> = {
  SUCCESS: 'border-l-black',
  WARNING: 'border-l-accent',
  ERROR: 'border-l-accent',
  INFO: 'border-l-[#999999]',
}

interface DecisionJournalProps {
  entries: JournalEntry[]
  maxItems?: number
  className?: string
}

export function DecisionJournal({ entries, maxItems, className }: DecisionJournalProps) {
  const visible = maxItems ? entries.slice(0, maxItems) : entries

  if (visible.length === 0) {
    return (
      <div className={cn('text-center py-8', className)}>
        <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold">NO JOURNAL ENTRIES</p>
        <p className="text-sm text-[#999999] mt-1">Actions will be recorded here as you use LINK.</p>
      </div>
    )
  }

  return (
    <div className={cn('space-y-0', className)}>
      {visible.map((entry) => (
        <div
          key={entry.id}
          className={cn(
            'flex gap-4 border-b border-[#E8E8E8] py-3 pl-4 border-l-4',
            STATUS_COLORS[entry.status ?? 'INFO'] ?? 'border-l-[#E8E8E8]'
          )}
        >
          <div className="w-20 shrink-0">
            <p className="text-[10px] mono-value text-[#999999]">{formatTimeShort(entry.timestamp)}</p>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[11px] uppercase tracking-widest font-bold">{entry.title}</p>
            {entry.pair && (
              <p className="text-sm font-bold mt-0.5">{entry.pair.replace('-', ' / ')}</p>
            )}
            {entry.detail && (
              <p className="text-xs text-[#444444] mt-0.5">{entry.detail}</p>
            )}
          </div>
          {entry.value !== undefined && (
            <div className="shrink-0">
              <span className="text-xs mono-value font-bold">{entry.value}</span>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
