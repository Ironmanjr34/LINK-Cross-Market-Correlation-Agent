import type { StrategyDefinition, StrategyType } from '@/types'
import { generateId } from '@/lib/utils'
import { DEFAULT_FEES_BPS, DEFAULT_SLIPPAGE_BPS, DEMO_CAPITAL } from '@/lib/constants'

interface GenerateStrategyParams {
  assetA: string
  assetB: string
  type: StrategyType
  entryZ?: number
  exitZ?: number
  stopZ?: number
  hedgeRatio?: number
  lookback?: number
  capitalAllocation?: number
}

export function generateStrategy(params: GenerateStrategyParams): StrategyDefinition {
  const {
    assetA,
    assetB,
    type,
    entryZ = 2.0,
    exitZ = 0.5,
    stopZ = 3.0,
    hedgeRatio,
    lookback = 30,
    capitalAllocation = DEMO_CAPITAL,
  } = params

  const typeLabels: Record<StrategyType, string> = {
    MEAN_REVERSION: 'Mean Reversion',
    BREAKOUT: 'Regime Breakout',
    RELATIVE_STRENGTH: 'Relative Strength',
    CROSS_MARKET_ROTATION: 'Cross-Market Rotation',
  }

  return {
    id: generateId(),
    name: `${typeLabels[type]} — ${assetA} / ${assetB}`,
    type,
    assetA,
    assetB,
    lookback,
    timeframe: '1D',
    entryZ,
    exitZ,
    stopZ,
    hedgeRatio,
    positionMode: 'pair',
    rebalanceFrequency: 'Daily',
    capitalAllocation,
    feesBps: DEFAULT_FEES_BPS,
    slippageBps: DEFAULT_SLIPPAGE_BPS,
    createdAt: Date.now(),
  }
}

/**
 * Parse AI-generated strategy configuration into typed StrategyDefinition.
 * Used when AI produces structured JSON from natural language.
 */
export function parseAIStrategy(
  raw: Partial<StrategyDefinition> & { assetA: string; assetB: string; type: StrategyType }
): StrategyDefinition {
  return generateStrategy({
    assetA: raw.assetA,
    assetB: raw.assetB,
    type: raw.type,
    entryZ: raw.entryZ ?? 2.0,
    exitZ: raw.exitZ ?? 0.5,
    stopZ: raw.stopZ ?? 3.0,
    hedgeRatio: raw.hedgeRatio,
    lookback: raw.lookback ?? 30,
    capitalAllocation: raw.capitalAllocation ?? DEMO_CAPITAL,
  })
}
