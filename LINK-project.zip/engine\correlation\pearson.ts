import { MIN_SAMPLE_SIZE } from '@/lib/constants'

/**
 * Calculate Pearson correlation coefficient between two numeric arrays.
 * Returns null if insufficient data, zero variance, or mismatched lengths.
 */
export function pearsonCorrelation(x: number[], y: number[]): number | null {
  if (x.length !== y.length) return null
  const n = x.length
  if (n < MIN_SAMPLE_SIZE) return null

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0
  for (let i = 0; i < n; i++) {
    sumX += x[i]
    sumY += y[i]
    sumXY += x[i] * y[i]
    sumX2 += x[i] * x[i]
    sumY2 += y[i] * y[i]
  }

  const numerator = n * sumXY - sumX * sumY
  const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY))

  if (denominator === 0) return null
  const r = numerator / denominator
  // Clamp to [-1, 1] for floating point safety
  return Math.max(-1, Math.min(1, r))
}
