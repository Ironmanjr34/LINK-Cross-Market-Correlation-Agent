import type {
  StrategyDefinition,
  PaperPosition,
  RelationshipAnalysis,
} from '@/types'
import { generateId } from '@/lib/utils'

export function openPaperPosition(
  strategy: StrategyDefinition,
  analysis: RelationshipAnalysis,
  currentPriceA: number,
  currentPriceB: number,
  currentBalance: number
): PaperPosition {
  const zScore = analysis.zScore ?? 0
  const direction = zScore < 0 ? 'LONG_A_SHORT_B' : 'LONG_B_SHORT_A'
  const slippageFactor = 1 - strategy.slippageBps / 10000
  const hedgeRatio = strategy.hedgeRatio ?? 1

  const halfCapital = strategy.capitalAllocation / 2
  const quantityA = halfCapital / currentPriceA
  const quantityB = (halfCapital * hedgeRatio) / currentPriceB

  return {
    id: generateId(),
    strategyId: strategy.id,
    strategyName: strategy.name,
    assetA: strategy.assetA,
    assetB: strategy.assetB,
    direction,
    entryTimestamp: Date.now(),
    entryPriceA: currentPriceA / slippageFactor,
    entryPriceB: currentPriceB / slippageFactor,
    quantityA,
    quantityB,
    capitalAllocated: strategy.capitalAllocation,
    balanceBefore: currentBalance,
    status: 'OPEN',
    entrySignal: `Z-score ${zScore.toFixed(2)}σ — ${strategy.type}`,
    hedgeRatio,
  }
}

export function closePaperPosition(
  position: PaperPosition,
  currentPriceA: number,
  currentPriceB: number,
  exitReason: string,
  feesBps: number,
  slippageBps: number
): PaperPosition {
  const costFactor = (1 - feesBps / 10000) * (1 - slippageBps / 10000)
  const exitPriceA = currentPriceA * (1 - slippageBps / 10000)
  const exitPriceB = currentPriceB * (1 - slippageBps / 10000)

  let pnl = 0
  if (position.direction === 'LONG_A_SHORT_B') {
    const longPnl = (exitPriceA - position.entryPriceA) * position.quantityA
    const shortPnl = (position.entryPriceB - exitPriceB) * position.quantityB
    pnl = (longPnl + shortPnl) * costFactor
  } else {
    const longPnl = (exitPriceB - position.entryPriceB) * position.quantityB
    const shortPnl = (position.entryPriceA - exitPriceA) * position.quantityA
    pnl = (longPnl + shortPnl) * costFactor
  }

  return {
    ...position,
    exitTimestamp: Date.now(),
    exitPriceA,
    exitPriceB,
    pnl,
    pnlPct: pnl / position.capitalAllocated,
    balanceAfter: position.balanceBefore + pnl,
    status: 'CLOSED',
    exitReason,
  }
}
