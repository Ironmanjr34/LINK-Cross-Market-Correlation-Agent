export function formatCorrelation(v: number | null): string {
  if (v === null) return 'N/A'
  return v.toFixed(2)
}

export function formatZScore(v: number | null): string {
  if (v === null) return 'N/A'
  const sign = v > 0 ? '+' : ''
  return `${sign}${v.toFixed(2)}σ`
}

export function formatPct(v: number, decimals = 1): string {
  return `${(v * 100).toFixed(decimals)}%`
}

export function formatPctBps(bps: number): string {
  return `${(bps / 100).toFixed(2)}%`
}

export function formatCurrency(v: number, decimals = 0): string {
  const abs = Math.abs(v)
  const sign = v < 0 ? '-' : ''
  return `${sign}$${abs.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`
}

export function formatTimestamp(ts: number): string {
  return new Date(ts).toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: 'UTC',
  }).replace(',', '') + ' UTC'
}

export function formatTimeShort(ts: number): string {
  return new Date(ts).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  })
}

export function formatDateShort(ts: number): string {
  return new Date(ts).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

export function formatSharpe(v: number): string {
  return v.toFixed(2)
}

export function formatReturn(v: number): string {
  const sign = v >= 0 ? '+' : ''
  return `${sign}${(v * 100).toFixed(2)}%`
}

export function formatDuration(startMs: number, endMs: number): string {
  const diffDays = Math.round((endMs - startMs) / (1000 * 60 * 60 * 24))
  if (diffDays < 1) return '< 1 day'
  if (diffDays === 1) return '1 day'
  return `${diffDays} days`
}
