﻿'use client'
import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { SwissPanel, SwissButton, SwissMetric, SwissSectionLabel, SwissDivider } from '@/components/swiss'
import { CorrelationHeatmap } from '@/components/charts/CorrelationHeatmap'
import { RollingCorrelationChart } from '@/components/charts/RollingCorrelationChart'
import { DEMO_ASSETS, ASSET_MAP, ROLLING_WINDOW } from '@/lib/constants'
import { DEMO_SERIES, DEFAULT_SCAN_PAIRS } from '@/data/demoScenario'
import { calculateCorrelationStats } from '@/engine/correlation'
import { classifyRegime } from '@/engine/regime'
import { formatCorrelation, formatZScore } from '@/lib/formatters'
import { REGIME_LABELS } from '@/lib/constants'

const MATRIX_ASSETS = ['BTC', 'ETH', 'SOL', 'NASDAQ', 'GOLD', 'DXY']
const METHODS = ['pearson', 'spearman'] as const
const LOOKBACK_OPTIONS = [7, 14, 30, 60, 90]

export default function CorrelationPage() {
  const router = useRouter()
  const [assetA, setAssetA] = useState('BTC')
  const [assetB, setAssetB] = useState('NASDAQ')
  const [lookback, setLookback] = useState(30)
  const [method, setMethod] = useState<'pearson' | 'spearman'>('pearson')

  const analysis = useMemo(() => {
    const sA = DEMO_SERIES[assetA]
    const sB = DEMO_SERIES[assetB]
    if (!sA || !sB) return null
    return calculateCorrelationStats(sA, sB, lookback, method)
  }, [assetA, assetB, lookback, method])

  const regime = useMemo(() => {
    if (!analysis) return 'INSUFFICIENT_DATA'
    return classifyRegime(
      analysis.currentCorrelation,
      analysis.zScore,
      analysis.rolling,
      analysis.baselineCorrelation,
      analysis.sampleSize
    )
  }, [analysis])

  // Build full matrix
  const correlationMatrix = useMemo(() => {
    const matrix: Record<string, Record<string, number | null>> = {}
    for (const a of MATRIX_ASSETS) {
      matrix[a] = {}
      for (const b of MATRIX_ASSETS) {
        if (a === b) { matrix[a][b] = 1; continue }
        if (matrix[b]?.[a] !== undefined) { matrix[a][b] = matrix[b][a]; continue }
        const sA = DEMO_SERIES[a]; const sB = DEMO_SERIES[b]
        if (!sA || !sB) { matrix[a][b] = null; continue }
        matrix[a][b] = calculateCorrelationStats(sA, sB, lookback, method).currentCorrelation
      }
    }
    return matrix
  }, [lookback, method])

  return (
    <div>
      <div className="border-b-4 border-black px-6 py-8">
        <p className="text-label uppercase tracking-widest text-gray-mid mb-2">02 / CORRELATION LAB</p>
        <h1 className="text-display-md font-black tracking-tighter">CORRELATION LAB</h1>
        <p className="text-gray-dark mt-2">Research cross-market relationships with configurable rolling windows and methods.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 border-b-2 border-black">
        {/* Controls */}
        <div className="lg:col-span-3 border-r-0 lg:border-r-2 border-black border-b-2 lg:border-b-0">
          <div className="p-6">
            <SwissSectionLabel className="mb-4">PAIR SELECTION</SwissSectionLabel>

            <div className="space-y-4">
              {/* Asset A */}
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">ASSET A</label>
                <select
                  value={assetA}
                  onChange={e => setAssetA(e.target.value)}
                  className="w-full border-2 border-black px-3 py-2 text-sm font-bold uppercase focus:outline-none focus:border-accent bg-white"
                >
                  {DEMO_ASSETS.map(a => <option key={a.id} value={a.id}>{a.symbol} — {a.name}</option>)}
                </select>
              </div>

              {/* Asset B */}
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">ASSET B</label>
                <select
                  value={assetB}
                  onChange={e => setAssetB(e.target.value)}
                  className="w-full border-2 border-black px-3 py-2 text-sm font-bold uppercase focus:outline-none focus:border-accent bg-white"
                >
                  {DEMO_ASSETS.filter(a => a.id !== assetA).map(a => <option key={a.id} value={a.id}>{a.symbol} — {a.name}</option>)}
                </select>
              </div>

              {/* Lookback */}
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">ROLLING WINDOW</label>
                <div className="flex flex-wrap gap-2">
                  {LOOKBACK_OPTIONS.map(l => (
                    <SwissButton key={l} onClick={() => setLookback(l)} variant={lookback === l ? 'primary' : 'secondary'} size="sm">
                      {l}D
                    </SwissButton>
                  ))}
                </div>
              </div>

              {/* Method */}
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">METHOD</label>
                <div className="flex gap-2">
                  {METHODS.map(m => (
                    <SwissButton key={m} onClick={() => setMethod(m)} variant={method === m ? 'primary' : 'secondary'} size="sm">
                      {m.toUpperCase()}
                    </SwissButton>
                  ))}
                </div>
              </div>

              <SwissDivider weight={1} className="my-4" />

              {/* Current stats */}
              <div className="space-y-3">
                <div>
                  <p className="text-label uppercase tracking-widest text-gray-mid">CURRENT CORRELATION</p>
                  <p className="text-2xl font-black mono-value">{formatCorrelation(analysis?.currentCorrelation ?? null)}</p>
                </div>
                <div>
                  <p className="text-label uppercase tracking-widest text-gray-mid">BASELINE</p>
                  <p className="text-2xl font-black mono-value">{formatCorrelation(analysis?.baselineCorrelation ?? null)}</p>
                </div>
                <div>
                  <p className="text-label uppercase tracking-widest text-gray-mid">Z-SCORE</p>
                  <p className="text-2xl font-black mono-value text-accent">{formatZScore(analysis?.zScore ?? null)}</p>
                </div>
                <div>
                  <p className="text-label uppercase tracking-widest text-gray-mid">REGIME</p>
                  <p className="text-sm font-black">{REGIME_LABELS[regime] ?? regime}</p>
                </div>
              </div>

              <SwissDivider weight={1} className="my-4" />

              <SwissButton
                onClick={() => router.push(`/relationship/${assetA}-${assetB}`)}
                variant="primary"
                size="md"
                className="w-full"
              >
                OPEN FULL ANALYSIS →
              </SwissButton>
            </div>
          </div>
        </div>

        {/* Chart area */}
        <div className="lg:col-span-9 p-6 space-y-8">
          {analysis && analysis.rolling.length > 0 ? (
            <>
              <RollingCorrelationChart
                data={analysis.rolling}
                baseline={analysis.baselineCorrelation}
                height={260}
                label={`${assetA} / ${assetB} — ${lookback}D ROLLING ${method.toUpperCase()} CORRELATION`}
              />
              <SwissDivider weight={1} />
            </>
          ) : (
            <div className="border-2 border-gray-subtle p-8 text-center">
              <p className="text-label uppercase tracking-widest text-gray-mid">INSUFFICIENT SAMPLE</p>
              <p className="text-sm text-gray-mid mt-1">A minimum of {lookback + 20} observations is required for this window.</p>
            </div>
          )}

          {/* Matrix */}
          <div>
            <SwissSectionLabel className="mb-4">CORRELATION MATRIX — {lookback}D ROLLING</SwissSectionLabel>
            <CorrelationHeatmap
              assets={MATRIX_ASSETS}
              matrix={correlationMatrix}
              onCellClick={(a, b) => { setAssetA(a); setAssetB(b) }}
            />
            <p className="text-label text-gray-mid mt-2">CLICK ANY CELL TO SELECT PAIR</p>
          </div>
        </div>
      </div>
    </div>
  )
}
