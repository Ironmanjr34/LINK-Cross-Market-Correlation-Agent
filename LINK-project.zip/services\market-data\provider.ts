import type { MarketDataProvider, PriceSeries, Quote } from '@/types'
import { DEMO_SERIES } from '@/data/demoScenario'

/**
 * Mock market data provider backed by deterministic seeded demo data.
 * All data is labeled DEMO / SEEDED.
 */
export class MockMarketDataProvider implements MarketDataProvider {
  async getHistoricalPrices(
    symbol: string,
    _timeframe: string,
    start: Date,
    end: Date
  ): Promise<PriceSeries> {
    const series = DEMO_SERIES[symbol.toUpperCase()]
    if (!series) return []

    return series.filter(
      (p) => p.timestamp >= start.getTime() && p.timestamp <= end.getTime()
    )
  }

  async getLatestPrice(symbol: string): Promise<Quote> {
    const series = DEMO_SERIES[symbol.toUpperCase()]
    if (!series || series.length === 0) {
      return { symbol, price: 0, timestamp: Date.now() }
    }
    const latest = series[series.length - 1]
    return { symbol, price: latest.price, timestamp: latest.timestamp }
  }

  getFullSeries(symbol: string): PriceSeries {
    return DEMO_SERIES[symbol.toUpperCase()] ?? []
  }
}

export const marketDataProvider = new MockMarketDataProvider()
