'use client'
import { useLinkStore } from '@/services/persistence/store'
import { formatTimeShort } from '@/lib/formatters'

export function AgentActivityPanel() {
  const journal = useLinkStore((s) => s.journal)
  const recent = journal.slice(0, 8)

  return (
    <div className="border-t-2 border-black bg-white">
      <div className="flex items-center justify-between p-3 border-b border-[#E8E8E8]">
        <p className="text-[11px] uppercase tracking-widest font-bold text-black">LINK ACTIVITY LOG</p>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 bg-black animate-pulse" />
          <span className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">STREAM ACTIVE</span>
        </span>
      </div>
      <div className="max-h-48 overflow-y-auto">
        {recent.length === 0 ? (
          <p className="text-[10px] text-[#999999] uppercase tracking-widest p-4">WAITING FOR SYSTEM ACTIVITY...</p>
        ) : (
          recent.map((entry) => (
            <div key={entry.id} className="flex items-center gap-3 px-4 py-2.5 border-b border-[#E8E8E8] last:border-0 text-xs">
              <span className="text-[10px] mono-value text-[#999999] shrink-0 w-16">
                {formatTimeShort(entry.timestamp)}
              </span>
              <div className="min-w-0 flex-1 flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-widest font-bold text-black">{entry.title}</span>
                {entry.pair && (
                  <span className="text-[10px] font-mono text-[#999999]">{entry.pair.replace('-', ' / ')}</span>
                )}
                {entry.detail && (
                  <span className="text-xs text-[#444444] truncate">{entry.detail}</span>
                )}
              </div>
              {entry.value !== undefined && (
                <span className="text-[11px] mono-value font-bold ml-auto shrink-0">{String(entry.value)}</span>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  )
}
