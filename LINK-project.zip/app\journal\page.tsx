'use client'
import { useLinkStore } from '@/services/persistence/store'
import { DecisionJournal } from '@/components/domain/DecisionJournal'
import { SwissMetric, SwissSectionLabel } from '@/components/swiss'

export default function JournalPage() {
  const { journal } = useLinkStore()

  return (
    <div>
      <div className="border-b-4 border-black px-6 py-8 bg-white">
        <p className="text-[11px] uppercase tracking-widest text-[#999999] mb-2 font-bold">08 / DECISION JOURNAL</p>
        <h1 className="text-3xl md:text-5xl font-black tracking-tighter">DECISION JOURNAL</h1>
        <p className="text-[#444444] mt-2 text-sm">
          Immutable log of every research step, quantitative calculation, AI interpretation, and simulated execution.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 border-b-2 border-black bg-white">
        <div className="p-6 border-r-2 border-black">
          <SwissMetric label="TOTAL EVENTS" value={journal.length} size="md" />
        </div>
        <div className="p-6 border-r-2 border-black">
          <SwissMetric
            label="STRATEGIES"
            value={journal.filter((j) => j.type === 'STRATEGY_GENERATED').length}
            size="md"
          />
        </div>
        <div className="p-6 border-r-2 border-black">
          <SwissMetric
            label="BACKTESTS"
            value={journal.filter((j) => j.type === 'BACKTEST_COMPLETE').length}
            size="md"
          />
        </div>
        <div className="p-6">
          <SwissMetric
            label="PAPER TRADES"
            value={journal.filter((j) => j.type === 'PAPER_TRADE_STARTED').length}
            size="md"
          />
        </div>
      </div>

      <div className="px-6 py-6 bg-white">
        <SwissSectionLabel className="mb-4">AUDIT TRAIL LOG</SwissSectionLabel>
        <DecisionJournal entries={journal} />
      </div>

      <div className="border-t-2 border-black px-6 py-4 bg-[#F2F2F2]">
        <p className="text-[10px] text-[#999999] uppercase tracking-widest">
          ALL ACTIONS RECORDED CHRONOLOGICALLY — PROOF OF AGENTIC WORKFLOW — SIMULATED EXECUTION
        </p>
      </div>
    </div>
  )
}
