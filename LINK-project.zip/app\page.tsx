'use client'
import { useState, useCallback, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { SwissPanel, SwissButton, SwissMetric, SwissSectionLabel, SwissDivider, SwissStatus } from '@/components/swiss'
import { CorrelationHeatmap } from '@/components/charts/CorrelationHeatmap'
import { AnomalyCard } from '@/components/domain/AnomalyCard'
import { AgentActivityPanel } from '@/components/domain/AgentActivityPanel'
import { CommandCenter } from '@/components/CommandCenter'
import { useAnomalyScan } from '@/hooks/useAnomalyEngine'
import { useLinkStore } from '@/services/persistence/store'
import { DEMO_ASSETS, ASSET_MAP } from '@/lib/constants'
import { DEMO_SERIES, DEFAULT_SCAN_PAIRS } from '@/data/demoScenario'
import { calculateCorrelationStats } from '@/engine/correlation'
import { pairId } from '@/lib/utils'
import { formatDateShort } from '@/lib/formatters'

const MATRIX_ASSETS = ['BTC', 'ETH', 'NASDAQ', 'GOLD', 'DXY']

export default function OverviewPage() {
  const router = useRouter()
  const { addJournalEntry, isScanning, setIsScanning, setScanResult, scanResult } = useLinkStore()
  const [scanStep, setScanStep] = useState(0)

  // Pre-calculate scan results
  const realScanResult = useAnomalyScan()

  // Build correlation matrix
  const correlationMatrix = useMemo(() => {
    const matrix: Record<string, Record<string, number | null>> = {}
    for (const assetA of MATRIX_ASSETS) {
      matrix[assetA] = {}
      for (const assetB of MATRIX_ASSETS) {
        if (assetA === assetB) { matrix[assetA][assetB] = 1; continue }
        if (matrix[assetB]?.[assetA] !== undefined) {
          matrix[assetA][assetB] = matrix[assetB][assetA]
          continue
        }
        const sA = DEMO_SERIES[assetA]
        const sB = DEMO_SERIES[assetB]
        if (!sA || !sB) { matrix[assetA][assetB] = null; continue }
        const stats = calculateCorrelationStats(sA, sB, 30)
        matrix[assetA][assetB] = stats.currentCorrelation
      }
    }
    return matrix
  }, [])

  const handleScanMarkets = useCallback(async () => {
    setIsScanning(true)
    setScanStep(0)
    addJournalEntry({ type: 'SCAN_STARTED', title: 'MARKET SCAN STARTED', detail: `Scanning ${DEFAULT_SCAN_PAIRS.length} pairs`, status: 'INFO' })

    // Animate progress
    for (let i = 0; i <= DEFAULT_SCAN_PAIRS.length; i++) {
      setScanStep(i)
      await new Promise(r => setTimeout(r, 60))
    }

    setScanResult(realScanResult)
    setIsScanning(false)
    addJournalEntry({
      type: 'SCAN_COMPLETE',
      title: 'SCAN COMPLETE',
      detail: `${realScanResult.anomalies.length} anomalies detected across ${realScanResult.totalPairs} pairs`,
      value: `${realScanResult.anomalies.length} ANOMALIES`,
      status: 'SUCCESS',
    })
  }, [realScanResult, addJournalEntry, setIsScanning, setScanResult])

  const displayResult = scanResult ?? realScanResult
  const topAnomaly = displayResult.anomalies[0]

  return (
    <div className="">
      {/* Hero */}
      <div className="border-b-4 border-black pattern-grid">
        <div className="px-6 py-12 md:py-20">
          <p className="text-label uppercase tracking-widest text-gray-mid mb-4">01 / CROSS-MARKET INTELLIGENCE</p>
          <h1 className="text-display-xl font-black leading-none tracking-tighter mb-6 max-w-3xl">
            WHEN MARKETS
            <br />MOVE TOGETHER,
            <br /><span className="text-accent">LINK FINDS IT.</span>
          </h1>
          <p className="text-lg text-gray-dark max-w-xl mb-8 leading-relaxed">
            Detect cross-market relationship breaks.
            Generate testable pair strategies.
            Validate with backtesting.
            Move to paper trading.
          </p>
          <div className="flex gap-3 flex-wrap">
            <SwissButton onClick={handleScanMarkets} isLoading={isScanning} size="lg">
              SCAN MARKETS
            </SwissButton>
            <SwissButton onClick={() => router.push('/correlation')} variant="secondary" size="lg">
              OPEN CORRELATION LAB
            </SwissButton>
          </div>
        </div>
      </div>

      {/* Scan progress */}
      {isScanning && (
        <div className="border-b-2 border-black px-6 py-4 bg-black text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-label uppercase tracking-widest font-bold">SCANNING {DEFAULT_SCAN_PAIRS.length} ASSET RELATIONSHIPS...</p>
            <p className="text-label mono-value">{scanStep} / {DEFAULT_SCAN_PAIRS.length} PAIRS ANALYZED</p>
          </div>
          <div className="h-1 bg-white/20 w-full">
            <div
              className="h-1 bg-accent transition-all duration-100"
              style={{ width: `${(scanStep / DEFAULT_SCAN_PAIRS.length) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* KPI Row */}
      <div className="border-b-2 border-black grid grid-cols-2 md:grid-cols-4">
        {[
          { label: 'PAIRS SCANNED', value: displayResult.totalPairs },
          { label: 'ANOMALIES', value: displayResult.anomalies.length, accent: displayResult.anomalies.length > 0 },
          { label: 'WATCHLIST', value: displayResult.watchlist.length },
          { label: 'NORMAL', value: displayResult.normal },
        ].map(({ label, value, accent }, i) => (
          <div key={label} className={`p-6 ${i < 3 ? 'border-r-2 border-black md:border-r-2' : ''} ${i === 1 && 'border-r-2 border-black'}`}>
            <SwissMetric label={label} value={value} size="lg" accent={accent} />
          </div>
        ))}
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 border-b-2 border-black">
        {/* Left column: Regime + Anomalies */}
        <div className="lg:col-span-5 border-r-0 lg:border-r-2 border-black">
          {/* Market Regime */}
          <div className="border-b-2 border-black p-6">
            <SwissSectionLabel number="02" className="mb-4">MARKET REGIME</SwissSectionLabel>
            <div className="flex items-end gap-6">
              <SwissMetric label="REGIME" value="RISK OFF" size="lg" />
              <SwissMetric label="CONFIDENCE" value="72%" size="md" />
            </div>
            <p className="text-sm text-gray-dark mt-4 leading-relaxed">
              Cross-asset correlation patterns suggest a risk-off environment.
              BTC/NASDAQ relationship has weakened materially.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {['BTC/NASDAQ WEAK', 'DXY NEGATIVE CORR', 'GOLD NEUTRAL'].map(s => (
                <span key={s} className="text-label border border-gray-subtle px-2 py-1 uppercase tracking-widest">{s}</span>
              ))}
            </div>
          </div>

          {/* Anomaly feed */}
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <SwissSectionLabel number="03" >ANOMALY FEED</SwissSectionLabel>
              <SwissButton onClick={() => router.push('/anomalies')} variant="ghost" size="sm">
                VIEW ALL →
              </SwissButton>
            </div>
            {displayResult.anomalies.length === 0 ? (
              <div className="border-2 border-gray-subtle p-6 text-center">
                <p className="text-label uppercase tracking-widest text-gray-mid">NO SIGNIFICANT RELATIONSHIP BREAKS</p>
                <p className="text-sm text-gray-mid mt-1">Click SCAN MARKETS to detect anomalies.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {displayResult.anomalies.slice(0, 3).map((anomaly, i) => (
                  <AnomalyCard
                    key={anomaly.id}
                    anomaly={anomaly}
                    index={i}
                    onClick={() => router.push(`/relationship/${anomaly.assetA.id}-${anomaly.assetB.id}`)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right column: Correlation Matrix */}
        <div className="lg:col-span-7">
          <div className="p-6 border-b-2 border-black">
            <div className="flex items-center justify-between mb-4">
              <SwissSectionLabel number="04">CORRELATION MATRIX</SwissSectionLabel>
              <SwissButton onClick={() => router.push('/correlation')} variant="ghost" size="sm">
                CORRELATION LAB →
              </SwissButton>
            </div>
            <CorrelationHeatmap
              assets={MATRIX_ASSETS}
              matrix={correlationMatrix}
              onCellClick={(a, b) => router.push(`/relationship/${a}-${b}`)}
            />
            <p className="text-label text-gray-mid mt-3">CLICK ANY CELL TO OPEN PAIR ANALYSIS</p>
          </div>

          {/* Top anomaly detail */}
          {topAnomaly && (
            <div className="p-6 border-b-2 border-black">
              <SwissSectionLabel number="05" className="mb-4">TOP ANOMALY</SwissSectionLabel>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <SwissMetric label="PAIR" value={`${topAnomaly.assetA.symbol} / ${topAnomaly.assetB.symbol}`} size="sm" mono={false} />
                <SwissMetric label="Z-SCORE" value={`${topAnomaly.analysis.zScore !== null ? (topAnomaly.analysis.zScore > 0 ? '+' : '') + topAnomaly.analysis.zScore.toFixed(2) + '\u03c3' : 'N/A'}`} size="sm" accent />
                <SwissMetric label="CURRENT CORRELATION" value={topAnomaly.analysis.currentCorrelation?.toFixed(2) ?? 'N/A'} size="sm" />
                <SwissMetric label="BASELINE" value={topAnomaly.analysis.baselineCorrelation?.toFixed(2) ?? 'N/A'} size="sm" />
              </div>
              <SwissButton
                onClick={() => router.push(`/relationship/${topAnomaly.assetA.id}-${topAnomaly.assetB.id}`)}
                variant="primary"
                size="md"
              >
                OPEN ANALYSIS →
              </SwissButton>
            </div>
          )}
        </div>
      </div>

      {/* Command Center */}
      <div className="border-b-2 border-black">
        <CommandCenter />
      </div>

      {/* Agent Activity */}
      <AgentActivityPanel />

      {/* Workflow steps */}
      <div className="border-t-2 border-black p-6 pattern-dots">
        <SwissSectionLabel number="06" className="mb-8">HOW LINK WORKS</SwissSectionLabel>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-9 gap-0">
          {[
            { n: '01', label: 'DETECT', desc: 'Scan market relationships' },
            { n: '\u2192', label: '', desc: '' },
            { n: '02', label: 'INTERPRET', desc: 'AI explains the anomaly' },
            { n: '\u2192', label: '', desc: '' },
            { n: '03', label: 'STRATEGIZE', desc: 'Generate pair strategy' },
            { n: '\u2192', label: '', desc: '' },
            { n: '04', label: 'BACKTEST', desc: 'Calculate real metrics' },
            { n: '\u2192', label: '', desc: '' },
            { n: '05', label: 'EXECUTE', desc: 'Paper trade & journal' },
          ].map(({ n, label, desc }, i) => (
            <div key={i} className={`${n === '\u2192' ? 'flex items-center justify-center text-gray-mid text-xl font-black' : 'border-2 border-black p-4'}`}>
              {n !== '\u2192' ? (
                <>
                  <p className="text-label text-accent mono-value font-black">{n}</p>
                  <p className="text-sm font-black uppercase tracking-widest mt-1">{label}</p>
                  <p className="text-label text-gray-mid mt-1">{desc}</p>
                </>
              ) : (
                n
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
