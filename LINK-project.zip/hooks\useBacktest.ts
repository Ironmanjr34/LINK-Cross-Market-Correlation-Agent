import { useState, useCallback } from 'react'
import { runBacktest } from '@/engine/backtest'
import { DEMO_SERIES } from '@/data/demoScenario'
import type { StrategyDefinition, BacktestResult } from '@/types'

export function useBacktest() {
  const [result, setResult] = useState<BacktestResult | null>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const runBacktestForStrategy = useCallback(async (strategy: StrategyDefinition) => {
    setIsRunning(true)
    setError(null)
    setResult(null)

    try {
      // Small delay to show loading state
      await new Promise((r) => setTimeout(r, 800))

      const seriesA = DEMO_SERIES[strategy.assetA]
      const seriesB = DEMO_SERIES[strategy.assetB]

      if (!seriesA || !seriesB) {
        throw new Error(`No data for ${strategy.assetA} or ${strategy.assetB}`)
      }

      const backtestResult = runBacktest(strategy, seriesA, seriesB)
      setResult(backtestResult)
    } catch (err) {
      setError(String(err))
    } finally {
      setIsRunning(false)
    }
  }, [])

  return { result, isRunning, error, runBacktestForStrategy }
}
