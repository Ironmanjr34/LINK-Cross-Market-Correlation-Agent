import { cn } from '@/lib/utils'
import type { ReactNode } from 'react'

interface SwissPanelProps {
  children: ReactNode
  className?: string
  border?: 'all' | 'top' | 'bottom' | 'left' | 'right' | 'none'
  borderWidth?: 2 | 4
  pattern?: 'grid' | 'dots' | 'diagonal' | 'none'
  padding?: 'none' | 'sm' | 'md' | 'lg'
}

export function SwissPanel({
  children,
  className,
  border = 'all',
  borderWidth = 2,
  pattern = 'none',
  padding = 'md',
}: SwissPanelProps) {
  const borderClasses = {
    all: borderWidth === 4 ? 'border-4' : 'border-2',
    top: borderWidth === 4 ? 'border-t-4' : 'border-t-2',
    bottom: borderWidth === 4 ? 'border-b-4' : 'border-b-2',
    left: borderWidth === 4 ? 'border-l-4' : 'border-l-2',
    right: borderWidth === 4 ? 'border-r-4' : 'border-r-2',
    none: '',
  }

  const patternClasses = {
    grid: 'pattern-grid',
    dots: 'pattern-dots',
    diagonal: 'pattern-diagonal',
    none: '',
  }

  const paddingClasses = {
    none: '',
    sm: 'p-3',
    md: 'p-4 md:p-6',
    lg: 'p-6 md:p-10',
  }

  return (
    <div
      className={cn(
        'border-black bg-white',
        borderClasses[border],
        patternClasses[pattern],
        paddingClasses[padding],
        className
      )}
    >
      {children}
    </div>
  )
}
