import type { Anomaly, Asset, RelationshipAnalysis } from '@/types'
import { ANOMALY_Z_THRESHOLD, WATCHLIST_Z_THRESHOLD } from '@/lib/constants'
import { generateId } from '@/lib/utils'

/**
 * Convert a data quality rating to a numeric factor.
 */
function dataQualityFactor(quality: RelationshipAnalysis['dataQuality']): number {
  switch (quality) {
    case 'HIGH': return 1.0
    case 'MEDIUM': return 0.8
    case 'LOW': return 0.5
    case 'INSUFFICIENT': return 0
  }
}

/**
 * Calculate anomaly score.
 * anomalyScore = |zScore| × relationshipStrength × dataQualityFactor
 */
export function calculateAnomalyScore(analysis: RelationshipAnalysis): number {
  if (analysis.zScore === null || analysis.currentCorrelation === null) return 0
  const absZ = Math.abs(analysis.zScore)
  const strength = Math.abs(analysis.currentCorrelation)
  const quality = dataQualityFactor(analysis.dataQuality)
  return absZ * strength * quality
}

export function classifySeverity(
  zScore: number | null
): Anomaly['severity'] {
  if (zScore === null) return 'LOW'
  const absZ = Math.abs(zScore)
  if (absZ >= 3.5) return 'EXTREME'
  if (absZ >= 2.5) return 'HIGH'
  if (absZ >= ANOMALY_Z_THRESHOLD) return 'MODERATE'
  return 'LOW'
}

/**
 * Build an Anomaly object from a RelationshipAnalysis.
 */
export function buildAnomaly(
  assetA: Asset,
  assetB: Asset,
  analysis: RelationshipAnalysis
): Anomaly {
  return {
    id: generateId(),
    assetA,
    assetB,
    analysis,
    anomalyScore: calculateAnomalyScore(analysis),
    severity: classifySeverity(analysis.zScore),
    detectedAt: Date.now(),
  }
}

/**
 * Filter and rank a list of analyses to find anomalies.
 */
export function detectAnomalies(
  analyses: { assetA: Asset; assetB: Asset; analysis: RelationshipAnalysis }[]
): { anomalies: Anomaly[]; watchlist: Anomaly[] } {
  const anomalies: Anomaly[] = []
  const watchlist: Anomaly[] = []

  for (const { assetA, assetB, analysis } of analyses) {
    const absZ = analysis.zScore !== null ? Math.abs(analysis.zScore) : 0

    if (absZ >= ANOMALY_Z_THRESHOLD) {
      anomalies.push(buildAnomaly(assetA, assetB, analysis))
    } else if (absZ >= WATCHLIST_Z_THRESHOLD) {
      watchlist.push(buildAnomaly(assetA, assetB, analysis))
    }
  }

  // Sort by anomaly score descending
  anomalies.sort((a, b) => b.anomalyScore - a.anomalyScore)
  watchlist.sort((a, b) => b.anomalyScore - a.anomalyScore)

  return { anomalies, watchlist }
}
