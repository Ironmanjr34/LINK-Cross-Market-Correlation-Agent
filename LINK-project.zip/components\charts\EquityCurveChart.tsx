'use client'
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts'
import type { EquityPoint } from '@/types'
import { formatDateShort, formatCurrency } from '@/lib/formatters'

interface EquityCurveChartProps {
  data: EquityPoint[]
  initialCapital: number
  height?: number
}

export function EquityCurveChart({ data, initialCapital, height = 240 }: EquityCurveChartProps) {
  const chartData = data.map((p) => ({
    timestamp: p.timestamp,
    equity: +p.equity.toFixed(2),
    drawdown: +(-p.drawdown * 100).toFixed(2),
  }))

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null
    return (
      <div className="bg-white border-2 border-black p-3">
        <p className="text-[10px] uppercase tracking-widest text-[#999999] mb-1">
          {formatDateShort(label)}
        </p>
        {payload.map((p: any) => (
          <p key={p.dataKey} className="text-sm font-bold mono-value">
            {p.dataKey === 'equity'
              ? `EQUITY: ${formatCurrency(p.value)}`
              : `DRAWDOWN: ${p.value.toFixed(1)}%`}
          </p>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Equity curve */}
      <div>
        <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-2">
          CUMULATIVE EQUITY CURVE
        </p>
        <ResponsiveContainer width="100%" height={height}>
          <ComposedChart data={chartData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
            <CartesianGrid strokeDasharray="" stroke="rgba(0,0,0,0.06)" />
            <XAxis
              dataKey="timestamp"
              tickFormatter={(t) => formatDateShort(t)}
              tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
              axisLine={{ stroke: '#000' }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
              axisLine={{ stroke: '#000' }}
              tickLine={false}
              tickFormatter={(v) => `$${(v / 1000).toFixed(1)}k`}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine y={initialCapital} stroke="#000" strokeDasharray="4 4" strokeWidth={1} />
            <Line
              type="monotone"
              dataKey="equity"
              stroke="#000"
              dot={false}
              strokeWidth={2}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      {/* Drawdown */}
      <div>
        <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-2">
          DRAWDOWN PROFILE (%)
        </p>
        <ResponsiveContainer width="100%" height={100}>
          <ComposedChart data={chartData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
            <CartesianGrid strokeDasharray="" stroke="rgba(0,0,0,0.06)" />
            <XAxis
              dataKey="timestamp"
              tickFormatter={(t) => formatDateShort(t)}
              tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
              axisLine={{ stroke: '#000' }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
              axisLine={{ stroke: '#000' }}
              tickLine={false}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine y={0} stroke="#000" strokeWidth={1} />
            <Area
              type="monotone"
              dataKey="drawdown"
              stroke="#FF3000"
              fill="rgba(255,48,0,0.1)"
              dot={false}
              strokeWidth={1.5}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
