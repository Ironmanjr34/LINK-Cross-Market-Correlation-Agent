import { SwissMetric, SwissDivider, SwissButton, SwissTable } from '@/components/swiss'
import { formatReturn, formatPct, formatSharpe, formatCurrency, formatDateShort } from '@/lib/formatters'
import type { BacktestResult, BacktestTrade } from '@/types'

interface BacktestSummaryProps {
  result: BacktestResult
  onRiskCheck?: () => void
}

export function BacktestSummary({ result, onRiskCheck }: BacktestSummaryProps) {
  const tradeColumns = [
    {
      key: 'date',
      header: 'DATE',
      render: (t: BacktestTrade) => (
        <span className="mono-value text-xs">{formatDateShort(t.entryTimestamp)}</span>
      ),
    },
    {
      key: 'direction',
      header: 'DIRECTION',
      render: (t: BacktestTrade) => (
        <span className="text-xs font-bold">{t.direction.replace(/_/g, ' ')}</span>
      ),
    },
    {
      key: 'entryZ',
      header: 'ENTRY Z',
      render: (t: BacktestTrade) => (
        <span className="mono-value text-xs">{t.entryZScore > 0 ? '+' : ''}{t.entryZScore.toFixed(2)}σ</span>
      ),
    },
    {
      key: 'pnl',
      header: 'P&L',
      render: (t: BacktestTrade) => (
        <span className={`mono-value text-xs font-bold ${t.pnl >= 0 ? 'text-black' : 'text-accent'}`}>
          {formatCurrency(t.pnl, 2)}
        </span>
      ),
    },
    {
      key: 'pnlPct',
      header: 'P&L %',
      render: (t: BacktestTrade) => (
        <span className={`mono-value text-xs ${t.pnl >= 0 ? 'text-black' : 'text-accent'}`}>
          {t.pnl >= 0 ? '+' : ''}{(t.pnlPct * 100).toFixed(2)}%
        </span>
      ),
    },
    {
      key: 'exit',
      header: 'EXIT REASON',
      render: (t: BacktestTrade) => (
        <span className="text-xs uppercase tracking-widest">{t.exitReason}</span>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold">BACKTEST RESULTS</p>
          <p className="text-xs text-[#999999] mt-1">
            {formatDateShort(result.period.start)} → {formatDateShort(result.period.end)} — {result.tradeCount} TRADES
          </p>
        </div>
        <p className="text-[11px] uppercase tracking-widest text-[#999999]">
          SOURCE: {result.dataSource}
        </p>
      </div>

      <SwissDivider weight={2} />

      {/* Key metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
        <SwissMetric
          label="TOTAL RETURN"
          value={formatReturn(result.totalReturn)}
          size="md"
          accent={result.totalReturn < 0}
        />
        <SwissMetric label="SHARPE" value={formatSharpe(result.sharpe)} size="md" />
        <SwissMetric label="WIN RATE" value={formatPct(result.winRate)} size="md" />
        <SwissMetric
          label="PROFIT FACTOR"
          value={result.profitFactor === 999 ? '∞' : result.profitFactor.toFixed(2)}
          size="md"
        />
        <SwissMetric
          label="MAX DRAWDOWN"
          value={formatPct(result.maxDrawdown)}
          size="md"
          accent={result.maxDrawdown > 0.15}
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'TRADES', value: result.tradeCount },
          { label: 'WINS', value: result.winCount },
          { label: 'LOSSES', value: result.lossCount },
          { label: 'AVG TRADE', value: formatCurrency(result.avgTradePnl, 2) },
        ].map(({ label, value }) => (
          <div key={label}>
            <p className="text-[11px] uppercase tracking-widest text-[#999999]">{label}</p>
            <p className="text-lg font-black mono-value">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
        {[
          { label: 'BEST TRADE', value: formatCurrency(result.bestTrade, 2) },
          { label: 'WORST TRADE', value: formatCurrency(result.worstTrade, 2) },
          { label: 'FEES', value: `${result.feesBps}bps` },
          { label: 'SLIPPAGE', value: `${result.slippageBps}bps` },
        ].map(({ label, value }) => (
          <div key={label}>
            <p className="text-[11px] uppercase tracking-widest text-[#999999]">{label}</p>
            <p className="font-bold mono-value">{value}</p>
          </div>
        ))}
      </div>

      <p className="text-[10px] text-[#999999] uppercase tracking-widest">
        CALCULATED ON DEMO DATA — NOT FINANCIAL ADVICE — RESULTS DO NOT GUARANTEE FUTURE PERFORMANCE
      </p>

      {onRiskCheck && (
        <SwissButton onClick={onRiskCheck} variant="primary" size="lg">
          RISK CHECK →
        </SwissButton>
      )}

      {/* Trade log */}
      <div>
        <p className="text-xs uppercase tracking-widest font-bold mb-3">TRADE LOG ({result.tradeCount} TRADES)</p>
        <SwissTable
          columns={tradeColumns}
          data={result.trades.slice(0, 20)}
          keyExtractor={(t) => t.id}
          emptyMessage="NO TRADES"
        />
        {result.trades.length > 20 && (
          <p className="text-[11px] text-[#999999] mt-2">Showing 20 of {result.trades.length} trades.</p>
        )}
      </div>
    </div>
  )
}
