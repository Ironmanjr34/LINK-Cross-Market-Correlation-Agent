import type { RelationshipRegime, CorrelationObservation } from '@/types'
import { MIN_SAMPLE_SIZE } from '@/lib/constants'

/**
 * Classify the current relationship regime based on:
 * - current correlation value
 * - z-score magnitude and direction
 * - trend in rolling correlation
 */
export function classifyRegime(
  currentCorrelation: number | null,
  zScore: number | null,
  rollingCorrelation: CorrelationObservation[],
  baselineCorrelation: number | null,
  sampleSize: number
): RelationshipRegime {
  if (sampleSize < MIN_SAMPLE_SIZE || currentCorrelation === null) {
    return 'INSUFFICIENT_DATA'
  }

  const absZ = zScore !== null ? Math.abs(zScore) : 0

  // Extreme break — very high z-score
  if (absZ >= 3.0) {
    return 'BROKEN'
  }

  // Significant divergence
  if (absZ >= 2.0) {
    return 'DIVERGENCE'
  }

  // Check for inversion: sign changed relative to baseline
  if (
    baselineCorrelation !== null &&
    Math.sign(currentCorrelation) !== Math.sign(baselineCorrelation) &&
    Math.abs(currentCorrelation) > 0.2 &&
    Math.abs(baselineCorrelation) > 0.2
  ) {
    return 'INVERTING'
  }

  // Trend analysis from recent rolling observations
  if (rollingCorrelation.length >= 10) {
    const recent = rollingCorrelation.slice(-10)
    const firstHalf = recent.slice(0, 5).reduce((s, r) => s + r.value, 0) / 5
    const secondHalf = recent.slice(5).reduce((s, r) => s + r.value, 0) / 5
    const trend = secondHalf - firstHalf

    if (trend > 0.1) return 'STRENGTHENING'
    if (trend < -0.1) return 'WEAKENING'
  }

  // Absolute correlation classification
  const absCorr = Math.abs(currentCorrelation)
  if (currentCorrelation > 0) {
    if (absCorr >= 0.7) return 'STRONG_POSITIVE'
    if (absCorr >= 0.4) return 'MODERATE_POSITIVE'
  } else {
    if (absCorr >= 0.7) return 'STRONG_NEGATIVE'
    if (absCorr >= 0.4) return 'MODERATE_NEGATIVE'
  }

  return 'NEUTRAL'
}

export function getRegimeSeverity(regime: RelationshipRegime): number {
  const severity: Record<RelationshipRegime, number> = {
    BROKEN: 5,
    DIVERGENCE: 4,
    INVERTING: 4,
    WEAKENING: 3,
    STRENGTHENING: 2,
    STRONG_NEGATIVE: 2,
    MODERATE_NEGATIVE: 1,
    NEUTRAL: 0,
    MODERATE_POSITIVE: 0,
    STRONG_POSITIVE: 0,
    INSUFFICIENT_DATA: -1,
  }
  return severity[regime] ?? 0
}

export function isAnomalousRegime(regime: RelationshipRegime): boolean {
  return ['BROKEN', 'DIVERGENCE', 'INVERTING'].includes(regime)
}
