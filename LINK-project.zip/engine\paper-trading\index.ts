export { openPaperPosition, closePaperPosition } from './executor'
