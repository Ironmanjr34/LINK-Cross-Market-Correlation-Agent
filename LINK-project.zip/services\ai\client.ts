/**
 * Client-side AI service.
 * All requests are proxied through /api/ai to keep the API key server-side.
 */

export type AIRequestType =
  | 'parse_intent'
  | 'explain_anomaly'
  | 'generate_strategy'
  | 'summarize_regime'

export interface AIRequest {
  type: AIRequestType
  payload: Record<string, unknown>
}

export interface AIResponse {
  success: boolean
  data?: Record<string, unknown>
  text?: string
  error?: string
  demo?: boolean
}

export async function callAI(request: AIRequest): Promise<AIResponse> {
  try {
    const response = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    })

    if (!response.ok) {
      throw new Error(`AI API error: ${response.status}`)
    }

    return response.json()
  } catch (error) {
    console.warn('AI service unavailable, using demo response:', error)
    return {
      success: false,
      error: String(error),
      demo: true,
    }
  }
}
