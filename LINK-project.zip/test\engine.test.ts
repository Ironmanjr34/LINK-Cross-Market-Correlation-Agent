/**
 * LINK Quantitative Engine Test Suite
 * Tests: Pearson, Spearman, rolling correlation, z-score, log returns, drawdown,
 * Sharpe ratio, profit factor, hedge ratio, risk rules, paper trading execution.
 * Edge cases: empty arrays, mismatched lengths, zero variance, insufficient samples.
 */

import { pearsonCorrelation } from '../engine/correlation/pearson'
import { spearmanCorrelation } from '../engine/correlation/spearman'
import { logReturns, alignSeries, rollingCorrelation, calculateCorrelationStats } from '../engine/correlation/rolling'
import { estimateHedgeRatio } from '../engine/strategy/hedgeRatio'
import { calcWinRate, calcProfitFactor, calcMaxDrawdown, calcSharpe, calcAnnualizedReturn } from '../engine/backtest/metrics'
import { runBacktest } from '../engine/backtest/runner'
import { generateStrategy } from '../engine/strategy/generator'
import { evaluateRisk } from '../engine/risk/evaluator'
import { openPaperPosition, closePaperPosition } from '../engine/paper-trading/executor'
import { DEMO_SERIES } from '../data/demoScenario'
import type { PriceSeries, BacktestTrade, EquityPoint } from '../types'

let passed = 0
let failed = 0

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`✓ ${testName}`)
    passed++
  } else {
    console.error(`✗ FAIL: ${testName}`)
    failed++
  }
}

function approxEqual(a: number, b: number, epsilon = 0.001): boolean {
  return Math.abs(a - b) < epsilon
}

console.log('--- RUNNING QUANT ENGINE TESTS ---')

// 1. Pearson Correlation
{
  // Perfect positive correlation
  const x = Array.from({ length: 30 }, (_, i) => i + 1)
  const y = Array.from({ length: 30 }, (_, i) => 2 * (i + 1))
  const rPos = pearsonCorrelation(x, y)
  assert(rPos !== null && approxEqual(rPos, 1.0), 'Pearson: perfect positive = 1.0')

  // Perfect negative correlation
  const yNeg = Array.from({ length: 30 }, (_, i) => -2 * (i + 1))
  const rNeg = pearsonCorrelation(x, yNeg)
  assert(rNeg !== null && approxEqual(rNeg, -1.0), 'Pearson: perfect negative = -1.0')

  // Edge cases
  assert(pearsonCorrelation([], []) === null, 'Pearson: empty series returns null')
  assert(pearsonCorrelation([1, 2], [1, 2]) === null, 'Pearson: insufficient sample (<20) returns null')
  assert(pearsonCorrelation(new Array(30).fill(5), Array.from({ length: 30 }, (_, i) => i)) === null, 'Pearson: zero variance returns null')
}

// 2. Spearman Correlation
{
  const x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22]
  const y = x.map((v) => Math.exp(v * 0.1)) // Monotonic non-linear
  const rSpearman = spearmanCorrelation(x, y)
  assert(rSpearman !== null && approxEqual(rSpearman, 1.0, 0.05), 'Spearman: monotonic curve r ~ 1.0')
}

// 3. Log Returns
{
  const prices = [100, 110, 104.5]
  const rets = logReturns(prices)
  assert(rets.length === 2, 'Log returns length = N - 1')
  assert(approxEqual(rets[0], Math.log(1.1)), 'Log returns calculation accurate')
  assert(logReturns([]).length === 0, 'Log returns: empty array returns empty')
  assert(logReturns([100]).length === 0, 'Log returns: single price returns empty')
}

// 4. Series Alignment
{
  const sA: PriceSeries = [{ timestamp: 1, price: 10 }, { timestamp: 2, price: 20 }, { timestamp: 4, price: 40 }]
  const sB: PriceSeries = [{ timestamp: 2, price: 200 }, { timestamp: 3, price: 300 }, { timestamp: 4, price: 400 }]
  const aligned = alignSeries(sA, sB)
  assert(aligned.timestamps.length === 2, 'Series alignment: matches timestamps 2 and 4')
  assert(aligned.pricesA[0] === 20 && aligned.pricesB[0] === 200, 'Series alignment: preserves paired prices')
}

// 5. Drawdown Calculation
{
  const curve: EquityPoint[] = [
    { timestamp: 1, equity: 10000, drawdown: 0 },
    { timestamp: 2, equity: 12000, drawdown: 0 },
    { timestamp: 3, equity: 9600, drawdown: 0.2 }, // 20% DD from peak 12000
    { timestamp: 4, equity: 11000, drawdown: 0.083 },
  ]
  const maxDD = calcMaxDrawdown(curve)
  assert(approxEqual(maxDD, 0.2), 'Max drawdown calculates 20% correctly')
}

// 6. Win Rate & Profit Factor
{
  const mockTrades: BacktestTrade[] = [
    { id: '1', entryTimestamp: 1, exitTimestamp: 2, direction: 'LONG_A_SHORT_B', entryPriceA: 10, entryPriceB: 10, exitPriceA: 12, exitPriceB: 10, entryZScore: 2, exitZScore: 0.5, pnl: 500, pnlPct: 0.05, exitReason: 'TARGET' },
    { id: '2', entryTimestamp: 3, exitTimestamp: 4, direction: 'LONG_A_SHORT_B', entryPriceA: 10, entryPriceB: 10, exitPriceA: 9, exitPriceB: 10, entryZScore: 2, exitZScore: 3.5, pnl: -200, pnlPct: -0.02, exitReason: 'STOP' },
    { id: '3', entryTimestamp: 5, exitTimestamp: 6, direction: 'LONG_A_SHORT_B', entryPriceA: 10, entryPriceB: 10, exitPriceA: 13, exitPriceB: 10, entryZScore: 2, exitZScore: 0.5, pnl: 300, pnlPct: 0.03, exitReason: 'TARGET' },
  ]
  const wr = calcWinRate(mockTrades)
  assert(approxEqual(wr, 2 / 3), 'Win rate: 2 wins / 3 trades = 66.7%')
  const pf = calcProfitFactor(mockTrades)
  assert(approxEqual(pf, 800 / 200), 'Profit factor: 800 gross gain / 200 gross loss = 4.0')
}

// 7. Hedge Ratio (Beta)
{
  const pA = Array.from({ length: 50 }, (_, i) => 100 + i * 2)
  const pB = Array.from({ length: 50 }, (_, i) => 50 + i * 1)
  const hr = estimateHedgeRatio(pA, pB)
  assert(hr !== null && hr > 0, 'Hedge ratio computes positive beta')
}

// 8. Risk Engine Rules
{
  const strat = generateStrategy({ assetA: 'BTC', assetB: 'NASDAQ', type: 'MEAN_REVERSION' })
  const mockResult = {
    strategyId: strat.id,
    totalReturn: 0.12,
    annualizedReturn: 0.24,
    winRate: 0.65,
    profitFactor: 1.8,
    sharpe: 1.4,
    maxDrawdown: 0.07,
    tradeCount: 25,
    winCount: 16,
    lossCount: 9,
    avgTradePnl: 48,
    bestTrade: 320,
    worstTrade: -110,
    trades: [],
    equityCurve: [],
    period: { start: 0, end: 1 },
    dataSource: 'DEMO',
    timeframe: '1D',
    feesBps: 10,
    slippageBps: 5,
  }
  const riskPass = evaluateRisk(strat, mockResult, 180)
  assert(riskPass.overallStatus === 'PASS' || riskPass.overallStatus === 'CONDITIONAL', 'Risk Engine: healthy backtest passes or conditional')
  assert(riskPass.checks.length === 6, 'Risk Engine evaluates all 6 risk checkpoints')
}

// 9. Paper Trading P&L
{
  const strat = generateStrategy({ assetA: 'BTC', assetB: 'NASDAQ', type: 'MEAN_REVERSION' })
  const mockAnalysis = {
    assetA: { id: 'BTC', symbol: 'BTC', name: 'Bitcoin', category: 'crypto' as const },
    assetB: { id: 'NASDAQ', symbol: 'NASDAQ', name: 'Nasdaq', category: 'equity' as const },
    currentCorrelation: 0.18,
    baselineCorrelation: 0.72,
    correlationStdDev: 0.2,
    deviation: -0.54,
    zScore: -2.7,
    rollingCorrelation: [],
    regime: 'DIVERGENCE' as const,
    sampleSize: 90,
    dataQuality: 'HIGH' as const,
    timestamp: Date.now(),
  }
  const pos = openPaperPosition(strat, mockAnalysis, 100000, 20000, 10000)
  assert(pos.status === 'OPEN', 'Paper Trade: position opens with OPEN status')
  assert(pos.quantityA > 0 && pos.quantityB > 0, 'Paper Trade: calculates positive quantities for both legs')

  // Close at gain
  const closed = closePaperPosition(pos, 105000, 19500, 'TARGET', 10, 5)
  assert(closed.status === 'CLOSED', 'Paper Trade: closes with CLOSED status')
  assert(closed.pnl !== undefined && closed.pnl > 0, 'Paper Trade: long A / short B with A up and B down produces positive P&L')
}

// 10. End-to-End Backtest Simulation on Seeded Dataset
{
  const strat = generateStrategy({ assetA: 'BTC', assetB: 'NASDAQ', type: 'MEAN_REVERSION' })
  const res = runBacktest(strat, DEMO_SERIES.BTC, DEMO_SERIES.NASDAQ)
  assert(res.trades.length > 0, `Backtest produces real simulated trades: ${res.trades.length} trades`)
  assert(res.equityCurve.length === DEMO_SERIES.BTC.length, 'Equity curve matches series length')
  assert(!isNaN(res.totalReturn), 'Total return is a valid finite number')
  assert(!isNaN(res.sharpe), 'Sharpe ratio is a valid finite number')
}

console.log(`\nTEST RESULTS: ${passed} passed, ${failed} failed`)
if (failed > 0) {
  process.exit(1)
} else {
  console.log('ALL QUANT ENGINE TESTS PASSED PERFECTLY!')
}
