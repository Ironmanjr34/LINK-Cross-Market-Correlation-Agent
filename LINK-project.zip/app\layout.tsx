import type { Metadata } from 'next'
import './globals.css'
import { NavBar } from '@/components/layout/NavBar'
import { DemoModeBanner } from '@/components/layout/DemoModeBanner'

export const metadata: Metadata = {
  title: 'LINK — Cross-Market Correlation Agent',
  description: 'Detect cross-market relationship breaks, generate testable pair strategies, backtest and paper trade.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="min-h-screen bg-white text-black antialiased">
        <div className="flex flex-col md:flex-row min-h-screen">
          {/* Main Workspace on the Left */}
          <div className="flex-1 min-w-0 flex flex-col">
            <DemoModeBanner />
            <main className="flex-1 w-full">
              {children}
            </main>
          </div>

          {/* Terminal Navigation Bar docked on the Right */}
          <NavBar />
        </div>
      </body>
    </html>
  )
}
