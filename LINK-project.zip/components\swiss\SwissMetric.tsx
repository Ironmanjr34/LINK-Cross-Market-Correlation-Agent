import { cn } from '@/lib/utils'

interface SwissMetricProps {
  label: string
  value: string | number
  subValue?: string
  size?: 'sm' | 'md' | 'lg' | 'xl'
  accent?: boolean
  mono?: boolean
  className?: string
}

export function SwissMetric({
  label,
  value,
  subValue,
  size = 'lg',
  accent = false,
  mono = true,
  className,
}: SwissMetricProps) {
  const sizeClasses = {
    sm: 'text-xl md:text-2xl',
    md: 'text-2xl md:text-3xl',
    lg: 'text-4xl md:text-5xl',
    xl: 'text-5xl md:text-7xl',
  }

  return (
    <div className={cn('flex flex-col', className)}>
      <span className="text-[11px] uppercase tracking-widest text-[#999999] font-medium">
        {label}
      </span>
      <span
        className={cn(
          'font-black leading-none mt-1',
          sizeClasses[size],
          mono && 'mono-value',
          accent ? 'text-accent' : 'text-black'
        )}
      >
        {value}
      </span>
      {subValue && (
        <span className="text-[11px] text-[#999999] mt-1 mono-value">{subValue}</span>
      )}
    </div>
  )
}
