import type { BacktestResult, StrategyDefinition, RiskEvaluation, RiskCheckItem } from '@/types'
import { MIN_SAMPLE_SIZE } from '@/lib/constants'

export function evaluateRisk(
  strategy: StrategyDefinition,
  backtest: BacktestResult,
  sampleSize: number
): RiskEvaluation {
  const checks: RiskCheckItem[] = []

  // 1. Sample size check
  checks.push(
    sampleSize >= 60
      ? { id: 'sample_size', label: 'Sample Size', status: 'PASS', detail: `${sampleSize} observations in historical dataset` }
      : sampleSize >= MIN_SAMPLE_SIZE
      ? { id: 'sample_size', label: 'Sample Size', status: 'WARNING', detail: `${sampleSize} observations — minimum threshold met` }
      : { id: 'sample_size', label: 'Sample Size', status: 'BLOCKED', detail: `Insufficient data: ${sampleSize} observations (min ${MIN_SAMPLE_SIZE})` }
  )

  // 2. Historical drawdown check
  const dd = backtest.maxDrawdown
  checks.push(
    dd < 0.15
      ? { id: 'drawdown', label: 'Historical Drawdown', status: 'PASS', detail: `Max drawdown ${(dd * 100).toFixed(1)}% (within 15% limit)` }
      : dd < 0.30
      ? { id: 'drawdown', label: 'Historical Drawdown', status: 'WARNING', detail: `Max drawdown ${(dd * 100).toFixed(1)}% — moderate tail risk` }
      : { id: 'drawdown', label: 'Historical Drawdown', status: 'BLOCKED', detail: `Max drawdown ${(dd * 100).toFixed(1)}% exceeds 30% risk limit` }
  )

  // 3. Trade count check
  // For extreme z-score divergence (|Z| >= 2.0), 3-10 regime occurrences in 180 days is normal.
  checks.push(
    backtest.tradeCount >= 5
      ? { id: 'trades', label: 'Trade Frequency', status: 'PASS', detail: `${backtest.tradeCount} signals executed in backtest period` }
      : backtest.tradeCount >= 1
      ? { id: 'trades', label: 'Trade Frequency', status: 'WARNING', detail: `${backtest.tradeCount} trades — low signal frequency, monitor closely` }
      : { id: 'trades', label: 'Trade Frequency', status: 'BLOCKED', detail: `0 trades generated — adjust entry threshold |Z| < ${strategy.entryZ}σ` }
  )

  // 4. Profit factor
  const pf = backtest.profitFactor
  checks.push(
    pf >= 1.2
      ? { id: 'profit_factor', label: 'Profit Factor', status: 'PASS', detail: `Profit factor ${pf === 999 ? '∞' : pf.toFixed(2)} indicates positive edge` }
      : pf >= 0.8
      ? { id: 'profit_factor', label: 'Profit Factor', status: 'WARNING', detail: `Profit factor ${pf.toFixed(2)} is near breakeven` }
      : { id: 'profit_factor', label: 'Profit Factor', status: 'BLOCKED', detail: `Profit factor ${pf.toFixed(2)} — strategy underperformed baseline` }
  )

  // 5. Execution cost check
  const totalCostBps = strategy.feesBps + strategy.slippageBps
  checks.push(
    totalCostBps <= 25
      ? { id: 'execution_cost', label: 'Execution Cost', status: 'PASS', detail: `Total transaction drag ${totalCostBps}bps per trade` }
      : totalCostBps <= 60
      ? { id: 'execution_cost', label: 'Execution Cost', status: 'WARNING', detail: `Total cost ${totalCostBps}bps — slippage may erode returns` }
      : { id: 'execution_cost', label: 'Execution Cost', status: 'BLOCKED', detail: `Total cost ${totalCostBps}bps exceeds viability limit` }
  )

  // 6. Concentration check (pair strategy has market-neutral hedged exposure)
  checks.push({
    id: 'concentration',
    label: 'Concentration Risk',
    status: 'WARNING',
    detail: 'Hedged pair allocation — market-neutral exposure to relative spread',
  })

  // Determine overall status
  const hasBlocked = checks.some((c) => c.status === 'BLOCKED')
  const hasWarning = checks.some((c) => c.status === 'WARNING')
  const overallStatus = hasBlocked ? 'BLOCKED' : hasWarning ? 'CONDITIONAL' : 'PASS'

  return { overallStatus, checks, timestamp: Date.now() }
}
