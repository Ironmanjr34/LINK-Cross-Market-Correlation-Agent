'use client'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts'
import type { PriceSeries } from '@/types'
import { normalize } from '@/lib/utils'
import { formatDateShort } from '@/lib/formatters'

interface PriceComparisonChartProps {
  seriesA: PriceSeries
  seriesB: PriceSeries
  labelA: string
  labelB: string
  height?: number
}

export function PriceComparisonChart({
  seriesA,
  seriesB,
  labelA,
  labelB,
  height = 280,
}: PriceComparisonChartProps) {
  const normA = normalize(seriesA.map((p) => p.price))
  const normB = normalize(seriesB.map((p) => p.price))

  const data = seriesA.map((p, i) => ({
    timestamp: p.timestamp,
    [labelA]: normA[i] !== undefined ? +normA[i].toFixed(2) : null,
    [labelB]: normB[i] !== undefined ? +normB[i].toFixed(2) : null,
  }))

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null
    return (
      <div className="bg-white border-2 border-black p-3">
        <p className="text-label uppercase tracking-widest text-gray-mid mb-1">
          {formatDateShort(label)}
        </p>
        {payload.map((p: any) => (
          <p key={p.name} className="text-sm font-bold mono-value">
            {p.name}: {p.value?.toFixed(2)}
          </p>
        ))}
      </div>
    )
  }

  return (
    <div>
      <p className="text-label uppercase tracking-widest text-gray-mid mb-2">
        NORMALIZED TO 100 — PRICE COMPARISON
      </p>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid strokeDasharray="" stroke="rgba(0,0,0,0.06)" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(t) => formatDateShort(t)}
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#999' }}
            axisLine={{ stroke: '#000' }}
            tickLine={false}
            tickFormatter={(v) => v.toFixed(0)}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={100} stroke="#000" strokeDasharray="4 4" strokeWidth={1} />
          <Line
            type="monotone"
            dataKey={labelA}
            stroke="#000000"
            dot={false}
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey={labelB}
            stroke="#999999"
            dot={false}
            strokeWidth={1.5}
            strokeDasharray="6 3"
          />
          <Legend
            wrapperStyle={{ fontSize: '10px', fontFamily: 'Inter', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em' }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
