import { cn } from '@/lib/utils'

export type Status = 'PASS' | 'WARNING' | 'BLOCKED' | 'CONDITIONAL' | 'LIVE' | 'DEMO' | 'INFO' | 'NEUTRAL'

interface SwissStatusProps {
  status: Status
  label?: string
  size?: 'sm' | 'md'
  className?: string
}

const STATUS_CONFIG: Record<Status, { bg: string; text: string; border: string }> = {
  PASS: { bg: 'bg-black', text: 'text-white', border: 'border-black' },
  WARNING: { bg: 'bg-white', text: 'text-accent', border: 'border-accent' },
  BLOCKED: { bg: 'bg-accent', text: 'text-white', border: 'border-accent' },
  CONDITIONAL: { bg: 'bg-white', text: 'text-black', border: 'border-black' },
  LIVE: { bg: 'bg-black', text: 'text-white', border: 'border-black' },
  DEMO: { bg: 'bg-muted', text: 'text-black', border: 'border-black' },
  INFO: { bg: 'bg-white', text: 'text-black', border: 'border-black' },
  NEUTRAL: { bg: 'bg-white', text: 'text-[#999999]', border: 'border-[#E8E8E8]' },
}

export function SwissStatus({ status, label, size = 'sm', className }: SwissStatusProps) {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.NEUTRAL
  return (
    <span
      className={cn(
        'inline-flex items-center border font-bold uppercase tracking-widest',
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-3 py-1 text-xs',
        config.bg,
        config.text,
        config.border,
        className
      )}
    >
      {label ?? status}
    </span>
  )
}
