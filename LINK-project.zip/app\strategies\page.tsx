﻿'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { SwissPanel, SwissButton, SwissMetric, SwissSectionLabel, SwissDivider, SwissStatus } from '@/components/swiss'
import { StrategyRuleCard } from '@/components/domain/StrategyRuleCard'
import { useLinkStore } from '@/services/persistence/store'
import { generateStrategy } from '@/engine/strategy'
import { DEMO_ASSETS } from '@/lib/constants'
import type { StrategyType } from '@/types'

const STRATEGY_TYPES: { id: StrategyType; label: string; desc: string }[] = [
  { id: 'MEAN_REVERSION', label: 'MEAN REVERSION', desc: 'Trade when correlation deviates and historically tends to normalize.' },
  { id: 'BREAKOUT', label: 'REGIME BREAKOUT', desc: 'Trade when the relationship breaks a historical range and continues.' },
  { id: 'RELATIVE_STRENGTH', label: 'RELATIVE STRENGTH', desc: 'Compare normalized returns between assets.' },
  { id: 'CROSS_MARKET_ROTATION', label: 'CROSS-MARKET ROTATION', desc: 'Use relationship changes as a signal for allocation shifts.' },
]

export default function StrategiesPage() {
  const router = useRouter()
  const { strategies, currentStrategy, setCurrentStrategy, addStrategy, addJournalEntry } = useLinkStore()
  const [assetA, setAssetA] = useState('BTC')
  const [assetB, setAssetB] = useState('NASDAQ')
  const [strategyType, setStrategyType] = useState<StrategyType>('MEAN_REVERSION')
  const [entryZ, setEntryZ] = useState(2.0)
  const [exitZ, setExitZ] = useState(0.5)
  const [stopZ, setStopZ] = useState(3.0)
  const [lookback, setLookback] = useState(30)

  const handleGenerate = () => {
    const strategy = generateStrategy({
      assetA,
      assetB,
      type: strategyType,
      entryZ,
      exitZ,
      stopZ,
      lookback,
    })
    setCurrentStrategy(strategy)
    addStrategy(strategy)
    addJournalEntry({
      type: 'STRATEGY_GENERATED',
      title: 'STRATEGY GENERATED',
      detail: strategy.name,
      pair: `${assetA}-${assetB}`,
      value: strategyType,
      status: 'SUCCESS',
    })
  }

  return (
    <div>
      <div className="border-b-4 border-black px-6 py-8">
        <p className="text-label uppercase tracking-widest text-gray-mid mb-2">05 / STRATEGY BUILDER</p>
        <h1 className="text-display-md font-black tracking-tighter">STRATEGY BUILDER</h1>
        <p className="text-gray-dark mt-2">Configure and generate correlation-based pair strategies.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 border-b-2 border-black">
        {/* Builder */}
        <div className="lg:col-span-5 border-r-0 lg:border-r-2 border-black border-b-2 lg:border-b-0 p-6">
          <SwissSectionLabel className="mb-6">CONFIGURE STRATEGY</SwissSectionLabel>

          <div className="space-y-5">
            {/* Strategy type */}
            <div>
              <p className="text-label uppercase tracking-widest text-gray-mid mb-2">STRATEGY TYPE</p>
              <div className="space-y-2">
                {STRATEGY_TYPES.map(st => (
                  <button
                    key={st.id}
                    onClick={() => setStrategyType(st.id)}
                    className={`w-full text-left border-2 p-3 transition-colors duration-150 ${
                      strategyType === st.id ? 'border-black bg-black text-white' : 'border-gray-subtle hover:border-black'
                    }`}
                  >
                    <p className="text-label uppercase tracking-widest font-bold">{st.label}</p>
                    <p className="text-xs mt-0.5 ${strategyType === st.id ? 'text-white/70' : 'text-gray-mid'}">{st.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Assets */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">ASSET A</label>
                <select value={assetA} onChange={e => setAssetA(e.target.value)}
                  className="w-full border-2 border-black px-2 py-2 text-sm font-bold focus:outline-none focus:border-accent bg-white">
                  {DEMO_ASSETS.map(a => <option key={a.id} value={a.id}>{a.symbol}</option>)}
                </select>
              </div>
              <div>
                <label className="text-label uppercase tracking-widest text-gray-mid block mb-1">ASSET B</label>
                <select value={assetB} onChange={e => setAssetB(e.target.value)}
                  className="w-full border-2 border-black px-2 py-2 text-sm font-bold focus:outline-none focus:border-accent bg-white">
                  {DEMO_ASSETS.filter(a => a.id !== assetA).map(a => <option key={a.id} value={a.id}>{a.symbol}</option>)}
                </select>
              </div>
            </div>

            {/* Z thresholds */}
            <div>
              <p className="text-label uppercase tracking-widest text-gray-mid mb-2">SIGNAL RULES</p>
              <div className="space-y-3">
                {[
                  { label: 'ENTRY Z', value: entryZ, set: setEntryZ, min: 1.0, max: 4.0, step: 0.1 },
                  { label: 'EXIT Z', value: exitZ, set: setExitZ, min: 0.0, max: 2.0, step: 0.1 },
                  { label: 'STOP Z', value: stopZ, set: setStopZ, min: 2.0, max: 5.0, step: 0.1 },
                ].map(({ label, value, set, min, max, step }) => (
                  <div key={label} className="flex items-center gap-3">
                    <label className="text-label uppercase tracking-widest w-20 shrink-0">{label}</label>
                    <input
                      type="range" min={min} max={max} step={step} value={value}
                      onChange={e => set(parseFloat(e.target.value))}
                      className="flex-1 accent-black"
                    />
                    <span className="mono-value text-sm font-bold w-12 text-right">{value.toFixed(1)}σ</span>
                  </div>
                ))}
              </div>
            </div>

            <SwissButton onClick={handleGenerate} variant="primary" size="lg" className="w-full">
              GENERATE STRATEGY
            </SwissButton>
          </div>
        </div>

        {/* Current strategy */}
        <div className="lg:col-span-7 p-6">
          {currentStrategy ? (
            <>
              <SwissSectionLabel className="mb-4">GENERATED STRATEGY</SwissSectionLabel>
              <StrategyRuleCard
                strategy={currentStrategy}
                onRunBacktest={() => router.push('/backtest')}
              />
            </>
          ) : (
            <div className="h-full flex items-center justify-center border-2 border-gray-subtle">
              <div className="text-center p-8">
                <p className="text-label uppercase tracking-widest text-gray-mid">NO STRATEGY GENERATED</p>
                <p className="text-sm text-gray-mid mt-1">Configure parameters and click GENERATE STRATEGY.</p>
              </div>
            </div>
          )}

          {/* Strategy history */}
          {strategies.length > 0 && (
            <div className="mt-6">
              <SwissSectionLabel className="mb-3">STRATEGY HISTORY</SwissSectionLabel>
              <div className="space-y-2">
                {strategies.slice(-5).reverse().map(s => (
                  <div
                    key={s.id}
                    onClick={() => setCurrentStrategy(s)}
                    className="border border-gray-subtle p-3 cursor-pointer hover:border-black transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-bold">{s.name}</p>
                      <p className="text-label text-gray-mid">{s.assetA} / {s.assetB} — {s.type}</p>
                    </div>
                    <span className="text-label text-gray-mid">SELECT →</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="border-t-2 border-black px-6 py-4">
        <p className="text-label text-gray-mid uppercase tracking-widest">STRATEGIES ARE HYPOTHETICAL — NOT FINANCIAL ADVICE — CALCULATED ON DEMO DATA</p>
      </div>
    </div>
  )
}
