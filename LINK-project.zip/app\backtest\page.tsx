'use client'
import { useLinkStore } from '@/services/persistence/store'
import { useBacktest } from '@/hooks/useBacktest'
import { useEffect, useMemo, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { SwissButton, SwissSectionLabel, SwissStatus } from '@/components/swiss'
import { BacktestSummary } from '@/components/domain/BacktestSummary'
import { RiskCheckList } from '@/components/domain/RiskCheckList'
import { EquityCurveChart } from '@/components/charts/EquityCurveChart'
import { evaluateRisk } from '@/engine/risk'
import { usePaperTrading } from '@/hooks/usePaperTrading'
import { DEMO_SERIES, DEFAULT_SCAN_PAIRS } from '@/data/demoScenario'
import { ASSET_MAP } from '@/lib/constants'
import { calculateCorrelationStats } from '@/engine/correlation'
import { classifyRegime } from '@/engine/regime'
import { generateStrategy } from '@/engine/strategy'
import { formatReturn } from '@/lib/formatters'
import { ArrowRight, Play, CheckCircle } from 'lucide-react'

export default function BacktestPage() {
  const router = useRouter()
  const {
    currentStrategy,
    setCurrentStrategy,
    currentBacktest,
    currentRisk,
    setCurrentBacktest,
    setCurrentRisk,
    addJournalEntry,
    currentAnalysis,
  } = useLinkStore()

  const { result, isRunning, error, runBacktestForStrategy } = useBacktest()
  const { openPosition } = usePaperTrading()
  const riskSectionRef = useRef<HTMLDivElement>(null)

  // Ensure an analysis object is always available for the current pair
  const analysisToUse = useMemo(() => {
    if (
      currentAnalysis &&
      currentStrategy &&
      currentAnalysis.assetA.id === currentStrategy.assetA &&
      currentAnalysis.assetB.id === currentStrategy.assetB
    ) {
      return currentAnalysis
    }
    if (!currentStrategy) return null
    const sA = DEMO_SERIES[currentStrategy.assetA]
    const sB = DEMO_SERIES[currentStrategy.assetB]
    if (!sA || !sB) return null
    const stats = calculateCorrelationStats(sA, sB, currentStrategy.lookback || 30)
    const regime = classifyRegime(
      stats.currentCorrelation,
      stats.zScore,
      stats.rolling,
      stats.baselineCorrelation,
      stats.sampleSize
    )
    const assetAObj = ASSET_MAP[currentStrategy.assetA] || {
      id: currentStrategy.assetA,
      symbol: currentStrategy.assetA,
      name: currentStrategy.assetA,
      category: 'crypto' as const,
    }
    const assetBObj = ASSET_MAP[currentStrategy.assetB] || {
      id: currentStrategy.assetB,
      symbol: currentStrategy.assetB,
      name: currentStrategy.assetB,
      category: 'equity' as const,
    }

    return {
      assetA: assetAObj,
      assetB: assetBObj,
      currentCorrelation: stats.currentCorrelation,
      baselineCorrelation: stats.baselineCorrelation,
      correlationStdDev: stats.correlationStdDev,
      deviation:
        stats.currentCorrelation !== null && stats.baselineCorrelation !== null
          ? stats.currentCorrelation - stats.baselineCorrelation
          : null,
      zScore: stats.zScore,
      rollingCorrelation: stats.rolling,
      regime,
      sampleSize: stats.sampleSize,
      dataQuality: 'HIGH' as const,
      timestamp: Date.now(),
    }
  }, [currentAnalysis, currentStrategy])

  // Sync result to store and auto-evaluate risk check
  useEffect(() => {
    if (result && currentStrategy) {
      setCurrentBacktest(result)
      const seriesA = DEMO_SERIES[currentStrategy.assetA]
      const risk = evaluateRisk(currentStrategy, result, seriesA?.length ?? 180)
      setCurrentRisk(risk)

      addJournalEntry({
        type: 'BACKTEST_COMPLETE',
        title: 'BACKTEST COMPLETE',
        detail: `${result.tradeCount} trades — Total return: ${(result.totalReturn * 100).toFixed(2)}%`,
        pair: `${currentStrategy.assetA}-${currentStrategy.assetB}`,
        value: formatReturn(result.totalReturn),
        status: result.totalReturn >= 0 ? 'SUCCESS' : 'WARNING',
      })
    }
  }, [result, currentStrategy, setCurrentBacktest, setCurrentRisk, addJournalEntry])

  const backtestResult = result ?? currentBacktest

  const handleRiskCheck = () => {
    if (!backtestResult || !currentStrategy) return
    const seriesA = DEMO_SERIES[currentStrategy.assetA]
    const risk = evaluateRisk(currentStrategy, backtestResult, seriesA?.length ?? 180)
    setCurrentRisk(risk)
    addJournalEntry({
      type: 'RISK_CHECK',
      title: 'RISK CHECK EVALUATED',
      detail: `${risk.overallStatus} — ${risk.checks.filter((c) => c.status === 'PASS').length}/${risk.checks.length} checks passed`,
      pair: `${currentStrategy.assetA}-${currentStrategy.assetB}`,
      value: risk.overallStatus,
      status: risk.overallStatus === 'BLOCKED' ? 'WARNING' : 'SUCCESS',
    })

    // Scroll to risk section
    setTimeout(() => {
      riskSectionRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, 100)
  }

  const handleStartPaperTrade = () => {
    if (!currentStrategy) return
    const analysis = analysisToUse || {
      assetA: { id: currentStrategy.assetA, symbol: currentStrategy.assetA, name: currentStrategy.assetA, category: 'crypto' },
      assetB: { id: currentStrategy.assetB, symbol: currentStrategy.assetB, name: currentStrategy.assetB, category: 'equity' },
      currentCorrelation: 0.18,
      baselineCorrelation: 0.72,
      correlationStdDev: 0.2,
      deviation: -0.54,
      zScore: -2.7,
      rollingCorrelation: [],
      regime: 'DIVERGENCE',
      sampleSize: 90,
      dataQuality: 'HIGH',
      timestamp: Date.now(),
    }

    openPosition(currentStrategy, analysis as any)
    router.push('/paper')
  }

  const handleLoadDefaultStrategy = (pair: [string, string]) => {
    const strat = generateStrategy({
      assetA: pair[0],
      assetB: pair[1],
      type: 'MEAN_REVERSION',
      entryZ: 2.0,
      exitZ: 0.5,
      stopZ: 3.0,
      lookback: 30,
    })
    setCurrentStrategy(strat)
    runBacktestForStrategy(strat)
  }

  return (
    <div className="bg-white">
      <div className="border-b-4 border-black px-6 py-8 bg-white">
        <p className="text-[11px] uppercase tracking-widest text-[#999999] mb-2 font-bold">06 / BACKTEST ENGINE</p>
        <h1 className="text-3xl md:text-5xl font-black tracking-tighter">BACKTEST ENGINE</h1>
        <p className="text-[#444444] mt-2 text-sm">
          Chronological event-driven pair simulation. No look-ahead bias. Slippage and transaction costs included.
        </p>
      </div>

      {/* Strategy selection */}
      {!currentStrategy ? (
        <div className="p-6 md:p-8 border-b-2 border-black bg-white">
          <div className="border-2 border-black p-6 md:p-8 max-w-3xl">
            <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-2">
              SELECT ANOMALY PAIR TO TEST
            </p>
            <h2 className="text-xl font-black mb-3">NO STRATEGY ACTIVE</h2>
            <p className="text-sm text-[#444444] mb-6 leading-relaxed">
              Select a recommended cross-market anomaly below to immediately generate and backtest a pair strategy:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              {[
                { pair: ['BTC', 'NASDAQ'] as [string, string], label: 'BTC / NASDAQ', z: '-2.7σ', desc: 'Regime Break (Recommended Demo)' },
                { pair: ['ETH', 'TECH'] as [string, string], label: 'ETH / TECH', z: '-2.2σ', desc: 'Correlation Weakening' },
                { pair: ['SOL', 'NASDAQ'] as [string, string], label: 'SOL / NASDAQ', z: '-3.1σ', desc: 'Extreme Divergence' },
                { pair: ['BTC', 'GOLD'] as [string, string], label: 'BTC / GOLD', z: '+2.1σ', desc: 'Safe Haven Decoupling' },
              ].map(({ pair, label, z, desc }) => (
                <button
                  key={label}
                  onClick={() => handleLoadDefaultStrategy(pair)}
                  className="border-2 border-black p-4 text-left hover:bg-black hover:text-white transition-colors group flex flex-col justify-between"
                >
                  <div className="flex justify-between items-start">
                    <span className="font-black text-base">{label}</span>
                    <span className="mono-value font-bold text-accent group-hover:text-white">{z}</span>
                  </div>
                  <span className="text-[11px] text-[#999999] group-hover:text-white/80 uppercase tracking-wider mt-2">
                    {desc} &rarr;
                  </span>
                </button>
              ))}
            </div>

            <SwissButton onClick={() => router.push('/strategies')} variant="secondary" size="md">
              CUSTOM STRATEGY BUILDER &rarr;
            </SwissButton>
          </div>
        </div>
      ) : (
        <div className="p-6 md:p-8 border-b-2 border-black bg-white">
          <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
            <div>
              <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold">CURRENT STRATEGY</p>
              <h2 className="text-2xl font-black mt-0.5">{currentStrategy.name}</h2>
              <p className="text-xs text-[#444444] mt-1 font-mono">
                {currentStrategy.assetA} / {currentStrategy.assetB} | ENTRY |Z| &gt; {currentStrategy.entryZ}σ | EXIT |Z| &lt; {currentStrategy.exitZ}σ | STOP |Z| &gt; {currentStrategy.stopZ}σ
              </p>
            </div>
            <div className="flex items-center gap-3">
              <SwissButton
                onClick={() => runBacktestForStrategy(currentStrategy)}
                isLoading={isRunning}
                variant="primary"
                size="lg"
              >
                {isRunning ? 'RUNNING BACKTEST...' : 'RE-RUN BACKTEST'}
              </SwissButton>
              <SwissButton
                onClick={handleStartPaperTrade}
                variant="secondary"
                size="lg"
              >
                DIRECT PAPER TRADE &rarr;
              </SwissButton>
            </div>
          </div>

          {error && (
            <div className="border-2 border-accent p-4 mt-4">
              <p className="text-[11px] font-bold text-accent uppercase tracking-widest">BACKTEST ERROR</p>
              <p className="text-sm mt-1">{error}</p>
            </div>
          )}
        </div>
      )}

      {/* Loading state */}
      {isRunning && (
        <div className="p-6 border-b-2 border-black bg-white">
          <div className="border-2 border-black p-8 text-center bg-white">
            <div className="w-6 h-6 border-2 border-black border-t-transparent animate-spin mx-auto mb-3" />
            <p className="text-xs uppercase tracking-widest font-bold">RUNNING EVENT-DRIVEN SIMULATION...</p>
            <p className="text-xs text-[#999999] mt-1">Executing chronological candle loop with transaction drag modeling.</p>
          </div>
        </div>
      )}

      {/* Results & Scorecards */}
      {backtestResult && !isRunning && (
        <>
          {/* Equity curve */}
          {backtestResult.equityCurve.length > 0 && (
            <div className="p-6 md:p-8 border-b-2 border-black bg-white">
              <EquityCurveChart
                data={backtestResult.equityCurve}
                initialCapital={currentStrategy?.capitalAllocation ?? 10000}
              />
            </div>
          )}

          {/* Performance summary */}
          <div className="p-6 md:p-8 border-b-2 border-black bg-white">
            <BacktestSummary
              result={backtestResult}
              onRiskCheck={handleRiskCheck}
            />
          </div>

          {/* Risk check results */}
          <div ref={riskSectionRef} className="p-6 md:p-8 border-b-2 border-black bg-white">
            <div className="flex items-center justify-between mb-4">
              <SwissSectionLabel number="03">RISK ENGINE EVALUATION</SwissSectionLabel>
              <SwissButton onClick={handleStartPaperTrade} variant="primary" size="md">
                EXECUTE PAPER TRADE &rarr;
              </SwissButton>
            </div>
            {currentRisk ? (
              <RiskCheckList
                risk={currentRisk}
                onStartPaperTrade={handleStartPaperTrade}
              />
            ) : (
              <div className="border-2 border-black p-6 flex items-center justify-between">
                <div>
                  <p className="font-bold text-sm">RISK CHECK PENDING</p>
                  <p className="text-xs text-[#999999] mt-0.5">Evaluate drawdown, liquidity, and sample size before paper trade.</p>
                </div>
                <SwissButton onClick={handleRiskCheck} variant="primary" size="md">
                  EVALUATE RISK NOW
                </SwissButton>
              </div>
            )}
          </div>
        </>
      )}

      <div className="border-t-2 border-black px-6 py-4 bg-[#F2F2F2]">
        <p className="text-[10px] text-[#999999] uppercase tracking-widest">
          CHRONOLOGICAL EVENT LOOP — NO LOOK-AHEAD BIAS — FEES: {currentStrategy?.feesBps ?? 10}BPS, SLIPPAGE: {currentStrategy?.slippageBps ?? 5}BPS — CALCULATED ON DEMO DATA
        </p>
      </div>
    </div>
  )
}
