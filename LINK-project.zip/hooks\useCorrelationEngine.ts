import { useMemo } from 'react'
import { calculateCorrelationStats } from '@/engine/correlation'
import { classifyRegime } from '@/engine/regime'
import type { RelationshipAnalysis, Asset, CorrelationMethod } from '@/types'
import { DEMO_SERIES } from '@/data/demoScenario'
import { ROLLING_WINDOW, DATA_SOURCE_LABEL } from '@/lib/constants'

export function useRelationshipAnalysis(
  assetA: Asset | null,
  assetB: Asset | null,
  window = ROLLING_WINDOW,
  method: CorrelationMethod = 'pearson'
): RelationshipAnalysis | null {
  return useMemo(() => {
    if (!assetA || !assetB) return null

    const seriesA = DEMO_SERIES[assetA.id]
    const seriesB = DEMO_SERIES[assetB.id]

    if (!seriesA || !seriesB) return null

    const stats = calculateCorrelationStats(seriesA, seriesB, window, method)

    const dataQuality: RelationshipAnalysis['dataQuality'] =
      stats.sampleSize >= 100
        ? 'HIGH'
        : stats.sampleSize >= 50
        ? 'MEDIUM'
        : stats.sampleSize >= 20
        ? 'LOW'
        : 'INSUFFICIENT'

    const regime = classifyRegime(
      stats.currentCorrelation,
      stats.zScore,
      stats.rolling,
      stats.baselineCorrelation,
      stats.sampleSize
    )

    return {
      assetA,
      assetB,
      currentCorrelation: stats.currentCorrelation,
      baselineCorrelation: stats.baselineCorrelation,
      correlationStdDev: stats.correlationStdDev,
      deviation:
        stats.currentCorrelation !== null && stats.baselineCorrelation !== null
          ? stats.currentCorrelation - stats.baselineCorrelation
          : null,
      zScore: stats.zScore,
      rollingCorrelation: stats.rolling,
      regime,
      sampleSize: stats.sampleSize,
      dataQuality,
      timestamp: Date.now(),
    }
  }, [assetA, assetB, window, method])
}
