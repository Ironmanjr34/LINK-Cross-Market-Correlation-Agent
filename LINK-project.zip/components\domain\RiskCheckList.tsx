import { SwissStatus, SwissButton } from '@/components/swiss'
import type { RiskEvaluation } from '@/types'
import { AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react'

interface RiskCheckListProps {
  risk: RiskEvaluation
  onStartPaperTrade?: () => void
}

export function RiskCheckList({ risk, onStartPaperTrade }: RiskCheckListProps) {
  const isPass = risk.overallStatus === 'PASS'
  const isConditional = risk.overallStatus === 'CONDITIONAL'
  const isBlocked = risk.overallStatus === 'BLOCKED'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <p className="text-[11px] uppercase tracking-widest text-[#999999] mb-1 font-bold">OVERALL RISK STATUS</p>
          <div className="flex items-center gap-2">
            <SwissStatus
              status={isPass ? 'PASS' : isBlocked ? 'BLOCKED' : 'CONDITIONAL'}
              label={isPass ? 'PASS' : isConditional ? 'CONDITIONAL PASS' : 'BLOCKED'}
              size="md"
            />
            <span className="text-xs text-[#444444] font-mono">
              ({risk.checks.filter((c) => c.status === 'PASS').length}/{risk.checks.length} checks passed)
            </span>
          </div>
        </div>

        {onStartPaperTrade && !isBlocked && (
          <SwissButton onClick={onStartPaperTrade} variant="primary" size="lg">
            START PAPER TRADE →
          </SwissButton>
        )}
      </div>

      {/* Check item list */}
      <div className="border-t-2 border-black pt-4 space-y-3">
        {risk.checks.map((check) => (
          <div
            key={check.id}
            className="flex items-start justify-between gap-4 pb-3 border-b border-[#E8E8E8] last:border-0"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2">
                {check.status === 'PASS' ? (
                  <CheckCircle size={14} className="text-black" />
                ) : check.status === 'WARNING' ? (
                  <AlertTriangle size={14} className="text-accent" />
                ) : (
                  <ShieldAlert size={14} className="text-accent" />
                )}
                <p className="text-sm font-bold uppercase tracking-widest">{check.label}</p>
              </div>
              <p className="text-[11px] text-[#444444] mt-0.5 ml-5">{check.detail}</p>
            </div>
            <SwissStatus status={check.status} size="sm" />
          </div>
        ))}
      </div>

      <p className="text-[10px] text-[#999999] uppercase tracking-widest">
        RISK EVALUATION IS BASED ON HISTORICAL BACKTEST RESULTS ON DEMO DATA.
        PAST PERFORMANCE DOES NOT GUARANTEE FUTURE RESULTS.
      </p>

      {/* Conditional guidance */}
      {isConditional && onStartPaperTrade && (
        <div className="border-2 border-black p-4 bg-[#F2F2F2] flex items-center justify-between flex-wrap gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-black">
              CONDITIONAL APPROVAL GRANTED FOR PAPER TRADING
            </p>
            <p className="text-[11px] text-[#444444] mt-0.5">
              Strategy satisfies baseline risk bounds. Position will execute with automated stop-loss guards.
            </p>
          </div>
          <SwissButton onClick={onStartPaperTrade} variant="primary" size="md">
            PROCEED TO PAPER TRADING →
          </SwissButton>
        </div>
      )}

      {/* Blocked fallback with paper simulator override */}
      {isBlocked && (
        <div className="border-2 border-accent p-4 bg-white space-y-3">
          <div>
            <p className="text-[11px] font-bold text-accent uppercase tracking-widest flex items-center gap-1.5">
              <ShieldAlert size={14} />
              PRODUCTION RISK CRITERIA UNMET
            </p>
            <p className="text-xs text-[#444444] mt-1">
              One or more statistical checks flagged elevated historical risk. Live production trading would be blocked.
            </p>
          </div>

          {onStartPaperTrade && (
            <div className="pt-2 border-t border-accent/30 flex items-center justify-between flex-wrap gap-3">
              <p className="text-[10px] uppercase tracking-widest text-[#999999]">
                ALLOW EXPERIMENTAL PAPER TESTING (SIMULATED ONLY):
              </p>
              <SwissButton onClick={onStartPaperTrade} variant="secondary" size="sm">
                OVERRIDE &amp; TEST IN PAPER SIMULATOR →
              </SwissButton>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
