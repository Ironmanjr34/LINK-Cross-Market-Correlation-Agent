﻿import { SwissMetric, SwissStatus, SwissDivider } from '@/components/swiss'
import { formatCorrelation, formatZScore } from '@/lib/formatters'
import { REGIME_LABELS } from '@/lib/constants'
import type { RelationshipAnalysis } from '@/types'

interface RelationshipHeaderProps {
  assetA: string
  assetB: string
  analysis: RelationshipAnalysis
}

export function RelationshipHeader({ assetA, assetB, analysis }: RelationshipHeaderProps) {
  const absZ = Math.abs(analysis.zScore ?? 0)
  const isAnomaly = absZ >= 2.0

  return (
    <div>
      <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
        <div>
          <p className="text-label uppercase tracking-widest text-gray-mid">CROSS-MARKET RELATIONSHIP</p>
          <h1 className="text-display-md font-black tracking-tighter leading-none mt-1">
            {assetA} / {assetB}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <SwissStatus
            status={isAnomaly ? (absZ >= 3 ? 'BLOCKED' : 'WARNING') : 'PASS'}
            label={REGIME_LABELS[analysis.regime] ?? analysis.regime}
            size="md"
          />
          <SwissStatus status="DEMO" label="DEMO DATA" />
        </div>
      </div>

      <SwissDivider weight={2} className="mb-6" />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
        <SwissMetric
          label="CURRENT CORRELATION"
          value={formatCorrelation(analysis.currentCorrelation)}
          size="md"
          accent={isAnomaly}
        />
        <SwissMetric
          label="BASELINE"
          value={formatCorrelation(analysis.baselineCorrelation)}
          size="md"
        />
        <SwissMetric
          label="DEVIATION"
          value={
            analysis.deviation !== null
              ? `${analysis.deviation >= 0 ? '+' : ''}${analysis.deviation.toFixed(2)}`
              : 'N/A'
          }
          size="md"
          accent={isAnomaly}
        />
        <SwissMetric
          label="Z-SCORE"
          value={formatZScore(analysis.zScore)}
          size="md"
          accent={absZ >= 2}
        />
      </div>

      <div className="mt-4 flex items-center gap-6 text-label uppercase tracking-widest text-gray-mid">
        <span>OBSERVATIONS: <span className="text-black font-bold mono-value">{analysis.sampleSize}</span></span>
        <span>DATA QUALITY: <span className="text-black font-bold">{analysis.dataQuality}</span></span>
        <span>SOURCE: <span className="text-black font-bold">DEMO / SEEDED</span></span>
      </div>
    </div>
  )
}
