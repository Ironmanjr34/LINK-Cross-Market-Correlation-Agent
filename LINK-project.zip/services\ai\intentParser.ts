import { callAI } from './client'
import type { StrategyType } from '@/types'
import { parseAIStrategy } from '@/engine/strategy'

export interface ParsedIntent {
  assetA: string
  assetB: string
  type: StrategyType
  lookback: number
  entryZ: number
  exitZ: number
  stopZ: number
  confidence: number
}

const DEMO_INTENTS: Record<string, ParsedIntent> = {
  default: {
    assetA: 'BTC',
    assetB: 'NASDAQ',
    type: 'MEAN_REVERSION',
    lookback: 30,
    entryZ: 2.0,
    exitZ: 0.5,
    stopZ: 3.0,
    confidence: 0.88,
  },
}

export async function parseUserIntent(query: string): Promise<ParsedIntent> {
  const response = await callAI({
    type: 'parse_intent',
    payload: { query },
  })

  if (response.success && response.data) {
    const d = response.data as Partial<ParsedIntent>
    return {
      assetA: d.assetA ?? 'BTC',
      assetB: d.assetB ?? 'NASDAQ',
      type: (d.type as StrategyType) ?? 'MEAN_REVERSION',
      lookback: d.lookback ?? 30,
      entryZ: d.entryZ ?? 2.0,
      exitZ: d.exitZ ?? 0.5,
      stopZ: d.stopZ ?? 3.0,
      confidence: d.confidence ?? 0.8,
    }
  }

  return DEMO_INTENTS.default
}
