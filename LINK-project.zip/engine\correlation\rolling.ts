import { pearsonCorrelation } from './pearson'
import { spearmanCorrelation } from './spearman'
import type { PriceSeries, CorrelationObservation, CorrelationMethod } from '@/types'
import { MIN_SAMPLE_SIZE } from '@/lib/constants'

/**
 * Align two price series by matching timestamps.
 * Returns arrays of prices where both series have data.
 */
export function alignSeries(
  seriesA: PriceSeries,
  seriesB: PriceSeries
): { pricesA: number[]; pricesB: number[]; timestamps: number[] } {
  const mapB = new Map(seriesB.map((p) => [p.timestamp, p.price]))
  const aligned: { t: number; a: number; b: number }[] = []

  for (const pointA of seriesA) {
    const bPrice = mapB.get(pointA.timestamp)
    if (bPrice !== undefined) {
      aligned.push({ t: pointA.timestamp, a: pointA.price, b: bPrice })
    }
  }

  // Sort by timestamp
  aligned.sort((a, b) => a.t - b.t)

  return {
    timestamps: aligned.map((p) => p.t),
    pricesA: aligned.map((p) => p.a),
    pricesB: aligned.map((p) => p.b),
  }
}

/**
 * Compute log returns from a price array.
 */
export function logReturns(prices: number[]): number[] {
  const returns: number[] = []
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0 && prices[i] > 0) {
      returns.push(Math.log(prices[i] / prices[i - 1]))
    } else {
      returns.push(0)
    }
  }
  return returns
}

/**
 * Compute rolling correlation over a sliding window.
 * Returns correlation observations (timestamp, value).
 */
export function rollingCorrelation(
  seriesA: PriceSeries,
  seriesB: PriceSeries,
  window: number,
  method: CorrelationMethod = 'pearson'
): CorrelationObservation[] {
  const { timestamps, pricesA, pricesB } = alignSeries(seriesA, seriesB)

  if (timestamps.length < window + 1) return []

  const returnsA = logReturns(pricesA)
  const returnsB = logReturns(pricesB)
  // returnsA[i] corresponds to timestamps[i+1]

  const result: CorrelationObservation[] = []
  const correlFn = method === 'pearson' ? pearsonCorrelation : spearmanCorrelation

  for (let i = window; i < returnsA.length; i++) {
    const windowA = returnsA.slice(i - window, i)
    const windowB = returnsB.slice(i - window, i)
    const corr = correlFn(windowA, windowB)
    if (corr !== null) {
      result.push({ timestamp: timestamps[i + 1], value: corr })
    }
  }

  return result
}

/**
 * Calculate full correlation statistics over two aligned series.
 */
export function calculateCorrelationStats(
  seriesA: PriceSeries,
  seriesB: PriceSeries,
  window: number,
  method: CorrelationMethod = 'pearson'
): {
  currentCorrelation: number | null
  baselineCorrelation: number | null
  correlationStdDev: number | null
  zScore: number | null
  rolling: CorrelationObservation[]
  sampleSize: number
} {
  const { pricesA, pricesB, timestamps } = alignSeries(seriesA, seriesB)
  const sampleSize = timestamps.length

  if (sampleSize < MIN_SAMPLE_SIZE) {
    return {
      currentCorrelation: null,
      baselineCorrelation: null,
      correlationStdDev: null,
      zScore: null,
      rolling: [],
      sampleSize,
    }
  }

  const rolling = rollingCorrelation(seriesA, seriesB, window, method)

  if (rolling.length < window) {
    return {
      currentCorrelation: null,
      baselineCorrelation: null,
      correlationStdDev: null,
      zScore: null,
      rolling,
      sampleSize,
    }
  }

  const allValues = rolling.map((r) => r.value)
  const currentCorrelation = allValues[allValues.length - 1]

  // Baseline: mean of all rolling values except the last window
  const baselineValues = allValues.slice(0, -window)
  if (baselineValues.length < MIN_SAMPLE_SIZE) {
    return {
      currentCorrelation,
      baselineCorrelation: null,
      correlationStdDev: null,
      zScore: null,
      rolling,
      sampleSize,
    }
  }

  const baseline = baselineValues.reduce((s, v) => s + v, 0) / baselineValues.length
  const variance = baselineValues.reduce((s, v) => s + (v - baseline) ** 2, 0) / (baselineValues.length - 1)
  const stdDev = Math.sqrt(variance)

  let zScoreVal: number | null = null
  if (stdDev > 0) {
    zScoreVal = (currentCorrelation - baseline) / stdDev
  }

  return {
    currentCorrelation,
    baselineCorrelation: baseline,
    correlationStdDev: stdDev,
    zScore: zScoreVal,
    rolling,
    sampleSize,
  }
}
