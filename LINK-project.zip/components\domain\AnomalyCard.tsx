﻿'use client'
import { cn } from '@/lib/utils'
import { formatCorrelation, formatZScore, formatDateShort } from '@/lib/formatters'
import { SwissStatus } from '@/components/swiss'
import type { Anomaly } from '@/types'

interface AnomalyCardProps {
  anomaly: Anomaly
  index: number
  onClick?: () => void
  className?: string
}

export function AnomalyCard({ anomaly, index, onClick, className }: AnomalyCardProps) {
  const { analysis, assetA, assetB } = anomaly
  const absZ = Math.abs(analysis.zScore ?? 0)

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(e) => e.key === 'Enter' && onClick?.()}
      className={cn(
        'border-2 border-black p-4 cursor-pointer transition-all duration-150',
        'hover:border-accent group',
        className
      )}
      aria-label={`Anomaly: ${assetA.symbol} / ${assetB.symbol}, Z-score ${formatZScore(analysis.zScore)}`}
    >
      <div className="flex items-start justify-between gap-4 mb-3">
        <div>
          <span className="text-label text-gray-mid uppercase tracking-widest mono-value">
            {String(index + 1).padStart(2, '0')} / {anomaly.severity} ANOMALY
          </span>
          <h3 className="text-lg font-black mt-0.5 group-hover:text-accent transition-colors">
            {assetA.symbol} / {assetB.symbol}
          </h3>
        </div>
        <SwissStatus
          status={anomaly.severity === 'EXTREME' || anomaly.severity === 'HIGH' ? 'BLOCKED' : 'WARNING'}
          label={anomaly.severity}
        />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div>
          <span className="text-label uppercase tracking-widest text-gray-mid">CURRENT</span>
          <p className="text-xl font-black mono-value mt-0.5">
            {formatCorrelation(analysis.currentCorrelation)}
          </p>
        </div>
        <div>
          <span className="text-label uppercase tracking-widest text-gray-mid">BASELINE</span>
          <p className="text-xl font-black mono-value mt-0.5">
            {formatCorrelation(analysis.baselineCorrelation)}
          </p>
        </div>
        <div>
          <span className="text-label uppercase tracking-widest text-gray-mid">Z-SCORE</span>
          <p className="text-xl font-black mono-value mt-0.5 text-accent">
            {formatZScore(analysis.zScore)}
          </p>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-gray-subtle flex items-center justify-between">
        <span className="text-label uppercase tracking-widest text-gray-mid">
          {analysis.regime.replace('_', ' ')}
        </span>
        <span className="text-label uppercase tracking-widest text-gray-mid">
          OPEN →
        </span>
      </div>
    </div>
  )
}
