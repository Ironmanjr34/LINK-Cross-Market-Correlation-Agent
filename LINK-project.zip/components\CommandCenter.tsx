'use client'
import { useState } from 'react'
import { SwissButton } from '@/components/swiss'
import { parseUserIntent } from '@/services/ai'
import { useLinkStore } from '@/services/persistence/store'
import { useRouter } from 'next/navigation'
import { Search } from 'lucide-react'

const EXAMPLE_PROMPTS = [
  'Find unusual relationships between BTC and equities.',
  'Find the strongest correlation breaks in the last 30 days.',
  'Build a mean-reversion strategy for BTC and Nasdaq.',
  'Which relationships are becoming unstable?',
  'Analyze portfolio correlation risk.',
]

export function CommandCenter() {
  const [query, setQuery] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()
  const { addJournalEntry } = useLinkStore()

  const handleSubmit = async () => {
    if (!query.trim()) return
    setIsProcessing(true)

    addJournalEntry({
      type: 'USER_COMMAND',
      title: 'USER COMMAND',
      detail: query,
      status: 'INFO',
    })

    try {
      const intent = await parseUserIntent(query)

      addJournalEntry({
        type: 'AI_INTERPRETATION',
        title: 'AI PARSED INTENT',
        detail: `${intent.assetA} / ${intent.assetB} — ${intent.type}`,
        pair: `${intent.assetA}-${intent.assetB}`,
        status: 'SUCCESS',
      })

      router.push(`/relationship/${intent.assetA}-${intent.assetB}`)
    } catch {
      addJournalEntry({
        type: 'AI_INTERPRETATION',
        title: 'AI PARSE FAILED',
        detail: 'Using default configuration',
        status: 'WARNING',
      })
      router.push('/relationship/BTC-NASDAQ')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="p-6 md:p-8 bg-white">
      <p className="text-[11px] uppercase tracking-widest text-[#999999] font-bold mb-1">AI COMMAND INTERFACE</p>
      <p className="text-sm font-black mb-4 uppercase tracking-wider">INVESTIGATE CROSS-MARKET RELATIONSHIPS</p>

      <div className="flex gap-0">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#999999]" size={16} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            placeholder="e.g. Find unusual relationships between BTC and Nasdaq..."
            className="w-full border-2 border-black border-r-0 pl-10 pr-4 py-3 text-sm font-medium placeholder:text-[#999999] focus:outline-none focus:border-accent bg-white"
            aria-label="Command input"
          />
        </div>
        <SwissButton
          onClick={handleSubmit}
          isLoading={isProcessing}
          disabled={!query.trim() || isProcessing}
          variant="primary"
          size="md"
        >
          ANALYZE
        </SwissButton>
      </div>

      {/* Example prompts */}
      <div className="mt-4">
        <p className="text-[10px] uppercase tracking-widest text-[#999999] font-bold mb-2">TRY PROMPTS:</p>
        <div className="flex flex-wrap gap-2">
          {EXAMPLE_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              onClick={() => setQuery(prompt)}
              className="text-[11px] border border-[#E8E8E8] px-2.5 py-1 hover:border-black hover:text-black transition-colors duration-150 text-[#444444] bg-white cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
