import { cn } from '@/lib/utils'
import type { ReactNode } from 'react'

interface SwissSectionLabelProps {
  number?: string
  children: ReactNode
  accent?: boolean
  className?: string
  size?: 'sm' | 'md'
}

export function SwissSectionLabel({
  number,
  children,
  accent = false,
  className,
  size = 'md',
}: SwissSectionLabelProps) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      {number && (
        <span
          className={cn(
            'font-black mono-value',
            size === 'sm' ? 'text-[11px]' : 'text-xs',
            accent ? 'text-accent' : 'text-[#999999]'
          )}
        >
          {number} /
        </span>
      )}
      <span
        className={cn(
          'uppercase tracking-widest font-bold text-black',
          size === 'sm' ? 'text-[11px]' : 'text-xs'
        )}
      >
        {children}
      </span>
    </div>
  )
}
