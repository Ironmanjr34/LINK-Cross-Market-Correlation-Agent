'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useState } from 'react'
import { Menu, X, ArrowRight, ShieldCheck, Cpu } from 'lucide-react'
import { useLinkStore } from '@/services/persistence/store'
import { formatCurrency } from '@/lib/formatters'

const NAV_ITEMS = [
  { href: '/', number: '01', label: 'OVERVIEW' },
  { href: '/correlation', number: '02', label: 'CORRELATION' },
  { href: '/anomalies', number: '03', label: 'ANOMALIES' },
  { href: '/strategies', number: '04', label: 'STRATEGIES' },
  { href: '/backtest', number: '05', label: 'BACKTEST' },
  { href: '/paper', number: '06', label: 'PAPER TRADE' },
  { href: '/journal', number: '07', label: 'JOURNAL' },
]

export function NavBar() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const paperBalance = useLinkStore((s) => s.paperBalance)
  const scanResult = useLinkStore((s) => s.scanResult)

  return (
    <>
      {/* Mobile Top Header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 border-b-4 border-black bg-white sticky top-0 z-50">
        <Link href="/" className="flex flex-col">
          <span className="text-base font-black tracking-tighter leading-none">LINK</span>
          <span className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">
            CORRELATION AGENT
          </span>
        </Link>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 border-2 border-black hover:bg-black hover:text-white transition-colors"
          aria-label={mobileMenuOpen ? 'Close navigation' : 'Open navigation'}
        >
          {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {/* Mobile Drawer (from right side) */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/60 flex justify-end">
          <div className="w-4/5 max-w-xs bg-white h-full border-l-4 border-black flex flex-col justify-between p-6 animate-in slide-in-from-right">
            <div>
              <div className="flex items-center justify-between pb-4 border-b-2 border-black mb-6">
                <div>
                  <span className="text-xl font-black tracking-tighter">LINK</span>
                  <p className="text-[10px] text-[#999999] uppercase tracking-widest font-bold">
                    TERMINAL NAVIGATION
                  </p>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 border-2 border-black hover:bg-accent hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>

              <nav className="space-y-1">
                {NAV_ITEMS.map((item) => {
                  const isActive =
                    item.href === '/'
                      ? pathname === '/'
                      : pathname.startsWith(item.href)
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={cn(
                        'flex items-center justify-between px-3 py-3 border-b border-[#E8E8E8] text-xs font-bold uppercase tracking-widest transition-colors',
                        isActive
                          ? 'bg-black text-white border-black'
                          : 'hover:bg-accent hover:text-white text-black'
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <span className="mono-value text-[10px] opacity-70">{item.number}</span>
                        {item.label}
                      </span>
                      {isActive && <ArrowRight size={14} />}
                    </Link>
                  )
                })}
              </nav>
            </div>

            <div className="border-t-2 border-black pt-4 space-y-2">
              <div className="flex items-center justify-between text-[10px] uppercase tracking-widest">
                <span className="text-[#999999]">MODE</span>
                <span className="font-bold text-accent">DEMO (SEEDED)</span>
              </div>
              <div className="flex items-center justify-between text-[10px] uppercase tracking-widest">
                <span className="text-[#999999]">SIM BALANCE</span>
                <span className="font-mono font-bold">{formatCurrency(paperBalance)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Right-Side Vertical Terminal Rail */}
      <aside className="hidden md:flex md:w-64 lg:w-72 shrink-0 md:h-screen md:sticky md:top-0 border-l-4 border-black bg-white flex-col justify-between z-40 overflow-y-auto">
        {/* Top Header Block */}
        <div>
          <Link
            href="/"
            className="block p-6 border-b-4 border-black hover:bg-accent hover:text-white transition-colors duration-150 group"
          >
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black tracking-tighter leading-none">LINK</span>
              <span className="text-[10px] mono-value text-[#999999] group-hover:text-white">v0.1</span>
            </div>
            <p className="text-[10px] uppercase tracking-widest font-bold text-[#999999] group-hover:text-white mt-1">
              CROSS-MARKET CORRELATION AGENT
            </p>
          </Link>

          {/* System Status Pill Box */}
          <div className="p-4 border-b-2 border-black bg-[#F2F2F2] space-y-2">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-widest">
              <span className="flex items-center gap-1.5 font-bold text-black">
                <span className="w-2 h-2 bg-accent animate-pulse" />
                DEMO MODE
              </span>
              <span className="font-mono text-[9px] text-[#444444] font-bold">ACTIVE</span>
            </div>
            <div className="flex items-center justify-between text-[9px] uppercase tracking-widest text-[#999999]">
              <span>MARKET UNIVERSE</span>
              <span className="font-mono font-bold text-black">12 ASSETS</span>
            </div>
          </div>

          {/* Vertical Navigation Links */}
          <nav className="flex flex-col">
            {NAV_ITEMS.map((item) => {
              const isActive =
                item.href === '/'
                  ? pathname === '/'
                  : pathname.startsWith(item.href)
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center justify-between px-5 py-3.5 border-b border-[#E8E8E8] text-xs font-bold uppercase tracking-widest transition-colors duration-150 group',
                    isActive
                      ? 'bg-black text-white border-black'
                      : 'hover:bg-accent hover:text-white text-black'
                  )}
                >
                  <span className="flex items-center gap-3">
                    <span
                      className={cn(
                        'mono-value text-[10px] font-medium',
                        isActive
                          ? 'text-white/60'
                          : 'text-[#999999] group-hover:text-white/80'
                      )}
                    >
                      {item.number}
                    </span>
                    <span>{item.label}</span>
                  </span>
                  {isActive && (
                    <ArrowRight size={14} className="text-white" />
                  )}
                </Link>
              )
            })}
          </nav>
        </div>

        {/* Bottom Utility / Quick Terminal Stats */}
        <div className="border-t-4 border-black p-5 space-y-3 bg-white">
          <p className="text-[10px] uppercase tracking-widest text-[#999999] font-bold">
            TERMINAL MONITOR
          </p>

          <div className="space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-[#999999]">PAPER BAL:</span>
              <span className="font-bold">{formatCurrency(paperBalance)}</span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-[#999999]">AI MODEL:</span>
              <span className="font-bold text-black flex items-center gap-1">
                <Cpu size={11} className="text-accent" />
                GEMINI 3.8
              </span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-[#999999]">ANOMALIES:</span>
              <span className="font-bold text-accent">
                {scanResult ? `${scanResult.anomalies.length} DETECTED` : 'READY'}
              </span>
            </div>
          </div>

          <div className="pt-2 border-t border-[#E8E8E8]">
            <p className="text-[9px] text-[#999999] uppercase tracking-widest leading-relaxed">
              SWISS TERMINAL LAYOUT — RIGHT NAVIGATION RAIL
            </p>
          </div>
        </div>
      </aside>
    </>
  )
}
